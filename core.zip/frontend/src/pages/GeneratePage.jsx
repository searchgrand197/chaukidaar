import React, { useState } from 'react';
import { deviceService } from '../api/services';
import { toast } from 'react-hot-toast';
import { QrCode, Download, Printer, Loader2, Info, CheckCircle, FileSpreadsheet } from 'lucide-react';
import { printPdf } from '../utils/print';
import { downloadBatchExcel } from '../utils/downloadExcel';

const GeneratePage = () => {
  const [count, setCount] = useState(28);
  const [isGenerating, setIsGenerating] = useState(false);
  const [result, setResult] = useState(null);

  const handleGenerate = async () => {
    if (count < 1 || count > 280) {
      toast.error("Please enter a number between 1 and 280");
      return;
    }

    setIsGenerating(true);
    try {
      const response = await deviceService.generateBatch(count);
      setResult(response.data);
      toast.success(response.data.message);
    } catch (err) {
      toast.error(err.response?.data?.error || "Failed to generate batch");
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-8 animate-in slide-in-from-bottom duration-500">
      <div className="text-center">
        <h1 className="text-3xl font-bold text-slate-900">QR Batch Generator</h1>
        <p className="text-slate-500 mt-2">Generate and print unique device ID labels in A4 format.</p>
      </div>

      <div className="glass-card p-8 space-y-6">
        <div className="flex items-start gap-4 p-4 bg-blue-50 border border-blue-100 rounded-xl text-blue-700 text-sm">
          <Info className="w-5 h-5 flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-bold">Pro Tip: Label Sheet Layout</p>
            <p className="mt-1">Standard A4 sheets with 28 labels (4 columns x 7 rows) are recommended. Each batch will be formatted to fit these dimensions perfectly.</p>
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-sm font-bold text-slate-700">Number of Device IDs</label>
          <div className="flex gap-4">
            <input 
              type="number" 
              className="input-field flex-1 text-lg font-semibold"
              value={count}
              onChange={(e) => setCount(parseInt(e.target.value) || '')}
              min="1"
              max="280"
              placeholder="e.g. 28"
            />
            <button 
              onClick={handleGenerate}
              disabled={isGenerating}
              className="btn-primary flex items-center gap-2 px-8 min-w-[160px] justify-center"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <QrCode className="w-5 h-5" />
                  Generate
                </>
              )}
            </button>
          </div>
          <p className="text-xs text-slate-400">Enter a count (multiple of 28 is recommended for full pages).</p>
        </div>
      </div>

      {result && (
        <div className="glass-card p-8 border-primary-100 bg-primary-50/30 animate-in zoom-in duration-300">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center shadow-sm border border-primary-200">
                <CheckCircle className="w-8 h-8 text-green-500" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-slate-900">Batch #{result.batch_id} Ready</h3>
                <p className="text-slate-600">Successfully generated {count} unique device IDs.</p>
              </div>
            </div>
            
            <div className="flex flex-wrap gap-3 w-full md:w-auto">
              <a 
                href={result.pdf_url} 
                target="_blank" 
                rel="noreferrer"
                className="btn-primary flex-1 md:flex-none flex items-center justify-center gap-2"
              >
                <Download className="w-5 h-5" />
                Download PDF
              </a>
              <button
                type="button"
                onClick={() => downloadBatchExcel(result.batch_id, result.excel_url)}
                className="btn-secondary flex-1 md:flex-none flex items-center justify-center gap-2 bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100"
              >
                <FileSpreadsheet className="w-5 h-5" />
                Download Excel
              </button>
              <button 
                type="button"
                onClick={() => printPdf(result.pdf_url)}
                className="btn-secondary flex-1 md:flex-none flex items-center justify-center gap-2"
              >
                <Printer className="w-5 h-5" />
                Print Now
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default GeneratePage;
