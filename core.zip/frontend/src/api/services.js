import client from './client';

export const authService = {
  login: (credentials) => client.post('/auth/login/', credentials),
  getMe: () => client.get('/auth/me/'),
};

export const deviceService = {
  list: (params) => client.get('/devices/', { params }),
  get: (id) => client.get(`/devices/${id}/`),
  generateBatch: (count) => client.post('/devices/generate_batch/', { count }),
  assign: (data) => client.post('/device/assign/', data),
  verify: (deviceId) => client.get(`/devices/verify/${deviceId}/`),
};

export const batchService = {
  list: (params) => client.get('/batches/', { params }),
  downloadExcel: (batchNumber) =>
    client.get(`/batches/${batchNumber}/excel/`, { responseType: 'blob' }),
};

export const customerDeviceService = {
  list: () => client.get('/customer/devices/'),
  status: (deviceId) => client.get(`/customer/devices/${deviceId}/status/`),
  setPower: (deviceId, enabled) => client.post(`/customer/devices/${deviceId}/power/`, { enabled }),
  schedules: (deviceId) => client.get(`/customer/devices/${deviceId}/schedules/`),
  saveSchedule: (deviceId, schedule) => client.post(`/customer/devices/${deviceId}/schedules/`, schedule),
  deleteSchedule: (deviceId, scheduleId) => client.delete(`/customer/devices/${deviceId}/schedules/${scheduleId}/`),
  getSensorReadings: (deviceId) => client.get(`/customer/devices/${deviceId}/sensor-readings/?limit=100`),
  updateWifi: (deviceId, data) => client.post(`/customer/devices/${deviceId}/wifi/`, data),
  getWifiSetupInfo: (deviceId) => client.get(`/customer/devices/${deviceId}/wifi-setup-info/`),
  requestWifiForget: (deviceId) => client.post(`/customer/devices/${deviceId}/wifi/forget/`),
  updateUltrasonicConfig: (deviceId, data) => client.post(`/customer/devices/${deviceId}/ultrasonic-config/`, data),
};
