from pathlib import Path

from django.conf import settings
from django.http import FileResponse, HttpResponse
from django.views.static import serve

FRONTEND_DIST = Path(settings.BASE_DIR) / 'frontend' / 'dist'


def spa_index(request):
    index = FRONTEND_DIST / 'index.html'
    if not index.is_file():
        return HttpResponse(
            '<!DOCTYPE html><html><body style="font-family:sans-serif;padding:2rem">'
            '<h1>Frontend not built</h1>'
            '<p>From the <code>frontend</code> folder run:</p>'
            '<pre>npm install\nnpm run build</pre>'
            '<p>Or for hot reload, run <code>npm run dev</code> and open '
            '<a href="http://127.0.0.1:1000">http://127.0.0.1:1000</a></p>'
            '</body></html>',
            content_type='text/html',
        )
    return FileResponse(index.open('rb'), content_type='text/html')


def dist_static(request, path):
    return serve(request, path, document_root=str(FRONTEND_DIST))


def dist_assets(request, path):
    return serve(request, path, document_root=str(FRONTEND_DIST / 'assets'))
