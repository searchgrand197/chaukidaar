# Generated manually — default QR Generator (admin) login for portal.

from django.contrib.auth.hashers import make_password
from django.db import migrations


def seed_qr_generator_user(apps, schema_editor):
    User = apps.get_model('accounts', 'User')
    user, created = User.objects.get_or_create(
        username='alok',
        defaults={
            'email': '',
            'role': 'admin',
            'is_staff': True,
            'is_active': True,
            'password': make_password('0000'),
        },
    )
    if not created:
        user.password = make_password('0000')
        user.role = 'admin'
        user.is_staff = True
        user.is_active = True
        user.save(update_fields=['password', 'role', 'is_staff', 'is_active'])


def unseed_qr_generator_user(apps, schema_editor):
    User = apps.get_model('accounts', 'User')
    User.objects.filter(username='alok').delete()


class Migration(migrations.Migration):

    dependencies = [
        ('accounts', '0002_alter_user_role'),
    ]

    operations = [
        migrations.RunPython(seed_qr_generator_user, unseed_qr_generator_user),
    ]
