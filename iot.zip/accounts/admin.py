from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User

@admin.register(User)
class CustomUserAdmin(UserAdmin):
    fieldsets = UserAdmin.fieldsets + (
        ('Portal Details', {'fields': ('role', 'phone', 'active_status')}),
    )
    list_display = ('username', 'email', 'role', 'phone', 'active_status', 'is_staff')
    list_filter = ('role', 'active_status', 'is_staff')
