from django.contrib.auth.models import AbstractUser
from django.db import models

class User(AbstractUser):
    ROLE_CHOICES = (
        ('admin', 'Admin'),
        ('salesperson', 'Salesperson'),
        ('customer', 'Customer'),
    )
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='salesperson')
    phone = models.CharField(max_length=15, blank=True, null=True)
    active_status = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.username} ({self.role})"
