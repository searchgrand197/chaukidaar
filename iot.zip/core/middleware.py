class CsrfExemptIotApiMiddleware:
    """ESP8266 cannot send CSRF cookies — exempt /api/iot/ paths."""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if request.path.startswith('/api/iot/'):
            request._dont_enforce_csrf_checks = True
        return self.get_response(request)
