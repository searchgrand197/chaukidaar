import { toast } from 'react-hot-toast';

export const printPdf = async (url) => {
  const loadingToast = toast.loading("Opening Print Dialog...");

  try {
    // 1. Fetch PDF as blob
    const response = await fetch(url, { mode: 'cors' });
    if (!response.ok) throw new Error('Failed to fetch PDF');
    const blob = await response.blob();
    const blobUrl = URL.createObjectURL(blob);

    // 2. Use a persistent iframe (or just one that stays longer)
    let iframe = document.getElementById('print-iframe');
    if (!iframe) {
      iframe = document.createElement('iframe');
      iframe.id = 'print-iframe';
      iframe.style.position = 'fixed';
      iframe.style.right = '0';
      iframe.style.bottom = '0';
      iframe.style.width = '0';
      iframe.style.height = '0';
      iframe.style.border = 'none';
      document.body.appendChild(iframe);
    }

    iframe.src = blobUrl;

    iframe.onload = () => {
      toast.dismiss(loadingToast);
      setTimeout(() => {
        try {
          iframe.contentWindow.focus();
          iframe.contentWindow.print();
        } catch (e) {
          console.error("Print execution failed:", e);
          window.open(url, '_blank');
        }
      }, 500); // Small delay to ensure rendering
    };

  } catch (error) {
    toast.dismiss(loadingToast);
    console.error("Print failed:", error);
    toast.error("Opening in new tab instead...");
    window.open(url, '_blank');
  }
};
