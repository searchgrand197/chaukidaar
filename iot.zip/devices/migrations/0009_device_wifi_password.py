from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('devices', '0008_batch_excel_file'),
    ]

    operations = [
        migrations.AddField(
            model_name='device',
            name='wifi_password',
            field=models.CharField(blank=True, max_length=100),
        ),
    ]
