import React, { useState, useEffect } from 'react';
import { batchService } from '../api/services';
import { 
  History, 
  Download, 
  Calendar, 
  Package,
  Loader2,
  FileSpreadsheet
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { format } from 'date-fns';
import { toast } from 'react-hot-toast';
import { printPdf } from '../utils/print';
import { downloadBatchExcel } from '../utils/downloadExcel';

const BatchHistory = () => {
  const [batches, setBatches] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchBatches = async () => {
      try {
        const res = await batchService.list();
        setBatches(res.data?.results || []);
      } catch (err) {
        toast.error("Failed to load batch history");
      } finally {
        setLoading(false);
      }
    };
    fetchBatches();
  }, []);

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Batch Generation History</h1>
          <p className="text-slate-500">View and download previously generated device ID batches.</p>
        </div>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="w-10 h-10 animate-spin text-primary-500" />
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {batches?.map((batch) => (
            <div key={batch.batch_number} className="glass-card overflow-hidden hover:shadow-md transition-shadow">
              <div className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="w-12 h-12 bg-slate-100 rounded-xl flex items-center justify-center text-slate-600">
                    <History className="w-6 h-6" />
                  </div>
                  <span className="px-3 py-1 bg-primary-50 text-primary-700 rounded-full text-xs font-bold border border-primary-100">
                    Batch #{batch.batch_number}
                  </span>
                </div>
                
                <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                  <Package className="w-4 h-4 text-slate-400" />
                  {batch.count} Devices Generated
                </h3>
                
                <div className="flex items-center gap-2 mt-4 text-slate-500 text-sm">
                  <Calendar className="w-4 h-4" />
                  {format(new Date(batch.created_at), 'MMMM dd, yyyy HH:mm')}
                </div>
              </div>
              
              <div className="px-6 py-4 bg-slate-50 border-t border-slate-100 flex flex-wrap gap-2">
                <a 
                  href={batch.pdf_url} 
                  target="_blank" 
                  rel="noreferrer"
                  className="flex-1 min-w-[80px] btn-primary flex items-center justify-center gap-2 py-2"
                >
                  <Download className="w-4 h-4" />
                  PDF
                </a>
                <button
                  type="button"
                  onClick={() => downloadBatchExcel(batch.batch_number, batch.excel_url)}
                  className="flex-1 min-w-[80px] btn-secondary flex items-center justify-center gap-2 py-2 bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100"
                >
                  <FileSpreadsheet className="w-4 h-4" />
                  Excel
                </button>
                <button 
                  type="button"
                  onClick={() => printPdf(batch.pdf_url)}
                  className="flex-1 min-w-[80px] btn-secondary flex items-center justify-center gap-2 py-2"
                >
                  <Download className="w-4 h-4 rotate-180" /> 
                  Print
                </button>
              </div>
            </div>
          ))}
          
          {batches.length === 0 && (
            <div className="col-span-full py-20 text-center glass-card">
              <History className="w-16 h-16 text-slate-200 mx-auto mb-4" />
              <p className="text-slate-400 font-medium">No batches found. Start by generating a new one.</p>
              <Link to="/admin/generate" className="text-primary-600 font-bold hover:underline mt-2 inline-block">
                Generate First Batch
              </Link>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default BatchHistory;
