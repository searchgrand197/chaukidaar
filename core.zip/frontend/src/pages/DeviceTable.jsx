import React, { useState, useEffect } from 'react';
import { deviceService } from '../api/services';
import { 
  Search, 
  Filter, 
  MoreVertical, 
  UserPlus, 
  Trash2, 
  ExternalLink,
  ChevronLeft,
  ChevronRight,
  Loader2,
  Tablet
} from 'lucide-react';
import { format } from 'date-fns';
import { toast } from 'react-hot-toast';

const StatusBadge = ({ status }) => {
  const styles = {
    available: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    assigned: 'bg-blue-50 text-blue-700 border-blue-200',
    damaged: 'bg-rose-50 text-rose-700 border-rose-200',
  };
  return (
    <span className={`px-2.5 py-1 rounded-full text-xs font-bold border ${styles[status]}`}>
      {status.toUpperCase()}
    </span>
  );
};

const DeviceTable = () => {
  const [devices, setDevices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [page, setPage] = useState(1);
  const [count, setCount] = useState(0);

  const fetchDevices = async () => {
    setLoading(true);
    try {
      const res = await deviceService.list({ 
        page, 
        device_id: search, 
        status: statusFilter 
      });
      setDevices(res.data?.results || []);
      setCount(res.data?.count || 0);
    } catch (err) {
      toast.error("Failed to fetch devices");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const timer = setTimeout(fetchDevices, 500);
    return () => clearTimeout(timer);
  }, [search, statusFilter, page]);

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <h1 className="text-2xl font-bold text-slate-900">Device Management</h1>
        <div className="flex flex-1 md:max-w-md gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input 
              type="text" 
              className="input-field pl-10" 
              placeholder="Search by Device ID..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <select 
            className="input-field w-auto min-w-[140px]"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
          >
            <option value="">All Status</option>
            <option value="available">Available</option>
            <option value="assigned">Assigned</option>
            <option value="damaged">Damaged</option>
          </select>
        </div>
      </div>

      <div className="glass-card overflow-hidden">
        {/* Desktop Table View */}
        <div className="hidden md:block overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wider">
              <tr>
                <th className="px-6 py-4 font-semibold">Device ID</th>
                <th className="px-6 py-4 font-semibold">Status</th>
                <th className="px-6 py-4 font-semibold">Shop Name</th>
                <th className="px-6 py-4 font-semibold">Created Date</th>
                <th className="px-6 py-4 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <tr>
                  <td colSpan="5" className="px-6 py-12 text-center">
                    <Loader2 className="w-8 h-8 animate-spin mx-auto text-primary-500" />
                  </td>
                </tr>
              ) : devices?.length > 0 ? (
                devices?.map((device) => (
                  <tr key={device.id} className="hover:bg-slate-50 transition-colors group">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-slate-100 rounded-lg flex items-center justify-center">
                          <Tablet className="w-5 h-5 text-slate-500" />
                        </div>
                        <span className="font-bold text-slate-900">{device.device_id}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <StatusBadge status={device.status} />
                    </td>
                    <td className="px-6 py-4 text-slate-600 font-medium">
                      {device.assignment?.shop_name || '—'}
                    </td>
                    <td className="px-6 py-4 text-slate-500 text-sm">
                      {format(new Date(device.created_at), 'MMM dd, yyyy HH:mm')}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex justify-end gap-2">
                        <button className="p-2 hover:bg-primary-50 text-slate-400 hover:text-primary-600 rounded-lg transition-colors" title="Assign">
                          <UserPlus className="w-4 h-4" />
                        </button>
                        <button className="p-2 hover:bg-slate-100 text-slate-400 hover:text-slate-600 rounded-lg transition-colors" title="View Details">
                          <ExternalLink className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="5" className="px-6 py-12 text-center text-slate-400 italic">
                    No devices found matching your criteria.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Mobile Card View */}
        <div className="md:hidden divide-y divide-slate-100">
          {loading ? (
            <div className="py-20 text-center">
              <Loader2 className="w-8 h-8 animate-spin mx-auto text-primary-500" />
            </div>
          ) : devices?.length > 0 ? (
            devices?.map((device) => (
              <div key={device.id} className="p-4 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-slate-100 rounded-lg flex items-center justify-center">
                      <Tablet className="w-5 h-5 text-slate-500" />
                    </div>
                    <div>
                      <p className="font-bold text-slate-900">{device.device_id}</p>
                      <p className="text-xs text-slate-500">{format(new Date(device.created_at), 'MMM dd, HH:mm')}</p>
                    </div>
                  </div>
                  <StatusBadge status={device.status} />
                </div>
                <div className="flex items-center justify-between pt-2">
                  <div className="text-sm">
                    <span className="text-slate-500">Shop: </span>
                    <span className="font-medium text-slate-700">{device.assignment?.shop_name || '—'}</span>
                  </div>
                  <div className="flex gap-2">
                    <button className="p-2 bg-slate-100 rounded-lg text-slate-600">
                      <UserPlus className="w-4 h-4" />
                    </button>
                    <button className="p-2 bg-slate-100 rounded-lg text-slate-600">
                      <ExternalLink className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="py-20 text-center text-slate-400 italic">
              No devices found.
            </div>
          )}
        </div>

        {/* Pagination */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
          <p className="text-sm text-slate-500">
            Showing <span className="font-bold text-slate-800">{devices.length}</span> of <span className="font-bold text-slate-800">{count}</span> devices
          </p>
          <div className="flex gap-2">
            <button 
              disabled={page === 1}
              onClick={() => setPage(p => p - 1)}
              className="p-2 border border-slate-200 rounded-lg hover:bg-white disabled:opacity-50"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button 
              disabled={page * 20 >= count}
              onClick={() => setPage(p => p + 1)}
              className="p-2 border border-slate-200 rounded-lg hover:bg-white disabled:opacity-50"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DeviceTable;
