import { batchService } from '../api/services';
import { toast } from 'react-hot-toast';

export async function downloadBatchExcel(batchNumber, excelUrl = null) {
  try {
    if (excelUrl) {
      const link = document.createElement('a');
      link.href = excelUrl;
      link.download = `batch_${batchNumber}.xlsx`;
      link.target = '_blank';
      link.rel = 'noreferrer';
      document.body.appendChild(link);
      link.click();
      link.remove();
      return;
    }

    const response = await batchService.downloadExcel(batchNumber);
    const blob = new Blob([response.data], {
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `batch_${batchNumber}.xlsx`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.URL.revokeObjectURL(url);
  } catch (err) {
    toast.error('Failed to download Excel file');
    throw err;
  }
}
