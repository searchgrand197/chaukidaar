import React, { useState, useEffect } from 'react';
import { Package, Calendar, MapPin, ChevronRight, Loader2, ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import client from '../../api/client';
import { motion } from 'framer-motion';

const SalesHistory = () => {
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  const openAssignment = (item) => {
    navigate(`/sales/assignment/${item.id}`, { state: { assignment: item } });
  };

  useEffect(() => {
    const fetchHistory = async () => {
      try {
        const response = await client.get('/device/history/');
        // Handle paginated response (results) or plain array
        const data = response.data.results || response.data || [];
        setHistory(data);
      } catch (error) {
        console.error(error);
      } finally {
        setLoading(false);
      }
    };
    fetchHistory();
  }, []);

  return (
    <div className="min-h-screen bg-slate-50 p-4 md:p-8">
      <div className="max-w-4xl mx-auto space-y-6">
        <button 
          onClick={() => navigate('/sales/dashboard')}
          className="flex items-center text-slate-500 hover:text-indigo-600 transition-colors font-medium mb-4"
        >
          <ArrowLeft size={20} className="mr-2" />
          Back to Dashboard
        </button>

        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold text-slate-900">Assignment History</h1>
          <div className="px-4 py-2 bg-white rounded-xl border border-slate-200 text-sm font-bold text-slate-600">
            {history.length} Total
          </div>
        </div>

        {loading ? (
          <div className="flex flex-col items-center justify-center py-20 bg-white rounded-[2rem] border border-slate-100">
            <Loader2 className="w-12 h-12 animate-spin text-indigo-600 mb-4" />
            <p className="text-slate-500 font-medium">Loading your history...</p>
          </div>
        ) : history.length > 0 ? (
          <div className="space-y-4">
            {history.map((item, index) => (
              <motion.button
                key={item.id ?? index}
                type="button"
                onClick={() => openAssignment(item)}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className="w-full text-left bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm hover:shadow-md transition-all group cursor-pointer"
              >
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div className="flex items-start gap-4">
                    <div className="w-14 h-14 bg-indigo-50 rounded-2xl flex items-center justify-center text-indigo-600 shrink-0">
                      <Package size={28} />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">{item.shop_name}</h3>
                      <p className="text-slate-500 flex items-center mt-1">
                        <MapPin size={14} className="mr-1" />
                        {item.city}, {item.state}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between md:text-right border-t md:border-t-0 pt-4 md:pt-0 border-slate-50">
                    <div className="space-y-1">
                      <p className="text-sm font-mono font-bold text-slate-800 bg-slate-100 px-2 py-1 rounded inline-block md:block">
                        {item.device_id_str}
                      </p>
                      <p className="text-xs text-slate-400 flex items-center md:justify-end">
                        <Calendar size={12} className="mr-1" />
                        {new Date(item.assigned_at).toLocaleDateString()}
                      </p>
                    </div>
                    <ChevronRight size={24} className="text-slate-300 md:ml-6 group-hover:text-indigo-400 group-hover:translate-x-1 transition-all" />
                  </div>
                </div>
              </motion.button>
            ))}
          </div>
        ) : (
          <div className="text-center py-20 bg-white rounded-[2rem] border border-slate-100">
            <Package size={64} className="text-slate-100 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-slate-800">No Assignments Yet</h3>
            <p className="text-slate-500 mt-2 max-w-xs mx-auto">
              You haven't assigned any devices yet. Start by scanning a QR code!
            </p>
            <button 
              onClick={() => navigate('/sales/scanner')}
              className="mt-6 bg-indigo-600 text-white font-bold px-8 py-3 rounded-xl hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-100"
            >
              Scan QR Code
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default SalesHistory;
