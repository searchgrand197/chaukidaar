from rest_framework import viewsets, status, generics
from rest_framework.views import APIView
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, IsAdminUser, AllowAny
from .iot_auth import DeviceTokenAuthentication
from django_filters.rest_framework import DjangoFilterBackend
from django.shortcuts import get_object_or_404
from django.utils import timezone
from .models import Device, Batch, DeviceSequence, DeviceAssignment, DeviceSchedule, SensorReading
from .serializers import (
    DeviceSerializer,
    BatchSerializer,
    GenerateBatchSerializer,
    DeviceAssignmentSerializer,
    CustomerDeviceSerializer,
    DeviceScheduleSerializer,
    SensorReadingSerializer,
    PowerControlSerializer,
    WifiConfigSerializer,
    UltrasonicConfigSerializer,
    AlertPhoneSerializer,
    TelemetrySerializer,
    CommandAckSerializer,
    HotspotWifiReportSerializer,
)
from .phone_utils import normalize_phone_e164
from services.qr_service import generate_device_qr
from services.pdf_service import generate_labels_pdf
from services.excel_service import generate_batch_excel
from django.http import FileResponse
from django.conf import settings
import os

class DeviceViewSet(viewsets.ModelViewSet):
    queryset = Device.objects.all()
    serializer_class = DeviceSerializer
    lookup_field = 'device_id'
    filter_backends = [DjangoFilterBackend]
    filterset_fields = ['status', 'device_id']
    search_fields = ['device_id']

    @action(detail=False, methods=['post'], permission_classes=[IsAdminUser])
    def generate_batch(self, request):
        serializer = GenerateBatchSerializer(data=request.data)
        if serializer.is_valid():
            try:
                count = serializer.validated_data['count']
                batch = Batch.objects.create(count=count)
                
                devices_created = []
                for _ in range(count):
                    device_id, seq_num = DeviceSequence.get_next_ids()
                    # Defensive check: ensure seq_num is valid
                    seq_num = int(seq_num) if seq_num is not None else 0
                    
                    qr_file = generate_device_qr(device_id)
                    
                    device = Device.objects.create(
                        device_id=device_id,
                        sequence_number=seq_num,
                        status='available',
                        batch=batch
                    )
                    device.qr_image.save(f"{device_id}.png", qr_file, save=True)
                    devices_created.append(device)
                
                pdf_filename = generate_labels_pdf(devices_created, batch.batch_number)
                batch.pdf_file = os.path.join('batches', pdf_filename)

                excel_filename = generate_batch_excel(devices_created, batch.batch_number)
                batch.excel_file = os.path.join('batches', excel_filename)
                batch.save()
                
                return Response({
                    "message": f"Successfully generated {count} devices",
                    "batch_id": batch.batch_number,
                    "pdf_url": request.build_absolute_uri(batch.pdf_file.url),
                    "excel_url": request.build_absolute_uri(batch.excel_file.url),
                }, status=status.HTTP_201_CREATED)
            except Exception as e:
                return Response({"error": f"Generation failed: {str(e)}"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=False, methods=['get'], url_path='verify/(?P<device_id>[^/.]+)')
    def verify(self, request, device_id=None):
        try:
            # Try searching by full device_id first
            device = Device.objects.filter(device_id=device_id).first()
            
            # If not found and looks like INT-X or INT-EX, try sequence_number
            if not device and device_id.startswith('INT-'):
                try:
                    suffix = device_id.split('-')[1]
                    # Extract only the numbers from the suffix (handles 'E5' -> 5)
                    import re
                    numeric_part = re.findall(r'\d+', suffix)[0]
                    seq_num = int(numeric_part)
                    device = Device.objects.get(sequence_number=seq_num)
                except (ValueError, IndexError, Device.DoesNotExist):
                    pass
            
            if not device:
                raise Device.DoesNotExist

            return Response(DeviceSerializer(device).data)
        except Device.DoesNotExist:
            return Response({"error": "Invalid Device ID", "valid": False}, status=status.HTTP_404_NOT_FOUND)

class BatchViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Batch.objects.all()
    serializer_class = BatchSerializer
    permission_classes = [IsAuthenticated]

    @action(detail=True, methods=['get'], url_path='excel')
    def download_excel(self, request, pk=None):
        batch = self.get_object()
        devices = list(batch.devices.order_by('sequence_number'))
        if not devices:
            return Response({'error': 'No devices in this batch'}, status=status.HTTP_404_NOT_FOUND)

        if not batch.excel_file:
            excel_filename = generate_batch_excel(devices, batch.batch_number)
            batch.excel_file = os.path.join('batches', excel_filename)
            batch.save(update_fields=['excel_file'])

        file_handle = batch.excel_file.open('rb')
        response = FileResponse(
            file_handle,
            content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        )
        response['Content-Disposition'] = (
            f'attachment; filename="batch_{batch.batch_number}.xlsx"'
        )
        return response

class AssignDeviceView(generics.CreateAPIView):
    permission_classes = [IsAuthenticated]
    serializer_class = DeviceAssignmentSerializer

    def perform_create(self, serializer):
        serializer.save(assigned_by=self.request.user)

class AssignmentHistoryView(generics.ListAPIView):
    permission_classes = [IsAuthenticated]
    serializer_class = DeviceAssignmentSerializer

    def get_queryset(self):
        user = self.request.user
        if user.role == 'admin':
            return DeviceAssignment.objects.all().order_by('-assigned_at')
        return DeviceAssignment.objects.filter(assigned_by=user).order_by('-assigned_at')

class CustomerDeviceMixin:
    permission_classes = [IsAuthenticated]

    def get_customer_device(self, device_id):
        queryset = Device.objects.select_related('assignment', 'customer')
        if self.request.user.role != 'admin':
            queryset = queryset.filter(customer=self.request.user)
        return generics.get_object_or_404(queryset, device_id=device_id)

class CustomerDeviceListView(generics.ListAPIView):
    permission_classes = [IsAuthenticated]
    serializer_class = CustomerDeviceSerializer

    def get_queryset(self):
        if self.request.user.role == 'admin':
            return Device.objects.select_related('assignment', 'customer').all()
        return Device.objects.select_related('assignment', 'customer').filter(customer=self.request.user)

class CustomerDeviceStatusView(CustomerDeviceMixin, APIView):
    def get(self, request, device_id):
        device = self.get_customer_device(device_id)
        return Response(CustomerDeviceSerializer(device).data)

class CustomerPowerView(CustomerDeviceMixin, APIView):
    def post(self, request, device_id):
        device = self.get_customer_device(device_id)
        serializer = PowerControlSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        device.desired_power_state = serializer.validated_data['enabled']
        device.is_armed = device.desired_power_state
        device.command_revision += 1
        device.save(update_fields=['desired_power_state', 'is_armed', 'command_revision'])
        return Response(CustomerDeviceSerializer(device).data)

class CustomerScheduleView(CustomerDeviceMixin, APIView):
    def get(self, request, device_id):
        device = self.get_customer_device(device_id)
        schedules = device.schedules.all()
        return Response(DeviceScheduleSerializer(schedules, many=True).data)

    def post(self, request, device_id):
        device = self.get_customer_device(device_id)
        serializer = DeviceScheduleSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        schedule = serializer.save(device=device)
        device.command_revision += 1
        device.save(update_fields=['command_revision'])
        return Response(DeviceScheduleSerializer(schedule).data, status=status.HTTP_201_CREATED)


class CustomerScheduleDetailView(CustomerDeviceMixin, APIView):
    def delete(self, request, device_id, schedule_id):
        device = self.get_customer_device(device_id)
        schedule = get_object_or_404(DeviceSchedule, id=schedule_id, device=device)
        schedule.delete()
        device.command_revision += 1
        device.save(update_fields=['command_revision'])
        return Response(status=status.HTTP_204_NO_CONTENT)


class CustomerSensorReadingView(CustomerDeviceMixin, APIView):
    def get(self, request, device_id):
        device = self.get_customer_device(device_id)
        limit = min(int(request.query_params.get('limit', 100)), 100)
        readings = list(device.sensor_readings.all()[:limit])
        readings.reverse()
        return Response(SensorReadingSerializer(readings, many=True).data)

class CustomerWifiConfigView(CustomerDeviceMixin, APIView):
    def post(self, request, device_id):
        device = self.get_customer_device(device_id)
        serializer = WifiConfigSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        device.pending_wifi_ssid = serializer.validated_data['ssid']
        device.pending_wifi_password = serializer.validated_data['password']
        device.wifi_config_revision += 1
        device.wifi_ack_status = 'pending'
        device.save(update_fields=[
            'pending_wifi_ssid',
            'pending_wifi_password',
            'wifi_config_revision',
            'wifi_ack_status',
        ])
        return Response({
            'message': 'WiFi update queued for device',
            'revision': device.wifi_config_revision,
            'status': device.wifi_ack_status,
        })


def build_device_ap_ssid(device_id: str) -> str:
    suffix = device_id[-4:].upper() if len(device_id) >= 4 else device_id.upper()
    return f"{settings.ESP_WIFI_AP_SSID_PREFIX}{suffix}"


class CustomerWifiSetupInfoView(CustomerDeviceMixin, APIView):
    def get(self, request, device_id):
        device = self.get_customer_device(device_id)
        return Response({
            'device_id': device.device_id,
            'ap_ssid': build_device_ap_ssid(device.device_id),
            'ap_password': settings.ESP_WIFI_AP_PASSWORD,
            'portal_url': settings.ESP_WIFI_PORTAL_URL,
            'current_wifi_ssid': device.wifi_ssid or '',
            'wifi_ack_status': device.wifi_ack_status,
        })


class CustomerWifiForgetView(CustomerDeviceMixin, APIView):
    def post(self, request, device_id):
        device = self.get_customer_device(device_id)
        device.pending_wifi_ssid = ''
        device.pending_wifi_password = ''
        device.wifi_ack_status = 'setup_local'
        device.save(update_fields=[
            'pending_wifi_ssid',
            'pending_wifi_password',
            'wifi_ack_status',
        ])
        return Response({
            'message': 'Use the device setup hotspot to configure WiFi locally.',
            'ap_ssid': build_device_ap_ssid(device.device_id),
            'ap_password': settings.ESP_WIFI_AP_PASSWORD,
            'portal_url': settings.ESP_WIFI_PORTAL_URL,
        })


class CustomerUltrasonicConfigView(CustomerDeviceMixin, APIView):
    def post(self, request, device_id):
        device = self.get_customer_device(device_id)
        serializer = UltrasonicConfigSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        pending = {**device.ultrasonic_config, **serializer.validated_data}
        device.pending_ultrasonic_config = pending
        device.ultrasonic_config_revision += 1
        device.ultrasonic_ack_status = 'pending'
        device.save(update_fields=[
            'pending_ultrasonic_config',
            'ultrasonic_config_revision',
            'ultrasonic_ack_status',
        ])
        return Response({
            'message': 'Ultrasonic update queued for device',
            'revision': device.ultrasonic_config_revision,
            'config': pending,
            'status': device.ultrasonic_ack_status,
        })


def build_notification_payload(device):
    try:
        assignment = device.assignment
    except DeviceAssignment.DoesNotExist:
        return None
    if not assignment.phone:
        return None
    payload = {
        'phone': normalize_phone_e164(assignment.phone),
    }
    if assignment.alternate_phone:
        alt = normalize_phone_e164(assignment.alternate_phone)
        if alt:
            payload['alternate_phone'] = alt
    return payload


class CustomerAlertPhoneView(CustomerDeviceMixin, APIView):
    def get(self, request, device_id):
        device = self.get_customer_device(device_id)
        try:
            assignment = device.assignment
        except DeviceAssignment.DoesNotExist:
            return Response({'error': 'Device is not assigned'}, status=status.HTTP_404_NOT_FOUND)
        return Response({
            'phone': assignment.phone or '',
            'alternate_phone': assignment.alternate_phone or '',
            'phone_e164': normalize_phone_e164(assignment.phone),
            'alternate_phone_e164': normalize_phone_e164(assignment.alternate_phone or ''),
        })

    def post(self, request, device_id):
        device = self.get_customer_device(device_id)
        try:
            assignment = device.assignment
        except DeviceAssignment.DoesNotExist:
            return Response({'error': 'Device is not assigned'}, status=status.HTTP_404_NOT_FOUND)
        serializer = AlertPhoneSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        assignment.phone = serializer.validated_data['phone']
        assignment.alternate_phone = serializer.validated_data.get('alternate_phone') or None
        assignment.save(update_fields=['phone', 'alternate_phone'])
        return Response({
            'message': 'Alert phone saved — device will receive it on next command poll',
            'phone': assignment.phone,
            'alternate_phone': assignment.alternate_phone or '',
            'phone_e164': normalize_phone_e164(assignment.phone),
            'alternate_phone_e164': normalize_phone_e164(assignment.alternate_phone or ''),
        })

class IoTTelemetryView(APIView):
    authentication_classes = [DeviceTokenAuthentication]
    permission_classes = [AllowAny]

    def post(self, request, device_id):
        device = request.auth
        serializer = TelemetrySerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data

        reading = SensorReading.objects.create(
            device=device,
            temperature=data.get('temperature'),
            ultrasonic_distance=data.get('ultrasonic_distance'),
            heat_alarm=data.get('heat_alarm', False),
            status=data.get('status', ''),
        )

        device.is_online = data.get('online', True)
        device.last_seen = timezone.now()
        if 'temperature' in data:
            device.last_temperature = data.get('temperature')
        if 'ultrasonic_distance' in data:
            device.last_ultrasonic_distance = data.get('ultrasonic_distance')
        if 'armed' in data:
            device.is_armed = data['armed']
        if data.get('firmware_version'):
            device.firmware_version = data['firmware_version']
        device.save(update_fields=[
            'is_online',
            'last_seen',
            'last_temperature',
            'last_ultrasonic_distance',
            'is_armed',
            'firmware_version',
        ])

        return Response({'ok': True, 'reading_id': reading.id})

class IoTCommandView(APIView):
    authentication_classes = [DeviceTokenAuthentication]
    permission_classes = [AllowAny]

    def compute_scheduled_power_context(self, device):
        """
        When at least one schedule is enabled, the device may arm only inside those
        time windows (and only if desired_power_state is true). Outside all windows
        the effective power is false — e.g. overnight 18:00–06:00 is off from 06:00–18:00.
        """
        schedules = list(device.schedules.filter(enabled=True))
        if not schedules:
            return {
                'effective_enabled': device.desired_power_state,
                'has_enabled_schedules': False,
                'in_schedule_window': True,
            }

        now = timezone.localtime()
        current_time = now.time()
        current_weekday = str(now.weekday())
        in_window = False
        for schedule in schedules:
            days = [p.strip() for p in schedule.weekdays.split(',') if p.strip()]
            if current_weekday not in days:
                continue
            if schedule.start_time <= schedule.end_time:
                if schedule.start_time <= current_time <= schedule.end_time:
                    in_window = True
                    break
            else:
                if current_time >= schedule.start_time or current_time <= schedule.end_time:
                    in_window = True
                    break

        if in_window:
            effective = device.desired_power_state
        else:
            effective = False

        return {
            'effective_enabled': effective,
            'has_enabled_schedules': True,
            'in_schedule_window': in_window,
        }

    def get(self, request, device_id):
        device = request.auth
        device.last_seen = timezone.now()
        device.is_online = True
        device.save(update_fields=['last_seen', 'is_online'])

        ctx = self.compute_scheduled_power_context(device)
        lite = request.query_params.get('lite') == '1'
        payload = {
            'device_id': device.device_id,
            'command_revision': device.command_revision,
            'desired_power_state': device.desired_power_state,
            'schedule_gate_active': ctx['has_enabled_schedules'],
            'in_schedule_window': ctx['in_schedule_window'],
            'power': {'enabled': ctx['effective_enabled']},
            'wifi_update': None,
            'ultrasonic_update': None,
        }
        if not lite:
            schedules = DeviceScheduleSerializer(device.schedules.filter(enabled=True), many=True).data
            payload['schedules'] = schedules
        if device.wifi_config_revision > device.wifi_ack_revision and device.pending_wifi_ssid:
            payload['wifi_update'] = {
                'revision': device.wifi_config_revision,
                'ssid': device.pending_wifi_ssid,
                'password': device.pending_wifi_password,
            }
        if device.ultrasonic_config_revision > device.ultrasonic_ack_revision and device.pending_ultrasonic_config:
            payload['ultrasonic_update'] = {
                'revision': device.ultrasonic_config_revision,
                'config': device.pending_ultrasonic_config,
            }
        notification = build_notification_payload(device)
        if notification:
            payload['notification'] = notification
        if not lite:
            try:
                assignment = device.assignment
                if assignment.wifi_ssid:
                    payload['sales_wifi'] = {
                        'ssid': assignment.wifi_ssid,
                        'password': assignment.wifi_password or '',
                    }
            except DeviceAssignment.DoesNotExist:
                pass
        return Response(payload)

class IoTCommandAckView(APIView):
    authentication_classes = [DeviceTokenAuthentication]
    permission_classes = [AllowAny]

    def post(self, request, device_id):
        device = request.auth
        serializer = CommandAckSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data
        update_fields = ['last_seen', 'is_online']

        device.last_seen = timezone.now()
        device.is_online = True

        if 'command_revision' in data:
            device.command_ack_revision = max(device.command_ack_revision, data['command_revision'])
            update_fields.append('command_ack_revision')

        if 'wifi_revision' in data and data.get('wifi_status'):
            device.wifi_ack_revision = max(device.wifi_ack_revision, data['wifi_revision'])
            device.wifi_ack_status = data['wifi_status']
            update_fields.extend(['wifi_ack_revision', 'wifi_ack_status'])
            if data['wifi_status'] == 'success':
                device.wifi_ssid = data.get('wifi_ssid') or device.pending_wifi_ssid
                device.wifi_password = device.pending_wifi_password or device.wifi_password
                device.pending_wifi_ssid = ''
                device.pending_wifi_password = ''
                update_fields.extend(['wifi_ssid', 'wifi_password', 'pending_wifi_ssid', 'pending_wifi_password'])
                try:
                    assignment = device.assignment
                    assignment.wifi_ssid = device.wifi_ssid
                    assignment.wifi_password = device.wifi_password
                    assignment.save(update_fields=['wifi_ssid', 'wifi_password'])
                except DeviceAssignment.DoesNotExist:
                    pass

        if 'ultrasonic_revision' in data and data.get('ultrasonic_status'):
            device.ultrasonic_ack_revision = max(device.ultrasonic_ack_revision, data['ultrasonic_revision'])
            device.ultrasonic_ack_status = data['ultrasonic_status']
            update_fields.extend(['ultrasonic_ack_revision', 'ultrasonic_ack_status'])
            if data['ultrasonic_status'] == 'success':
                device.ultrasonic_config = device.pending_ultrasonic_config
                device.pending_ultrasonic_config = {}
                update_fields.extend(['ultrasonic_config', 'pending_ultrasonic_config'])

        device.save(update_fields=list(set(update_fields)))
        return Response({'ok': True})

class IoTHotspotWifiReportView(APIView):
    """ESP8266 setup hotspot reports shop WiFi captured from the customer phone."""
    authentication_classes = [DeviceTokenAuthentication]
    permission_classes = [AllowAny]

    def post(self, request, device_id):
        device = request.auth
        serializer = HotspotWifiReportSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        ssid = serializer.validated_data['ssid']
        password = serializer.validated_data['password']

        device.wifi_ssid = ssid
        device.wifi_password = password
        device.wifi_ack_status = 'success'
        device.pending_wifi_ssid = ''
        device.pending_wifi_password = ''
        device.last_seen = timezone.now()
        device.is_online = True
        update_fields = [
            'wifi_ssid', 'wifi_password', 'wifi_ack_status',
            'pending_wifi_ssid', 'pending_wifi_password',
            'last_seen', 'is_online',
        ]

        try:
            assignment = device.assignment
            assignment.wifi_ssid = ssid
            assignment.wifi_password = password
            assignment.save(update_fields=['wifi_ssid', 'wifi_password'])
        except DeviceAssignment.DoesNotExist:
            pass

        device.save(update_fields=update_fields)
        return Response({
            'ok': True,
            'ssid': ssid,
            'password': password,
            'message': 'WiFi saved from device hotspot',
        })
