import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { X, Zap, ZapOff, Camera, Loader2, AlertCircle } from 'lucide-react';
import { BrowserMultiFormatReader } from '@zxing/library';
import client from '../../api/client';
import { motion } from 'framer-motion';

const QRScanner = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [hasCamera, setHasCamera] = useState(true);
  const videoRef = useRef(null);
  const navigate = useNavigate();
  const reader = new BrowserMultiFormatReader();

  useEffect(() => {
    let controls;
    const startScanner = async () => {
      try {
        const videoInputDevices = await reader.listVideoInputDevices();
        if (videoInputDevices.length === 0) {
          setHasCamera(false);
          return;
        }

        controls = await reader.decodeFromVideoDevice(
          null, // use default
          videoRef.current,
          (result, err) => {
            if (result) {
              handleScan(result.getText());
            }
          }
        );
      } catch (err) {
        console.error(err);
        setHasCamera(false);
      }
    };

    startScanner();

    return () => {
      if (controls) controls.stop();
      reader.reset();
    };
  }, []);

  const handleScan = async (data) => {
    setLoading(true);
    setError('');

    let deviceId = null;
    try {
      console.log("Scanned Data:", data);
      
      // 1. Try to parse as JSON
      try {
        const qrData = JSON.parse(data);
        deviceId = qrData.device_id || qrData.id;
      } catch (e) {
        // 2. Try to extract ID from URL (e.g., https://.../INT-25)
        if (data.includes('/') && !data.endsWith('/')) {
           deviceId = data.split('/').pop().trim();
        } else if (data.includes('/') && data.endsWith('/')) {
           const parts = data.split('/').filter(p => p.length > 0);
           deviceId = parts[parts.length - 1];
        } else {
           // 3. Just use the raw string
           deviceId = data.trim();
        }
      }

      if (!deviceId) throw new Error("Invalid QR code");

      const response = await client.get(`/devices/verify/${deviceId}/`);
      
      if (response.data.status === 'assigned') {
        setError(`Device ${deviceId} is already assigned.`);
        setLoading(false);
      } else {
        navigate(`/sales/assign/${deviceId}?id=${response.data.id}`);
      }
    } catch (err) {
      console.error("Verification Error:", err);
      if (err.response?.status === 404) {
        setError(`Device "${deviceId}" not found in system.`);
      } else if (err.response?.status === 403 || err.response?.status === 401) {
        setError('Session expired. Please login again.');
      } else {
        setError('Network error: Is the backend tunnel still running?');
      }
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-black flex flex-col items-center justify-center p-4">
      <div className="absolute top-8 left-8">
        <button 
          onClick={() => navigate('/sales/dashboard')}
          className="p-4 bg-white/10 text-white rounded-full hover:bg-white/20 transition-colors"
        >
          <X size={24} />
        </button>
      </div>

      <div className="w-full max-w-lg relative">
        <div className="aspect-square bg-slate-900 rounded-[2.5rem] overflow-hidden border-4 border-white/20 relative">
          {!hasCamera ? (
            <div className="absolute inset-0 flex flex-col items-center justify-center p-8 text-center text-white">
              <AlertCircle size={48} className="text-rose-500 mb-4" />
              <h2 className="text-xl font-bold mb-2">Camera Not Found</h2>
              <p className="text-slate-400 mb-6">Please ensure you have a camera connected and permissions are granted.</p>
              <div className="w-full">
                <p className="text-sm text-slate-500 mb-2">Manual Entry Fallback:</p>
                <input 
                  type="text" 
                  placeholder="Enter Device ID"
                  className="w-full bg-white/10 border border-white/20 rounded-xl px-4 py-3 text-white outline-none focus:ring-2 focus:ring-indigo-500"
                  onKeyDown={(e) => e.key === 'Enter' && handleScan(e.target.value)}
                />
              </div>
            </div>
          ) : (
            <video 
              ref={videoRef} 
              className="w-full h-full object-cover"
            />
          )}

          {/* Scanner Overlay */}
          <div className="absolute inset-0 border-[60px] border-black/40 pointer-events-none">
             <div className="w-full h-full border-2 border-indigo-400 rounded-2xl relative">
                <div className="absolute inset-x-0 h-0.5 bg-indigo-400 top-1/2 -translate-y-1/2 animate-scan shadow-[0_0_15px_rgba(129,140,248,0.8)]"></div>
             </div>
          </div>
        </div>

        <div className="mt-12 text-center text-white">
          <h2 className="text-2xl font-bold mb-2">Scan Device QR</h2>
          <p className="text-slate-400">Position the QR code within the frame to verify device</p>
        </div>

        {loading && (
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm flex flex-col items-center justify-center rounded-[2.5rem]">
            <Loader2 className="text-indigo-500 animate-spin mb-4" size={48} />
            <p className="text-white font-bold">Verifying Device...</p>
          </div>
        )}

        {error && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-6 bg-rose-500/20 border border-rose-500/50 p-4 rounded-2xl text-rose-200 text-center font-medium"
          >
            {error}
          </motion.div>
        )}
      </div>

      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes scan {
          0% { top: 0%; }
          50% { top: 100%; }
          100% { top: 0%; }
        }
        .animate-scan {
          animation: scan 3s linear infinite;
          position: absolute;
        }
      `}} />
    </div>
  );
};

export default QRScanner;
