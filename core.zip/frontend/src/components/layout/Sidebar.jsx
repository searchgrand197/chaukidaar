import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  LayoutDashboard, 
  QrCode, 
  Tablet, 
  History, 
  CheckCircle, 
  Settings,
  ShieldCheck
} from 'lucide-react';
import clsx from 'clsx';

const menuItems = [
  { icon: LayoutDashboard, label: 'Dashboard', path: '/admin/dashboard' },
  { icon: QrCode, label: 'Generate QR', path: '/admin/generate' },
  { icon: Tablet, label: 'Devices', path: '/admin/devices' },
  { icon: History, label: 'Batch History', path: '/admin/batches' },
  { icon: ShieldCheck, label: 'Verify QR', path: '/admin/verify' },
];

const Sidebar = ({ isOpen, onClose }) => {
  return (
    <>
      {/* Mobile Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/50 z-40 lg:hidden backdrop-blur-sm"
          onClick={onClose}
        />
      )}

      <aside className={clsx(
        "fixed lg:static inset-y-0 left-0 w-64 bg-slate-900 text-white z-50 transform transition-transform duration-300 lg:translate-x-0",
        isOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="h-16 flex items-center px-6 border-b border-slate-800">
          <div className="w-8 h-8 bg-primary-500 rounded-lg flex items-center justify-center mr-3">
            <QrCode className="w-5 h-5 text-white" />
          </div>
          <span className="text-lg font-bold tracking-tight">INT Manager</span>
        </div>

        <nav className="p-4 space-y-2">
          {menuItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              onClick={onClose}
              className={({ isActive }) => clsx(
                "flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group",
                isActive 
                  ? "bg-primary-600 text-white shadow-lg shadow-primary-900/20" 
                  : "text-slate-400 hover:bg-slate-800 hover:text-white"
              )}
            >
              <item.icon className={clsx(
                "w-5 h-5 transition-colors",
                "group-hover:text-white"
              )} />
              <span className="font-medium">{item.label}</span>
            </NavLink>
          ))}
          <div className="pt-4 mt-4 border-t border-slate-800">
            <NavLink
              to="/"
              className="flex items-center gap-3 px-4 py-3 rounded-xl text-slate-400 hover:bg-slate-800 hover:text-white transition-all"
            >
              <LayoutDashboard className="w-5 h-5" />
              <span className="font-medium">Back to Selection</span>
            </NavLink>
          </div>
        </nav>

        <div className="absolute bottom-0 w-full p-4 border-t border-slate-800">
          <div className="bg-slate-800/50 rounded-xl p-4">
            <p className="text-xs text-slate-500 mb-2 uppercase font-bold tracking-wider">System Status</p>
            <div className="flex items-center gap-2 text-xs text-green-400">
              <CheckCircle className="w-3 h-3" />
              <span>Production Ready</span>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;
