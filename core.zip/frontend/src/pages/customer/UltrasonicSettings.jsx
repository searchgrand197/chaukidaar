import { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, Loader2, Radar, RotateCcw } from 'lucide-react';
import toast from 'react-hot-toast';
import { customerDeviceService } from '../../api/services';

const UltrasonicSettings = () => {
  const { deviceId } = useParams();
  const navigate = useNavigate();
  const [form, setForm] = useState({
    ignore_percent: 0.1,
    min_intrusion_cm: 30,
    recalibrate: false,
  });
  const [saving, setSaving] = useState(false);

  const saveConfig = async (event) => {
    event.preventDefault();
    setSaving(true);
    try {
      await customerDeviceService.updateUltrasonicConfig(deviceId, {
        ignore_percent: Number(form.ignore_percent),
        min_intrusion_cm: Number(form.min_intrusion_cm),
        recalibrate: form.recalibrate,
      });
      toast.success('Sensor update queued');
      navigate(`/customer/device/${deviceId}`);
    } catch {
      toast.error('Could not queue sensor update');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 p-5">
      <button onClick={() => navigate(`/customer/device/${deviceId}`)} className="flex items-center gap-2 text-slate-500 font-bold mb-6">
        <ArrowLeft size={20} /> Back
      </button>

      <h1 className="text-3xl font-black text-slate-900">Ultrasonic Sensor</h1>
      <p className="text-slate-500 mt-1">Adjust movement sensitivity and recalibrate the baseline.</p>

      <form onSubmit={saveConfig} className="bg-white rounded-[2rem] p-5 border border-slate-100 mt-6 space-y-5">
        <label className="block">
          <span className="text-sm font-bold text-slate-500">Ignore Percent</span>
          <input
            type="number"
            step="0.01"
            min="0.01"
            max="0.9"
            className="w-full bg-slate-50 rounded-2xl px-4 py-4 font-bold outline-none mt-2"
            value={form.ignore_percent}
            onChange={(e) => setForm({ ...form, ignore_percent: e.target.value })}
          />
        </label>
        <label className="block">
          <span className="text-sm font-bold text-slate-500">Minimum Intrusion Distance (cm)</span>
          <input
            type="number"
            min="1"
            max="400"
            className="w-full bg-slate-50 rounded-2xl px-4 py-4 font-bold outline-none mt-2"
            value={form.min_intrusion_cm}
            onChange={(e) => setForm({ ...form, min_intrusion_cm: e.target.value })}
          />
        </label>
        <label className="flex items-center gap-3 p-4 rounded-2xl bg-slate-50 font-bold">
          <input type="checkbox" checked={form.recalibrate} onChange={(e) => setForm({ ...form, recalibrate: e.target.checked })} />
          <RotateCcw size={18} />
          Recalibrate after update
        </label>
        <button disabled={saving} className="w-full bg-indigo-600 text-white py-4 rounded-2xl font-black flex items-center justify-center gap-2">
          {saving ? <Loader2 className="animate-spin" /> : <Radar />}
          Queue Sensor Update
        </button>
      </form>
    </div>
  );
};

export default UltrasonicSettings;
