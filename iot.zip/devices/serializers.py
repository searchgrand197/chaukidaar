from rest_framework import serializers
from .models import Device, DeviceAssignment, Batch, DeviceSchedule, SensorReading
from accounts.models import User
from accounts.serializers import UserSerializer
import secrets
import string
import re


def generate_portal_password(length=8):
    alphabet = string.ascii_letters + string.digits
    return ''.join(secrets.choice(alphabet) for _ in range(length))


def unique_customer_username(phone, device_id):
    digits = re.sub(r'\D', '', phone or '')[-10:]
    base = f"c{digits}" if len(digits) >= 8 else f"shop_{device_id[-6:].lower()}"
    username = base
    suffix = 1
    while User.objects.filter(username=username).exists():
        username = f"{base}{suffix}"
        suffix += 1
    return username


class DeviceSerializer(serializers.ModelSerializer):
    assignment = serializers.SerializerMethodField()
    
    class Meta:
        model = Device
        fields = [
            'id', 'device_id', 'sequence_number', 'qr_image', 'status',
            'desired_power_state', 'is_armed', 'is_online', 'last_seen',
            'last_temperature', 'last_ultrasonic_distance', 'firmware_version',
            'wifi_ssid', 'ultrasonic_config', 'created_at', 'assignment',
        ]
    
    def get_assignment(self, obj):
        try:
            # We use a nested serializer to get shop_name, owner_name, etc.
            return DeviceAssignmentSerializer(obj.assignment).data
        except DeviceAssignment.DoesNotExist:
            return None

class DeviceAssignmentSerializer(serializers.ModelSerializer):
    assigned_by_details = UserSerializer(source='assigned_by', read_only=True)
    device_id_str = serializers.CharField(source='device.device_id', read_only=True)
    customer_username = serializers.CharField(write_only=True, required=False, allow_blank=True)
    customer_password = serializers.CharField(write_only=True, required=False, allow_blank=True)
    customer_email = serializers.EmailField(write_only=True, required=False, allow_blank=True)
    # Readable by salesman after assign / in history
    portal_username = serializers.SerializerMethodField()
    portal_password = serializers.CharField(read_only=True)

    class Meta:
        model = DeviceAssignment
        fields = '__all__'
        read_only_fields = ('assigned_by', 'assigned_at', 'portal_password')

    def get_portal_username(self, obj):
        if obj.customer_id:
            return obj.customer.username
        return ''

    def validate_device(self, value):
        if value.status == 'assigned':
            raise serializers.ValidationError("Device already assigned")
        return value

    def create(self, validated_data):
        customer_username = validated_data.pop('customer_username', '').strip()
        customer_password = validated_data.pop('customer_password', '').strip()
        customer_email = validated_data.pop('customer_email', '').strip()
        device = validated_data['device']

        # Always ensure a customer portal account exists for this shop assignment
        if not customer_username:
            customer_username = unique_customer_username(
                validated_data.get('phone', ''),
                device.device_id,
            )
        if not customer_password:
            customer_password = generate_portal_password()

        customer, created = User.objects.get_or_create(
            username=customer_username,
            defaults={
                'email': customer_email,
                'role': 'customer',
                'phone': validated_data.get('phone') or '',
            },
        )
        if created:
            customer.set_password(customer_password)
            customer.role = 'customer'
            if validated_data.get('phone'):
                customer.phone = validated_data['phone']
            customer.save()
        else:
            # Existing username: rotate password so salesman/customer get a known login
            customer.set_password(customer_password)
            if customer.role != 'customer':
                customer.role = 'customer'
            customer.save(update_fields=['password', 'role'])

        validated_data['customer'] = customer
        validated_data['portal_password'] = customer_password

        assignment = super().create(validated_data)
        device.status = 'assigned'
        device.customer = customer
        if assignment.wifi_ssid:
            device.wifi_ssid = assignment.wifi_ssid
        if assignment.wifi_password:
            device.wifi_password = assignment.wifi_password
        device.save()
        return assignment

class CustomerDeviceSerializer(serializers.ModelSerializer):
    assignment = DeviceAssignmentSerializer(read_only=True)

    class Meta:
        model = Device
        fields = [
            'id', 'device_id', 'status', 'desired_power_state', 'is_armed',
            'is_online', 'last_seen', 'last_temperature',
            'last_ultrasonic_distance', 'firmware_version', 'wifi_ssid', 'wifi_password',
            'ultrasonic_config', 'assignment',
        ]

class DeviceScheduleSerializer(serializers.ModelSerializer):
    class Meta:
        model = DeviceSchedule
        fields = ['id', 'name', 'start_time', 'end_time', 'weekdays', 'enabled']

class SensorReadingSerializer(serializers.ModelSerializer):
    class Meta:
        model = SensorReading
        fields = ['id', 'temperature', 'ultrasonic_distance', 'heat_alarm', 'status', 'created_at']

class PowerControlSerializer(serializers.Serializer):
    enabled = serializers.BooleanField()

class HotspotWifiReportSerializer(serializers.Serializer):
    ssid = serializers.CharField(max_length=100)
    password = serializers.CharField(max_length=100)

class WifiConfigSerializer(serializers.Serializer):
    ssid = serializers.CharField(max_length=100)
    password = serializers.CharField(max_length=100, write_only=True)

class UltrasonicConfigSerializer(serializers.Serializer):
    ignore_percent = serializers.FloatField(required=False, min_value=0.01, max_value=0.9)
    min_intrusion_cm = serializers.IntegerField(required=False, min_value=1, max_value=400)
    recalibrate = serializers.BooleanField(required=False, default=False)

    def validate(self, attrs):
        if not attrs:
            raise serializers.ValidationError('At least one ultrasonic setting is required.')
        return attrs

class AlertPhoneSerializer(serializers.Serializer):
    phone = serializers.CharField(max_length=15)
    alternate_phone = serializers.CharField(max_length=15, required=False, allow_blank=True)

    def validate_phone(self, value):
        digits = ''.join(c for c in value if c.isdigit())
        if len(digits) != 10:
            raise serializers.ValidationError('Phone must be 10 digits.')
        return digits

    def validate_alternate_phone(self, value):
        if not value:
            return ''
        digits = ''.join(c for c in value if c.isdigit())
        if len(digits) != 10:
            raise serializers.ValidationError('Alternate phone must be 10 digits.')
        return digits

class TelemetrySerializer(serializers.Serializer):
    temperature = serializers.DecimalField(max_digits=6, decimal_places=2, required=False, allow_null=True)
    ultrasonic_distance = serializers.DecimalField(max_digits=7, decimal_places=2, required=False, allow_null=True)
    heat_alarm = serializers.BooleanField(required=False, default=False)
    status = serializers.CharField(max_length=20, required=False, allow_blank=True)
    armed = serializers.BooleanField(required=False)
    online = serializers.BooleanField(required=False, default=True)
    firmware_version = serializers.CharField(max_length=50, required=False, allow_blank=True)

class CommandAckSerializer(serializers.Serializer):
    command_revision = serializers.IntegerField(required=False, min_value=0)
    wifi_revision = serializers.IntegerField(required=False, min_value=0)
    wifi_status = serializers.ChoiceField(choices=['success', 'failed'], required=False)
    wifi_ssid = serializers.CharField(max_length=100, required=False, allow_blank=True)
    ultrasonic_revision = serializers.IntegerField(required=False, min_value=0)
    ultrasonic_status = serializers.ChoiceField(choices=['success', 'failed'], required=False)

class BatchSerializer(serializers.ModelSerializer):
    pdf_url = serializers.SerializerMethodField()
    excel_url = serializers.SerializerMethodField()

    class Meta:
        model = Batch
        fields = [
            'batch_number',
            'count',
            'created_at',
            'pdf_file',
            'pdf_url',
            'excel_file',
            'excel_url',
        ]

    def get_pdf_url(self, obj):
        if obj.pdf_file:
            request = self.context.get('request')
            if request:
                return request.build_absolute_uri(obj.pdf_file.url)
            return obj.pdf_file.url
        return None

    def get_excel_url(self, obj):
        if obj.excel_file:
            request = self.context.get('request')
            if request:
                return request.build_absolute_uri(obj.excel_file.url)
            return obj.excel_file.url
        return None

class GenerateBatchSerializer(serializers.Serializer):
    count = serializers.IntegerField(min_value=1, max_value=280)
