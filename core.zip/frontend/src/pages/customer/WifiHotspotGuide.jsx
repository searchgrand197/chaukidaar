import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, ExternalLink, Loader2, Wifi, KeyRound, Trash2 } from 'lucide-react';
import toast from 'react-hot-toast';
import { customerDeviceService } from '../../api/services';

const WifiHotspotGuide = ({ mode }) => {
  const { deviceId } = useParams();
  const navigate = useNavigate();
  const [info, setInfo] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ ssid: '', password: '' });
  const [showHotspotSteps, setShowHotspotSteps] = useState(false);
  const isForget = mode === 'forget';

  useEffect(() => {
    const load = async () => {
      try {
        const response = await customerDeviceService.getWifiSetupInfo(deviceId);
        setInfo(response.data);
        if (isForget) {
          await customerDeviceService.requestWifiForget(deviceId);
          setForm({ ssid: '', password: '' });
        } else {
          setForm({
            ssid: response.data.current_wifi_ssid || '',
            password: '',
          });
        }
      } catch {
        toast.error('Could not load WiFi setup info');
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [deviceId, isForget]);

  const portalDeviceUrl = info
    ? `${info.portal_url}${isForget ? '?mode=forget' : ''}`
    : 'http://192.168.4.1';

  const saveViaApp = async (event) => {
    event.preventDefault();
    if (!form.ssid.trim() || !form.password) {
      toast.error('Enter WiFi name and password');
      return;
    }
    setSaving(true);
    try {
      if (isForget) {
        await customerDeviceService.requestWifiForget(deviceId);
      }
      await customerDeviceService.updateWifi(deviceId, {
        ssid: form.ssid.trim(),
        password: form.password,
      });
      toast.success(
        isForget
          ? 'New WiFi queued — device applies when online, or save on device hotspot below'
          : 'WiFi update queued for device'
      );
      navigate(`/customer/device/${deviceId}`);
    } catch {
      toast.error('Could not save WiFi — try the on-device portal below');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <Loader2 className="animate-spin text-indigo-600" size={40} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 p-5">
      <button
        type="button"
        onClick={() => navigate(`/customer/device/${deviceId}/wifi`)}
        className="flex items-center gap-2 text-slate-500 font-bold mb-6"
      >
        <ArrowLeft size={20} /> Back
      </button>

      <div className={`rounded-[2rem] p-6 text-white ${isForget ? 'bg-rose-600' : 'bg-indigo-600'}`}>
        {isForget ? <Trash2 size={36} /> : <KeyRound size={36} />}
        <h1 className="text-3xl font-black mt-4">
          {isForget ? 'Forget WiFi password' : 'Change WiFi password'}
        </h1>
        <p className="mt-2 opacity-90 text-sm leading-relaxed">
          {isForget
            ? 'Set new shop WiFi below. Old credentials are cleared when you save on the device.'
            : 'Update shop WiFi below. Network name may stay the same — only change the password if needed.'}
        </p>
      </div>

      {/* In-app setup portal (same fields as ESP 192.168.4.1 page) */}
      <div className="bg-slate-900 text-white rounded-[2rem] p-5 mt-6 shadow-xl border border-slate-800">
        <h2 className="font-black text-lg flex items-center gap-2">
          <Wifi size={22} className="text-indigo-400" />
          Shop WiFi setup
        </h2>
        <p className="text-slate-400 text-sm mt-2 leading-relaxed">
          {isForget
            ? 'Enter the new network the device should use (forgets old password on device when saved there).'
            : 'Enter updated WiFi details. Same form as the device setup page.'}
        </p>

        <form onSubmit={saveViaApp} className="mt-5 space-y-3">
          <input
            className="w-full bg-slate-800 text-white rounded-2xl px-4 py-4 font-bold outline-none focus:ring-2 focus:ring-indigo-500 placeholder:text-slate-500"
            placeholder="WiFi name (SSID)"
            value={form.ssid}
            onChange={(e) => setForm({ ...form, ssid: e.target.value })}
            required
            autoComplete="off"
          />
          <input
            className="w-full bg-slate-800 text-white rounded-2xl px-4 py-4 font-bold outline-none focus:ring-2 focus:ring-indigo-500 placeholder:text-slate-500"
            placeholder="WiFi password"
            type="password"
            value={form.password}
            onChange={(e) => setForm({ ...form, password: e.target.value })}
            required
            autoComplete="new-password"
          />
          <button
            type="submit"
            disabled={saving}
            className={`w-full py-4 rounded-2xl font-black flex items-center justify-center gap-2 ${
              isForget ? 'bg-rose-500 hover:bg-rose-400' : 'bg-indigo-500 hover:bg-indigo-400'
            }`}
          >
            {saving ? <Loader2 className="animate-spin" size={22} /> : <Wifi size={22} />}
            Save and send to device
          </button>
        </form>
      </div>

      {/* On-device portal: iframe when user has joined device hotspot */}
      <div className="bg-white rounded-[2rem] p-5 border border-slate-100 mt-5">
        <h2 className="font-black text-slate-900">On-device setup portal</h2>
        <p className="text-sm text-slate-500 mt-2 leading-relaxed">
          Next to the sensor: join WiFi <span className="font-bold text-slate-800">{info?.ap_ssid}</span> (password{' '}
          <span className="font-bold text-slate-800">{info?.ap_password}</span>), then use the portal below or open it in your browser.
        </p>

        <a
          href={portalDeviceUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="mt-4 w-full flex items-center justify-center gap-2 py-3 rounded-2xl border-2 border-indigo-200 text-indigo-700 font-bold text-sm"
        >
          <ExternalLink size={18} />
          Open {portalDeviceUrl}
        </a>

        <p className="text-xs text-slate-400 mt-3 text-center">
          Join the device hotspot first — this page only loads when your phone is on that network.
        </p>

        <div className="mt-4 rounded-2xl overflow-hidden border border-slate-200 bg-slate-100">
          <iframe
            title="Device WiFi setup portal"
            src={portalDeviceUrl}
            className="w-full h-[min(420px,55vh)] bg-white"
          />
        </div>
      </div>

      <button
        type="button"
        onClick={() => setShowHotspotSteps(!showHotspotSteps)}
        className="w-full mt-4 text-sm font-bold text-slate-500"
      >
        {showHotspotSteps ? 'Hide' : 'Show'} step-by-step hotspot guide
      </button>

      {showHotspotSteps && (
        <div className="bg-white rounded-[2rem] p-5 border border-slate-100 mt-3">
          <ol className="space-y-3 list-decimal list-inside text-slate-700 text-sm leading-relaxed">
            <li>Power-cycle the device (unplug 5s, plug back in).</li>
            <li>Wait ~1 minute for hotspot {info?.ap_ssid}.</li>
            <li>On phone WiFi, join {info?.ap_ssid} / {info?.ap_password}.</li>
            <li>Use the portal above or open {portalDeviceUrl}.</li>
            <li>Enter shop WiFi and tap Save — device reboots.</li>
          </ol>
        </div>
      )}
    </div>
  );
};

export default WifiHotspotGuide;

