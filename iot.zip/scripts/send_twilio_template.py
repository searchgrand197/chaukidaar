#!/usr/bin/env python3
"""
Send an SMS/WhatsApp message via Twilio using a Content Template (ContentSid).

Template body (HXe026663b5f1c1d78f976f29557b3ead1):
  Hi {{first_name}}, please confirm your appointment with us on {{date}} {{time}}.
  We are looking forward to seeing you.

Usage (PowerShell):
  $env:TWILIO_ACCOUNT_SID = "ACxxxxxxxx"
  $env:TWILIO_AUTH_TOKEN = "your_auth_token"
  python scripts/send_twilio_template.py --appointment `
    --first-name "Raj" --date "May 16, 2026" --time "3:00 PM"

Or raw JSON (--vars must be one argument; in PowerShell prefer --appointment):
  python scripts/send_twilio_template.py --vars "{""first_name"":""Raj"",""date"":""May 16"",""time"":""3 PM""}"

Requires: Python 3.9+ (stdlib only).
"""

from __future__ import annotations

import argparse
import base64
import json
import os
import sys
from urllib.error import HTTPError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

# Template HXe026... is WhatsApp quick-reply — use whatsapp: prefix
DEFAULT_FROM = "whatsapp:+12694154269"
DEFAULT_TO = "whatsapp:+917027547926"
DEFAULT_CONTENT_SID = "HXe026663b5f1c1d78f976f29557b3ead1"


def load_dotenv() -> None:
    """Load .env from repo root if present (optional, no extra package)."""
    root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    env_path = os.path.join(root, ".env")
    if not os.path.isfile(env_path):
        return
    with open(env_path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, value = line.partition("=")
            key = key.strip()
            value = value.strip().strip('"').strip("'")
            os.environ.setdefault(key, value)


def send_template_message(
    account_sid: str,
    auth_token: str,
    from_number: str,
    to_number: str,
    content_sid: str,
    content_variables: dict | None = None,
) -> dict:
    url = f"https://api.twilio.com/2010-04-01/Accounts/{account_sid}/Messages.json"

    payload = {
        "From": from_number,
        "To": to_number,
        "ContentSid": content_sid,
        "ContentVariables": json.dumps(content_variables or {}),
    }

    body = urlencode(payload).encode("utf-8")
    credentials = base64.b64encode(f"{account_sid}:{auth_token}".encode()).decode()

    req = Request(url, data=body, method="POST")
    req.add_header("Authorization", f"Basic {credentials}")
    req.add_header("Content-Type", "application/x-www-form-urlencoded")

    with urlopen(req, timeout=30) as resp:
        return json.loads(resp.read().decode("utf-8"))


def parse_vars(raw: str) -> dict:
    if not raw or raw.strip() in ("", "{}"):
        return {}
    try:
        data = json.loads(raw)
    except json.JSONDecodeError as e:
        raise SystemExit(f"Invalid --vars JSON: {e}") from e
    if not isinstance(data, dict):
        raise SystemExit("--vars must be a JSON object")
    return data


def appointment_variables(first_name: str, date: str, time: str) -> dict:
    """Variables for: Hi {{first_name}} ... on {{date}} {{time}}."""
    missing = [k for k, v in (("first_name", first_name), ("date", date), ("time", time)) if not str(v).strip()]
    if missing:
        raise SystemExit(f"Missing appointment field(s): {', '.join(missing)}")
    return {
        "first_name": first_name.strip(),
        "date": date.strip(),
        "time": time.strip(),
    }


def main() -> int:
    load_dotenv()

    parser = argparse.ArgumentParser(description="Send Twilio Content Template message")
    parser.add_argument("--account-sid", default=os.environ.get("TWILIO_ACCOUNT_SID"))
    parser.add_argument("--auth-token", default=os.environ.get("TWILIO_AUTH_TOKEN"))
    parser.add_argument("--from", dest="from_number", default=os.environ.get("TWILIO_FROM", DEFAULT_FROM))
    parser.add_argument("--to", dest="to_number", default=os.environ.get("TWILIO_TO", DEFAULT_TO))
    parser.add_argument(
        "--content-sid",
        default=os.environ.get("TWILIO_CONTENT_SID", DEFAULT_CONTENT_SID),
        help="Content Template SID (HX...)",
    )
    parser.add_argument(
        "--vars",
        default=os.environ.get("TWILIO_CONTENT_VARIABLES"),
        help="Template variables as JSON object (optional if --appointment is used)",
    )
    parser.add_argument(
        "--appointment",
        action="store_true",
        help="Send appointment confirmation template (first_name, date, time)",
    )
    parser.add_argument("--first-name", default=os.environ.get("TWILIO_FIRST_NAME", ""))
    parser.add_argument("--date", default=os.environ.get("TWILIO_APPT_DATE", ""))
    parser.add_argument("--time", default=os.environ.get("TWILIO_APPT_TIME", ""))
    args = parser.parse_args()

    if not args.account_sid or not args.auth_token:
        print(
            "Set TWILIO_ACCOUNT_SID and TWILIO_AUTH_TOKEN env vars, or pass --account-sid / --auth-token.",
            file=sys.stderr,
        )
        return 1

    if args.appointment or args.first_name or args.date or args.time:
        content_variables = appointment_variables(args.first_name, args.date, args.time)
    elif args.vars:
        content_variables = parse_vars(args.vars)
    else:
        raise SystemExit(
            "Provide --appointment with --first-name, --date, --time, or pass --vars JSON."
        )

    print(f"From:        {args.from_number}")
    print(f"To:          {args.to_number}")
    print(f"ContentSid:  {args.content_sid}")
    print(f"Variables:   {content_variables or '(none)'}")
    print("Sending...")

    try:
        result = send_template_message(
            account_sid=args.account_sid,
            auth_token=args.auth_token,
            from_number=args.from_number,
            to_number=args.to_number,
            content_sid=args.content_sid,
            content_variables=content_variables,
        )
    except HTTPError as e:
        err_body = e.read().decode("utf-8", errors="replace")
        print(f"Twilio HTTP {e.code}:", err_body, file=sys.stderr)
        return 1
    except OSError as e:
        print(f"Network error: {e}", file=sys.stderr)
        return 1

    print("Success.")
    print(json.dumps(result, indent=2))
    print(f"Message SID: {result.get('sid', '(unknown)')}")
    print(f"Status:      {result.get('status', '(unknown)')}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
