import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, Clock, Loader2, Plus, Trash2 } from 'lucide-react';
import toast from 'react-hot-toast';
import { customerDeviceService } from '../../api/services';

const Schedule = () => {
  const { deviceId } = useParams();
  const navigate = useNavigate();
  const [schedules, setSchedules] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    name: 'Daily security',
    start_time: '18:00',
    end_time: '06:00',
    weekdays: '0,1,2,3,4,5,6',
    enabled: true,
  });

  useEffect(() => {
    const loadSchedules = async () => {
      try {
        const response = await customerDeviceService.schedules(deviceId);
        setSchedules(response.data || []);
      } finally {
        setLoading(false);
      }
    };
    loadSchedules();
  }, [deviceId]);

  const refreshSchedules = async () => {
    const response = await customerDeviceService.schedules(deviceId);
    setSchedules(response.data || []);
  };

  const removeSchedule = async (scheduleId) => {
    if (!window.confirm('Remove this schedule? The device will follow app power only.')) return;
    setSaving(true);
    try {
      await customerDeviceService.deleteSchedule(deviceId, scheduleId);
      toast.success('Schedule removed');
      await refreshSchedules();
    } catch {
      toast.error('Could not remove schedule');
    } finally {
      setSaving(false);
    }
  };

  const saveSchedule = async (event) => {
    event.preventDefault();
    setSaving(true);
    try {
      await customerDeviceService.saveSchedule(deviceId, form);
      toast.success('Schedule saved');
      await refreshSchedules();
    } catch {
      toast.error('Could not save schedule');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 p-5">
      <button onClick={() => navigate(`/customer/device/${deviceId}`)} className="flex items-center gap-2 text-slate-500 font-bold mb-6">
        <ArrowLeft size={20} /> Back
      </button>

      <h1 className="text-3xl font-black text-slate-900">On/Off Schedule</h1>
      <p className="text-slate-500 mt-1">When a schedule is enabled, the device only arms inside your On–Off window (Asia/Kolkata). Example: On 18:00, Off 06:00 means active overnight and off from 06:00–18:00.</p>

      <form onSubmit={saveSchedule} className="bg-white rounded-[2rem] p-5 border border-slate-100 mt-6 space-y-4">
        <input className="w-full bg-slate-50 rounded-2xl px-4 py-4 font-bold outline-none" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
        <div className="grid grid-cols-2 gap-3">
          <label className="space-y-1">
            <span className="text-xs font-bold text-slate-500">On Time</span>
            <input type="time" className="w-full bg-slate-50 rounded-2xl px-4 py-4 font-bold outline-none" value={form.start_time} onChange={(e) => setForm({ ...form, start_time: e.target.value })} />
          </label>
          <label className="space-y-1">
            <span className="text-xs font-bold text-slate-500">Off Time</span>
            <input type="time" className="w-full bg-slate-50 rounded-2xl px-4 py-4 font-bold outline-none" value={form.end_time} onChange={(e) => setForm({ ...form, end_time: e.target.value })} />
          </label>
        </div>
        <label className="flex items-center gap-3 font-bold">
          <input type="checkbox" checked={form.enabled} onChange={(e) => setForm({ ...form, enabled: e.target.checked })} />
          Enabled
        </label>
        <button disabled={saving} className="w-full bg-indigo-600 text-white py-4 rounded-2xl font-black flex items-center justify-center gap-2">
          {saving ? <Loader2 className="animate-spin" /> : <Plus />}
          Add Schedule
        </button>
      </form>

      <div className="mt-6 space-y-3">
        {loading ? <Loader2 className="animate-spin text-indigo-600" /> : schedules.map((schedule) => (
          <div key={schedule.id} className="bg-white rounded-2xl p-4 border border-slate-100 flex items-center gap-3 justify-between">
            <div className="flex items-center gap-3 min-w-0">
              <Clock className="text-indigo-600 shrink-0" />
              <div className="min-w-0">
                <p className="font-black">{schedule.name}</p>
                <p className="text-sm text-slate-500">{schedule.start_time} to {schedule.end_time} · {schedule.enabled ? 'Enabled' : 'Disabled'}</p>
              </div>
            </div>
            <button type="button" disabled={saving} onClick={() => removeSchedule(schedule.id)} className="shrink-0 p-3 rounded-2xl bg-rose-50 text-rose-600 font-bold" aria-label="Delete schedule">
              <Trash2 size={20} />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Schedule;
