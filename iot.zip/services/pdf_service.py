from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
import os
from django.conf import settings
from datetime import datetime

def generate_labels_pdf(devices, batch_id):
    filename = f"batch_{batch_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
    filepath = os.path.join(settings.MEDIA_ROOT, 'batches', filename)
    os.makedirs(os.path.dirname(filepath), exist_ok=True)

    c = canvas.Canvas(filepath, pagesize=A4)
    width, height = A4

    # Label dimensions (approx 48mm x 32mm)
    label_w = 48 * mm
    label_h = 32 * mm
    
    # Grid: 4 columns, 7 rows = 28 per page
    cols = 4
    rows = 7
    
    # Margins (A4 is 210 x 297 mm)
    margin_x = (width - (cols * label_w)) / 2
    margin_y = (height - (rows * label_h)) / 2

    idx = 0
    for i, device in enumerate(devices):
        if i > 0 and i % 28 == 0:
            c.showPage()
            idx = 0
            
        row = idx // cols
        col = idx % cols
        idx += 1

        x = margin_x + (col * label_w)
        y = height - margin_y - ((row + 1) * label_h)

        # Draw cutting lines (dashed)
        c.setDash(1, 2)
        c.setLineWidth(0.1)
        c.rect(x, y, label_w, label_h)
        c.setDash([]) # Reset dash

        # QR Code Image
        if device.qr_image:
            qr_path = device.qr_image.path
            qr_size = 20 * mm
            # Center QR horizontally and vertically
            qr_x = x + (label_w - qr_size) / 2
            qr_y = y + 6 * mm
            c.drawImage(qr_path, qr_x, qr_y, width=qr_size, height=qr_size)

        # Top Text: INT-1, INT-2, etc.
        c.setFont("Helvetica-Bold", 16)
        c.drawCentredString(x + label_w/2, y + 26 * mm, f"INT-{device.sequence_number}")
        
        # Bottom Text: Full Serial Format (26E11000030)
        c.setFont("Helvetica-Bold", 10)
        c.drawCentredString(x + label_w/2, y + 4 * mm, device.device_id)

    c.save()
    return filename

def get_pdf_url(filename):
    return f"{settings.MEDIA_URL}batches/{filename}"
