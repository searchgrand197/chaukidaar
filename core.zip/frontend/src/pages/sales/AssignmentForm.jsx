import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, useSearchParams } from 'react-router-dom';
import { Home, User, Phone, MapPin, Map, CheckCircle, Info, ArrowLeft, Camera, Loader2 } from 'lucide-react';
import client from '../../api/client';
import { motion } from 'framer-motion';

const InputField = ({ label, icon: Icon, placeholder, value, onChange, type = "text", editable = true, required = false }) => (
  <div className="space-y-1.5">
    <label className="flex items-center text-sm font-bold text-slate-700 ml-1">
      {label}
      {required && <span className="text-rose-500 ml-1">*</span>}
    </label>
    <div className={`relative flex items-center group transition-all`}>
      <div className="absolute left-4 text-slate-400 group-focus-within:text-indigo-600">
        <Icon size={18} />
      </div>
      <input 
        type={type}
        placeholder={placeholder}
        value={value}
        onChange={onChange}
        disabled={!editable}
        className={`w-full pl-12 pr-4 py-4 rounded-2xl border ${editable ? 'bg-white border-slate-200 focus:ring-2 focus:ring-indigo-600 focus:border-transparent outline-none' : 'bg-slate-100 border-slate-200 text-slate-500 cursor-not-allowed'} transition-all font-medium`}
      />
    </div>
  </div>
);

const SelectField = ({ label, icon: Icon, options, value, onChange, required = false, disabled = false }) => (
  <div className="space-y-1.5">
    <label className="flex items-center text-sm font-bold text-slate-700 ml-1">
      {label}
      {required && <span className="text-rose-500 ml-1">*</span>}
    </label>
    <div className="relative flex items-center group transition-all">
      <div className="absolute left-4 text-slate-400 group-focus-within:text-indigo-600">
        <Icon size={18} />
      </div>
      <select 
        value={value}
        onChange={onChange}
        disabled={disabled}
        className="w-full pl-12 pr-4 py-4 rounded-2xl border bg-white border-slate-200 focus:ring-2 focus:ring-indigo-600 focus:border-transparent outline-none transition-all font-medium appearance-none"
      >
        <option value="">Select {label}</option>
        {options.map((opt) => (
          <option key={opt} value={opt}>{opt}</option>
        ))}
      </select>
      <div className="absolute right-4 pointer-events-none text-slate-400">
        <Map size={16} />
      </div>
    </div>
  </div>
);

const stateCityData = {
  "Andhra Pradesh": ["Visakhapatnam", "Vijayawada", "Guntur", "Nellore", "Kurnool", "Tirupati"],
  "Arunachal Pradesh": ["Itanagar", "Tawang", "Ziro", "Pasighat"],
  "Assam": ["Guwahati", "Dibrugarh", "Silchar", "Jorhat", "Tezpur"],
  "Bihar": ["Patna", "Gaya", "Bhagalpur", "Muzaffarpur", "Purnia"],
  "Chhattisgarh": ["Raipur", "Bhilai", "Bilaspur", "Korba", "Durg"],
  "Goa": ["Panaji", "Margao", "Vasco da Gama", "Mapusa"],
  "Gujarat": ["Ahmedabad", "Surat", "Vadodara", "Rajkot", "Bhavnagar", "Jamnagar"],
  "Haryana": ["Ambala", "Bhiwani", "Charkhi Dadri", "Faridabad", "Fatehabad", "Gurugram", "Hisar", "Jhajjar", "Jind", "Kaithal", "Karnal", "Kurukshetra", "Mahendragarh", "Nuh", "Palwal", "Panchkula", "Panipat", "Rewari", "Rohtak", "Sirsa", "Sonipat", "Yamunanagar"],
  "Himachal Pradesh": ["Shimla", "Dharamshala", "Solan", "Mandi", "Kullu"],
  "Jharkhand": ["Ranchi", "Jamshedpur", "Dhanbad", "Bokaro", "Deoghar"],
  "Karnataka": ["Bengaluru", "Mysuru", "Hubballi", "Mangaluru", "Belagavi", "Kalaburagi"],
  "Kerala": ["Thiruvananthapuram", "Kochi", "Kozhikode", "Thrissur", "Kollam", "Palakkad"],
  "Madhya Pradesh": ["Bhopal", "Indore", "Gwalior", "Jabalpur", "Ujjain", "Sagar"],
  "Maharashtra": ["Mumbai", "Pune", "Nagpur", "Thane", "Nashik", "Aurangabad", "Solapur"],
  "Manipur": ["Imphal", "Churachandpur", "Thoubal"],
  "Meghalaya": ["Shillong", "Tura", "Jowai"],
  "Mizoram": ["Aizawl", "Lunglei", "Champhai"],
  "Nagaland": ["Kohima", "Dimapur", "Mokokchung"],
  "Odisha": ["Bhubaneswar", "Cuttack", "Rourkela", "Berhampur", "Sambalpur"],
  "Punjab": ["Ludhiana", "Amritsar", "Jalandhar", "Patiala", "Bathinda", "Mohali"],
  "Rajasthan": ["Jaipur", "Jodhpur", "Udaipur", "Kota", "Bikaner", "Ajmer"],
  "Sikkim": ["Gangtok", "Namchi", "Geyzing"],
  "Tamil Nadu": ["Chennai", "Coimbatore", "Madurai", "Tiruchirappalli", "Salem", "Tirunelveli"],
  "Telangana": ["Hyderabad", "Warangal", "Nizamabad", "Karimnagar", "Khammam"],
  "Tripura": ["Agartala", "Udaipur", "Dharmanagar"],
  "Uttar Pradesh": ["Lucknow", "Kanpur", "Ghaziabad", "Agra", "Meerut", "Varanasi", "Prayagraj", "Noida"],
  "Uttarakhand": ["Dehradun", "Haridwar", "Roorkee", "Haldwani", "Rishikesh"],
  "West Bengal": ["Kolkata", "Howrah", "Durgapur", "Asansol", "Siliguri", "Darjeeling"],
  "Andaman and Nicobar Islands": ["Port Blair"],
  "Chandigarh": ["Chandigarh"],
  "Dadra and Nagar Haveli and Daman and Diu": ["Daman", "Diu", "Silvassa"],
  "Delhi": ["New Delhi", "North Delhi", "South Delhi", "East Delhi", "West Delhi"],
  "Jammu and Kashmir": ["Srinagar", "Jammu", "Anantnag", "Baramulla"],
  "Ladakh": ["Leh", "Kargil"],
  "Lakshadweep": ["Kavaratti"],
  "Puducherry": ["Puducherry", "Karaikal", "Mahe", "Yanam"]
};

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.05
    }
  }
};

const item = {
  hidden: { opacity: 0, y: 10 },
  show: { opacity: 1, y: 0 }
};

const AssignmentForm = () => {
  const { device_id } = useParams();
  const [searchParams] = useSearchParams();
  const id = searchParams.get('id');
  const navigate = useNavigate();

  const formatIntId = (fullId) => {
    if (!fullId) return '';
    if (fullId.startsWith('INT-')) return fullId;
    const match = fullId.match(/\d+$/);
    if (match) {
      return `INT-${parseInt(match[0], 10)}`;
    }
    return fullId;
  };

  const intId = formatIntId(device_id);

  const [form, setForm] = useState({
    shop_name: '',
    owner_name: '',
    phone: '',
    alternate_phone: '',
    address_line_1: '',
    address_line_2: '',
    city: '',
    state: '',
    pincode: '',
    landmark: '',
    notes: '',
  });

  const [location, setLocation] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((pos) => {
        setLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude });
      });
    }
  }, []);

  const validate = () => {
    const required = ['shop_name', 'owner_name', 'phone', 'address_line_1', 'city', 'state', 'pincode'];
    for (let field of required) {
      if (!form[field]) return `Please fill in ${field.replace('_', ' ')}`;
    }
    if (!/^\d{10}$/.test(form.phone)) return "Phone must be 10 digits";
    if (!/^\d{6}$/.test(form.pincode)) return "Pincode must be 6 digits";
    return null;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const error = validate();
    if (error) {
      alert(error);
      return;
    }

    // Go to next page (WiFi Setup) instead of submitting
    navigate(`/sales/wifi-setup?device_id=${device_id}`, { 
      state: { 
        formData: form,
        deviceId: id,
        location: location
      } 
    });
  };

  return (
    <div className="min-h-screen bg-slate-50 py-8 px-4">
      <div className="max-w-2xl mx-auto">
        <button 
          onClick={() => navigate('/sales/dashboard')}
          className="flex items-center text-slate-500 hover:text-slate-900 font-bold mb-8 transition-colors"
        >
          <ArrowLeft size={20} className="mr-2" />
          Back to Dashboard
        </button>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-[2.5rem] shadow-xl border border-slate-100 overflow-hidden"
        >
          <div className="bg-indigo-600 p-10 text-white">
            <h1 className="text-3xl font-bold">Device Assignment</h1>
            <p className="text-indigo-100 mt-2 text-lg">Registering device <span className="font-mono bg-white/20 px-2 py-1 rounded">{intId}</span></p>
          </div>

          <motion.form 
            variants={container}
            initial="hidden"
            animate="show"
            onSubmit={handleSubmit} 
            className="p-10 space-y-8"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
               <motion.div variants={item} className="md:col-span-2">
                 <InputField label="Device ID" icon={Info} value={intId} editable={false} />
               </motion.div>

               <motion.div variants={item} className="md:col-span-2">
                 <InputField 
                   label="Shop Name" icon={Home} placeholder="ABC Guard Shop" 
                   value={form.shop_name} onChange={e => setForm({...form, shop_name: e.target.value})} required 
                 />
               </motion.div>

               <motion.div variants={item}>
                 <InputField 
                   label="Owner Name" icon={User} placeholder="Ramesh Kumar" 
                   value={form.owner_name} onChange={e => setForm({...form, owner_name: e.target.value})} required 
                 />
               </motion.div>

               <motion.div variants={item}>
                 <InputField 
                   label="Phone Number" icon={Phone} placeholder="9876543210" type="tel"
                   value={form.phone} onChange={e => setForm({...form, phone: e.target.value})} required 
                 />
               </motion.div>

               <motion.div variants={item}>
                 <InputField 
                   label="Alternate No (Optional)" icon={Phone} placeholder="Optional number" type="tel"
                   value={form.alternate_phone} onChange={e => setForm({...form, alternate_phone: e.target.value})} 
                 />
               </motion.div>

               <motion.div variants={item} className="md:col-span-2">
                 <InputField 
                   label="Address Line 1" icon={MapPin} placeholder="Street, landmark, etc." 
                   value={form.address_line_1} onChange={e => setForm({...form, address_line_1: e.target.value})} required 
                 />
               </motion.div>

               <motion.div variants={item} className="md:col-span-2">
                 <InputField 
                   label="Address Line 2 (Optional)" icon={MapPin} placeholder="Suite, floor, etc." 
                   value={form.address_line_2} onChange={e => setForm({...form, address_line_2: e.target.value})} 
                 />
               </motion.div>

               <motion.div variants={item}>
                 <SelectField 
                   label="State" icon={Map} 
                   options={Object.keys(stateCityData)}
                   value={form.state} 
                   onChange={e => {
                     const newState = e.target.value;
                     setForm({...form, state: newState, city: ''}); // Reset city when state changes
                   }} 
                   required 
                 />
               </motion.div>

               <motion.div variants={item}>
                 <SelectField 
                   label="City" icon={Map} 
                   options={form.state ? stateCityData[form.state] : []}
                   value={form.city} 
                   onChange={e => setForm({...form, city: e.target.value})} 
                   required 
                   disabled={!form.state}
                 />
               </motion.div>

               <motion.div variants={item}>
                 <InputField 
                   label="Pincode" icon={MapPin} placeholder="126102" 
                   value={form.pincode} onChange={e => setForm({...form, pincode: e.target.value})} required 
                 />
               </motion.div>

               <motion.div variants={item}>
                 <InputField 
                   label="Landmark (Optional)" icon={MapPin} placeholder="Near Bus Stand" 
                   value={form.landmark} onChange={e => setForm({...form, landmark: e.target.value})} 
                 />
               </motion.div>
            </div>

            <motion.div 
               variants={item} 
               className="bg-slate-50 p-6 rounded-3xl border border-dashed border-slate-200 cursor-pointer hover:bg-slate-100 transition-colors group"
               onClick={() => {
                 if (location) {
                   window.open(`https://www.google.com/maps?q=${location.lat},${location.lng}`, '_blank');
                 }
               }}
            >
               <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <MapPin className="text-emerald-500 mr-3 group-hover:scale-110 transition-transform" size={24} />
                    <div>
                       <div className="flex items-center gap-2">
                         <p className="font-bold text-slate-900">GPS Location</p>
                         <span className="text-[10px] bg-indigo-100 text-indigo-600 px-1.5 py-0.5 rounded font-bold uppercase">Click to view map</span>
                       </div>
                       <p className="text-sm text-slate-500">
                         {location ? `${location.lat.toFixed(4)}, ${location.lng.toFixed(4)}` : 'Capturing location...'}
                       </p>
                    </div>
                  </div>
                  {location && <CheckCircle className="text-emerald-500" size={24} />}
               </div>
            </motion.div>

            <motion.button 
              variants={item}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              type="submit"
              className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-5 rounded-2xl flex items-center justify-center space-x-2 transition-all shadow-lg shadow-indigo-100 mt-4"
            >
              <CheckCircle size={22} />
              <span>Next: WiFi Setup</span>
            </motion.button>
          </motion.form>
        </motion.div>
      </div>
    </div>
  );
};

export default AssignmentForm;
