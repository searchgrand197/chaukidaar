from django.contrib import admin
from .models import Device, DeviceAssignment, Batch, DeviceSequence, DeviceSchedule, SensorReading

@admin.register(Device)
class DeviceAdmin(admin.ModelAdmin):
    list_display = ('device_id', 'status', 'customer', 'desired_power_state', 'is_online', 'last_seen')
    search_fields = ('device_id', 'customer__username')
    list_filter = ('status', 'desired_power_state', 'is_online')

@admin.register(DeviceAssignment)
class DeviceAssignmentAdmin(admin.ModelAdmin):
    list_display = ('device', 'shop_name', 'owner_name', 'customer', 'assigned_by', 'assigned_at')
    search_fields = ('device__device_id', 'shop_name', 'owner_name', 'customer__username')

@admin.register(DeviceSchedule)
class DeviceScheduleAdmin(admin.ModelAdmin):
    list_display = ('device', 'name', 'start_time', 'end_time', 'weekdays', 'enabled')
    list_filter = ('enabled',)

@admin.register(SensorReading)
class SensorReadingAdmin(admin.ModelAdmin):
    list_display = ('device', 'temperature', 'ultrasonic_distance', 'heat_alarm', 'status', 'created_at')
    list_filter = ('heat_alarm', 'status')

admin.site.register(Batch)
admin.site.register(DeviceSequence)
