"""
Seed a customer user + device for local ESP / portal WiFi testing.

Usage:
  python manage.py setup_local_dev
  python manage.py setup_local_dev --device-id LOCAL000001 --token my-token
"""

from django.core.management.base import BaseCommand
from django.contrib.auth import get_user_model

from devices.models import Device, DeviceAssignment

DEFAULT_DEVICE_ID = '26E13000028'
DEFAULT_TOKEN = 'iCWKwcRYYIy48xzE7KQc8kAcYDzlbgVBc7fxT-P3yCA'
CUSTOMER_USERNAME = 'shop'
CUSTOMER_PASSWORD = 'shop123'


class Command(BaseCommand):
    help = 'Create local test customer + device (matches new-esp.ino defaults)'

    def add_arguments(self, parser):
        parser.add_argument('--device-id', default=DEFAULT_DEVICE_ID)
        parser.add_argument('--token', default=DEFAULT_TOKEN)
        parser.add_argument('--wifi-ssid', default='sales')
        parser.add_argument('--wifi-password', default='00000000')

    def handle(self, *args, **options):
        User = get_user_model()
        device_id = options['device_id']
        token = options['token']

        customer, created = User.objects.get_or_create(
            username=CUSTOMER_USERNAME,
            defaults={'role': 'customer', 'email': 'shop@local.test'},
        )
        customer.role = 'customer'
        customer.set_password(CUSTOMER_PASSWORD)
        customer.save()

        device, _ = Device.objects.update_or_create(
            device_id=device_id,
            defaults={
                'device_token': token,
                'status': 'assigned',
                'customer': customer,
                'wifi_ssid': options['wifi_ssid'],
                'desired_power_state': True,
                'is_armed': True,
            },
        )

        assignment, _ = DeviceAssignment.objects.update_or_create(
            device=device,
            defaults={
                'customer': customer,
                'shop_name': 'Local Test Shop',
                'owner_name': 'Test Owner',
                'phone': '9876543210',
                'address_line_1': '123 Test Street',
                'city': 'Test City',
                'state': 'Test State',
                'pincode': '110001',
                'wifi_ssid': options['wifi_ssid'],
                'wifi_password': options['wifi_password'],
            },
        )

        self.stdout.write(self.style.SUCCESS('Local dev data ready'))
        self.stdout.write('')
        self.stdout.write('Customer portal login:')
        self.stdout.write(f'  username: {CUSTOMER_USERNAME}')
        self.stdout.write(f'  password: {CUSTOMER_PASSWORD}')
        self.stdout.write('')
        self.stdout.write('ESP8266 (must match new-esp.ino):')
        self.stdout.write(f'  DEVICE_ID:    {device.device_id}')
        self.stdout.write(f'  DEVICE_TOKEN: {device.device_token}')
        self.stdout.write('')
        self.stdout.write('WiFi on device (default):')
        self.stdout.write(f'  SSID:     {options["wifi_ssid"]}')
        self.stdout.write(f'  password: {options["wifi_password"]}')
        self.stdout.write('')
        self.stdout.write('Portal: http://localhost:1000/login  (Customer role)')
        self.stdout.write(f'Device: http://localhost:1000/customer/device/{device.device_id}')
