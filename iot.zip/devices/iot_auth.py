from django.contrib.auth.models import AnonymousUser
from rest_framework.authentication import BaseAuthentication
from rest_framework.exceptions import AuthenticationFailed

from .models import Device


class DeviceTokenAuthentication(BaseAuthentication):
    """
    Public IoT auth for ESP8266 — no JWT/session.
    Send: X-Device-Token: <token>  (or Authorization: Device <token>)
    """

    def authenticate(self, request):
        token = (request.headers.get('X-Device-Token') or '').strip()
        if not token:
            auth_header = request.headers.get('Authorization', '')
            if auth_header.startswith('Device '):
                token = auth_header.replace('Device ', '', 1).strip()
        if not token:
            raise AuthenticationFailed('Missing X-Device-Token header')

        device_id = None
        if request.resolver_match:
            device_id = request.resolver_match.kwargs.get('device_id')
        if not device_id:
            raise AuthenticationFailed('Missing device_id in URL')

        try:
            device = Device.objects.get(device_id=device_id, device_token=token)
        except Device.DoesNotExist:
            raise AuthenticationFailed('Invalid device_id or device token')

        return (AnonymousUser(), device)
