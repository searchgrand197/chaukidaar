import qrcode
import json
from io import BytesIO
from django.core.files import File

def generate_device_qr(device_id):
    qr_data = json.dumps({"device_id": device_id})
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=4,
    )
    qr.add_data(qr_data)
    qr.make(fit=True)

    img = qr.make_image(fill_color="black", back_color="white")
    
    blob = BytesIO()
    img.save(blob, 'PNG')
    blob.seek(0)
    
    return File(blob, name=f"{device_id}.png")
