from django.contrib import admin
from django.urls import path, include, re_path
from django.conf import settings
from django.conf.urls.static import static
from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
)
from drf_spectacular.views import SpectacularAPIView, SpectacularRedocView, SpectacularSwaggerView
from rest_framework.routers import DefaultRouter
from devices.views import (
    DeviceViewSet,
    BatchViewSet,
    AssignDeviceView,
    AssignmentHistoryView,
    CustomerDeviceListView,
    CustomerDeviceStatusView,
    CustomerPowerView,
    CustomerScheduleView,
    CustomerScheduleDetailView,
    CustomerSensorReadingView,
    CustomerWifiConfigView,
    CustomerWifiSetupInfoView,
    CustomerWifiForgetView,
    CustomerUltrasonicConfigView,
    CustomerAlertPhoneView,
    IoTTelemetryView,
    IoTCommandView,
    IoTCommandAckView,
    IoTHotspotWifiReportView,
)
from accounts.views import UserMeView
from core.frontend_views import spa_index, dist_static, dist_assets

router = DefaultRouter()
router.register(r'devices', DeviceViewSet, basename='device')
router.register(r'batches', BatchViewSet, basename='batch')

urlpatterns = [
    path('admin/', admin.site.urls),
    
    # Auth
    path('api/auth/login/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/auth/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('api/auth/me/', UserMeView.as_view(), name='user-me'),
    
    # Router API (Devices, Batches)
    path('api/', include(router.urls)),
    
    # Extra Device Actions (Legacy/Specific)
    path('api/device/assign/', AssignDeviceView.as_view(), name='assign-device'),
    path('api/device/history/', AssignmentHistoryView.as_view(), name='assignment-history'),

    # Customer IoT API
    path('api/customer/devices/', CustomerDeviceListView.as_view(), name='customer-devices'),
    path('api/customer/devices/<str:device_id>/status/', CustomerDeviceStatusView.as_view(), name='customer-device-status'),
    path('api/customer/devices/<str:device_id>/power/', CustomerPowerView.as_view(), name='customer-device-power'),
    path('api/customer/devices/<str:device_id>/schedules/', CustomerScheduleView.as_view(), name='customer-device-schedules'),
    path('api/customer/devices/<str:device_id>/schedules/<int:schedule_id>/', CustomerScheduleDetailView.as_view(), name='customer-device-schedule-detail'),
    path('api/customer/devices/<str:device_id>/sensor-readings/', CustomerSensorReadingView.as_view(), name='customer-device-sensor-readings'),
    path('api/customer/devices/<str:device_id>/wifi/', CustomerWifiConfigView.as_view(), name='customer-device-wifi'),
    path('api/customer/devices/<str:device_id>/wifi-setup-info/', CustomerWifiSetupInfoView.as_view(), name='customer-device-wifi-setup-info'),
    path('api/customer/devices/<str:device_id>/wifi/forget/', CustomerWifiForgetView.as_view(), name='customer-device-wifi-forget'),
    path('api/customer/devices/<str:device_id>/ultrasonic-config/', CustomerUltrasonicConfigView.as_view(), name='customer-device-ultrasonic-config'),
    path('api/customer/devices/<str:device_id>/alert-phone/', CustomerAlertPhoneView.as_view(), name='customer-device-alert-phone'),

    # ESP8266 IoT API
    path('api/iot/devices/<str:device_id>/telemetry/', IoTTelemetryView.as_view(), name='iot-device-telemetry'),
    path('api/iot/devices/<str:device_id>/commands/', IoTCommandView.as_view(), name='iot-device-commands'),
    path('api/iot/devices/<str:device_id>/commands/ack/', IoTCommandAckView.as_view(), name='iot-device-command-ack'),
    path('api/iot/devices/<str:device_id>/wifi-report/', IoTHotspotWifiReportView.as_view(), name='iot-device-wifi-report'),
    
    # Schema
    path('api/schema/', SpectacularAPIView.as_view(), name='schema'),
    path('api/schema/swagger-ui/', SpectacularSwaggerView.as_view(url_name='schema'), name='swagger-ui'),
    path('api/schema/redoc/', SpectacularRedocView.as_view(url_name='schema'), name='redoc'),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

# React SPA (built files in frontend/dist) — must be after API routes
urlpatterns += [
    path('favicon.svg', dist_static, {'path': 'favicon.svg'}),
    path('icons.svg', dist_static, {'path': 'icons.svg'}),
    re_path(r'^assets/(?P<path>.*)$', dist_assets),
    re_path(r'^(?!api/|admin/|media/|static/).*$', spa_index),
]
