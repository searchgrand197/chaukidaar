import { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, ChevronRight, KeyRound, Loader2, Trash2, Wifi } from 'lucide-react';
import toast from 'react-hot-toast';
import { customerDeviceService } from '../../api/services';

const WifiSettings = () => {
  const { deviceId } = useParams();
  const navigate = useNavigate();
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [form, setForm] = useState({ ssid: '', password: '' });
  const [saving, setSaving] = useState(false);

  const saveWifiRemote = async (event) => {
    event.preventDefault();
    setSaving(true);
    try {
      await customerDeviceService.updateWifi(deviceId, form);
      toast.success('WiFi update queued (device must be online)');
      navigate(`/customer/device/${deviceId}`);
    } catch {
      toast.error('Could not queue WiFi update');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 p-5">
      <button
        type="button"
        onClick={() => navigate(`/customer/device/${deviceId}`)}
        className="flex items-center gap-2 text-slate-500 font-bold mb-6"
      >
        <ArrowLeft size={20} /> Back
      </button>

      <div className="bg-indigo-600 text-white rounded-[2rem] p-6">
        <Wifi size={36} />
        <h1 className="text-3xl font-black mt-4">WiFi</h1>
        <p className="text-indigo-100 mt-2 text-sm leading-relaxed">
          Use the device setup hotspot when you are next to the sensor. Remote update works only if the device is already online.
        </p>
      </div>

      <div className="space-y-4 mt-6">
        <button
          type="button"
          onClick={() => navigate(`/customer/device/${deviceId}/wifi/forget`)}
          className="w-full bg-white rounded-[1.75rem] p-5 border border-slate-100 text-left flex items-center gap-4 shadow-sm"
        >
          <div className="bg-rose-100 p-3 rounded-2xl">
            <Trash2 className="text-rose-600" size={26} />
          </div>
          <div className="flex-1">
            <h2 className="font-black text-slate-900">Forget password</h2>
            <p className="text-sm text-slate-500 mt-1">Connect to device hotspot and set new shop WiFi</p>
          </div>
          <ChevronRight className="text-slate-300" />
        </button>

        <button
          type="button"
          onClick={() => navigate(`/customer/device/${deviceId}/wifi/change`)}
          className="w-full bg-white rounded-[1.75rem] p-5 border border-slate-100 text-left flex items-center gap-4 shadow-sm"
        >
          <div className="bg-indigo-100 p-3 rounded-2xl">
            <KeyRound className="text-indigo-600" size={26} />
          </div>
          <div className="flex-1">
            <h2 className="font-black text-slate-900">Change password</h2>
            <p className="text-sm text-slate-500 mt-1">Same hotspot flow — update network or password</p>
          </div>
          <ChevronRight className="text-slate-300" />
        </button>
      </div>

      <button
        type="button"
        onClick={() => setShowAdvanced(!showAdvanced)}
        className="w-full mt-6 text-sm font-bold text-slate-500"
      >
        {showAdvanced ? 'Hide' : 'Show'} advanced — remote update (device online)
      </button>

      {showAdvanced && (
        <form onSubmit={saveWifiRemote} className="bg-white rounded-[2rem] p-5 border border-slate-100 mt-3 space-y-4">
          <input
            className="w-full bg-slate-50 rounded-2xl px-4 py-4 font-bold outline-none"
            placeholder="WiFi name"
            value={form.ssid}
            onChange={(e) => setForm({ ...form, ssid: e.target.value })}
            required
          />
          <input
            className="w-full bg-slate-50 rounded-2xl px-4 py-4 font-bold outline-none"
            placeholder="WiFi password"
            type="password"
            value={form.password}
            onChange={(e) => setForm({ ...form, password: e.target.value })}
            required
          />
          <button
            type="submit"
            disabled={saving}
            className="w-full bg-slate-950 text-white py-4 rounded-2xl font-black flex items-center justify-center gap-2"
          >
            {saving ? <Loader2 className="animate-spin" /> : <Wifi />}
            Queue remote WiFi update
          </button>
        </form>
      )}
    </div>
  );
};

export default WifiSettings;

