import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, CalendarClock, Loader2, Power, Radio, Settings, Thermometer, Wifi } from 'lucide-react';
import toast from 'react-hot-toast';
import { customerDeviceService } from '../../api/services';

const ActionButton = ({ icon: Icon, title, subtitle, onClick }) => (
  <button onClick={onClick} className="bg-white rounded-[1.75rem] p-5 text-left border border-slate-100 shadow-sm">
    <Icon className="text-indigo-600 mb-4" size={26} />
    <h3 className="font-black text-slate-900">{title}</h3>
    <p className="text-sm text-slate-500 mt-1">{subtitle}</p>
  </button>
);

const DeviceControl = () => {
  const { deviceId } = useParams();
  const navigate = useNavigate();
  const [device, setDevice] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const loadDevice = async () => {
      try {
        const response = await customerDeviceService.status(deviceId);
        setDevice(response.data);
      } catch {
        toast.error('Could not load device');
      } finally {
        setLoading(false);
      }
    };
    loadDevice();
  }, [deviceId]);

  const togglePower = async () => {
    if (!device) return;
    setSaving(true);
    try {
      const response = await customerDeviceService.setPower(deviceId, !device.desired_power_state);
      setDevice(response.data);
      toast.success('Device command queued');
    } catch {
      toast.error('Could not update device');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <Loader2 className="animate-spin text-indigo-600" size={40} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 p-5">
      <button onClick={() => navigate('/customer/dashboard')} className="flex items-center gap-2 text-slate-500 font-bold mb-6">
        <ArrowLeft size={20} /> Back
      </button>

      <section className="bg-slate-950 text-white rounded-[2.5rem] p-6 shadow-xl">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-slate-400 font-mono text-sm">{device.device_id}</p>
            <h1 className="text-3xl font-black mt-2">{device.assignment?.shop_name || 'Security Device'}</h1>
            <p className="text-sm mt-2 text-slate-300">{device.is_online ? 'Online' : 'Offline'} · Last seen {device.last_seen ? new Date(device.last_seen).toLocaleString() : 'never'}</p>
          </div>
          <span className={`px-3 py-1 rounded-full text-xs font-black ${device.is_online ? 'bg-emerald-400 text-emerald-950' : 'bg-slate-700 text-slate-300'}`}>
            {device.is_online ? 'LIVE' : 'OFF'}
          </span>
        </div>

        <button
          onClick={togglePower}
          disabled={saving}
          className={`w-full mt-8 py-6 rounded-[2rem] flex items-center justify-center gap-3 font-black text-xl ${device.desired_power_state ? 'bg-emerald-500 text-white' : 'bg-white text-slate-950'}`}
        >
          {saving ? <Loader2 className="animate-spin" /> : <Power />}
          {device.desired_power_state ? 'Device On' : 'Device Off'}
        </button>
      </section>

      <div className="grid grid-cols-2 gap-4 mt-5">
        <div className="bg-white rounded-[1.75rem] p-5 border border-slate-100">
          <Thermometer className="text-orange-500 mb-3" />
          <p className="text-xs text-slate-500">Heat Sensor</p>
          <p className="text-2xl font-black">{device.last_temperature ?? '--'} C</p>
        </div>
        <div className="bg-white rounded-[1.75rem] p-5 border border-slate-100">
          <Radio className="text-cyan-500 mb-3" />
          <p className="text-xs text-slate-500">Ultrasonic</p>
          <p className="text-2xl font-black">{device.last_ultrasonic_distance ?? '--'} cm</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 mt-5">
        <ActionButton icon={CalendarClock} title="Schedule" subtitle="Set on/off timing" onClick={() => navigate(`/customer/device/${deviceId}/schedule`)} />
        <ActionButton icon={Thermometer} title="Graph" subtitle="Last 100 heat points" onClick={() => navigate(`/customer/device/${deviceId}/sensors`)} />
        <ActionButton icon={Wifi} title="WiFi" subtitle="Forget or change network" onClick={() => navigate(`/customer/device/${deviceId}/wifi`)} />
        <ActionButton icon={Settings} title="Sensor" subtitle="Ultrasonic settings" onClick={() => navigate(`/customer/device/${deviceId}/ultrasonic`)} />
      </div>
    </div>
  );
};

export default DeviceControl;
