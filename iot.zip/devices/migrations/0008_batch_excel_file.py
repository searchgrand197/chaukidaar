from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('devices', '0007_device_command_ack_revision_device_command_revision_and_more'),
    ]

    operations = [
        migrations.AddField(
            model_name='batch',
            name='excel_file',
            field=models.FileField(blank=True, null=True, upload_to='batches/'),
        ),
    ]
