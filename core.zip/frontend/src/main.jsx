import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'

// Diagnostic Error Handling
window.onerror = (msg, url, line) => {
  const root = document.getElementById('root');
  if (root) {
    root.innerHTML = `<div style="padding: 20px; color: red; font-family: sans-serif;">
      <h2>Frontend Crash Detected</h2>
      <p>Error: ${msg}</p>
      <p>Location: ${url}:${line}</p>
      <button onclick="window.location.reload()" style="padding: 8px 16px; margin-top: 10px; cursor: pointer;">Reload Page</button>
    </div>`;
  }
};

const rootElement = document.getElementById('root');
if (rootElement) {
  createRoot(rootElement).render(
    <StrictMode>
      <App />
    </StrictMode>,
  )
}
