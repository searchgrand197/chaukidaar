import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { QrCode, History, LogOut, Package, CheckCircle, Clock, Search, Filter, ChevronRight, LayoutDashboard } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import client from '../../api/client';
import { motion } from 'framer-motion';

const StatCard = ({ title, value, icon: Icon, color }) => (
  <div className="bg-white p-6 rounded-3xl flex-1 border border-slate-100 shadow-sm hover:shadow-md transition-shadow">
    <div className={`w-12 h-12 ${color} rounded-2xl flex items-center justify-center mb-4 shadow-sm`}>
      <Icon size={24} className="text-white" />
    </div>
    <p className="text-slate-500 text-sm font-medium">{title}</p>
    <p className="text-slate-900 text-2xl font-bold mt-1">{value}</p>
  </div>
);

const Dashboard = () => {
  const { user, logout } = useAuth();
  const [history, setHistory] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchHistory = async () => {
      try {
        const response = await client.get('/device/history/');
        // Handle paginated response (results) or plain array
        const data = response.data.results || response.data || [];
        setHistory(data);
      } catch (error) {
        console.error(error);
      }
    };
    fetchHistory();
  }, []);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const openAssignment = (item) => {
    navigate(`/sales/assignment/${item.id}`, { state: { assignment: item } });
  };

  const todayCount = history.filter(item => {
    const today = new Date().toISOString().split('T')[0];
    return item.assigned_at.startsWith(today);
  }).length;

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="max-w-6xl mx-auto px-4 h-20 flex items-center justify-between">
          <div className="flex items-center space-x-3">
             <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center font-bold text-white">INT</div>
             <h1 className="text-xl font-bold text-slate-900 hidden sm:block">ShopGuard Manager</h1>
          </div>
          <div className="flex items-center space-x-4">
             <div className="text-right hidden sm:block">
               <p className="text-sm font-bold text-slate-900">{user?.username}</p>
               <p className="text-xs text-slate-500 capitalize">{user?.role}</p>
             </div>
             <button 
               onClick={handleLogout}
               className="p-3 bg-rose-50 text-rose-600 rounded-xl hover:bg-rose-100 transition-colors"
             >
               <LogOut size={20} />
             </button>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-8">
        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
           <StatCard 
             title="Assigned Today" 
             value={todayCount} 
             icon={CheckCircle} 
             color="bg-emerald-500" 
           />
           <StatCard 
             title="Total History" 
             value={history.length} 
             icon={Package} 
             color="bg-indigo-500" 
           />
           <StatCard 
             title="Pending Sync" 
             value="0" 
             icon={Clock} 
             color="bg-amber-500" 
           />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Actions */}
          <div className="lg:col-span-2 space-y-6">
            <motion.button 
              whileHover={{ scale: 1.01 }}
              whileTap={{ scale: 0.99 }}
              onClick={() => navigate('/sales/scanner')}
              className="w-full bg-indigo-600 p-8 rounded-[2rem] text-left flex items-center justify-between shadow-xl shadow-indigo-100 group"
            >
              <div>
                <h2 className="text-white text-3xl font-bold">Scan QR Code</h2>
                <p className="text-indigo-100 mt-2">Start a new device assignment workflow</p>
              </div>
              <div className="bg-white/20 p-6 rounded-3xl group-hover:bg-white/30 transition-colors">
                <QrCode size={48} className="text-white" />
              </div>
            </motion.button>

            <motion.button 
              whileHover={{ scale: 1.01 }}
              whileTap={{ scale: 0.99 }}
              onClick={() => navigate('/')}
              className="w-full bg-slate-800 p-8 rounded-[2rem] text-left flex items-center justify-between shadow-xl shadow-slate-100 group"
            >
              <div>
                <h2 className="text-white text-2xl font-bold">Switch Portal</h2>
                <p className="text-slate-300 mt-2">Go back to role selection</p>
              </div>
              <div className="bg-white/10 p-6 rounded-3xl group-hover:bg-white/20 transition-colors">
                <LayoutDashboard size={40} className="text-white" />
              </div>
            </motion.button>

            <div className="bg-white rounded-[2rem] p-8 border border-slate-100 shadow-sm">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-slate-900">Recent Assignments</h3>
                <button 
                  onClick={() => navigate('/sales/history')}
                  className="text-indigo-600 font-bold hover:underline"
                >
                  View All
                </button>
              </div>
              
              <div className="space-y-4">
                {history?.slice(0, 5).map((item, index) => (
                  <button
                    key={item.id ?? index}
                    type="button"
                    onClick={() => openAssignment(item)}
                    className="w-full flex items-center p-4 bg-slate-50 rounded-2xl border border-slate-100 hover:border-indigo-200 transition-colors text-left cursor-pointer"
                  >
                    <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center mr-4 border border-slate-100">
                      <Package size={24} className="text-slate-600" />
                    </div>
                    <div className="flex-1">
                      <p className="font-bold text-slate-900">{item.shop_name}</p>
                      <p className="text-sm text-slate-500">{item.device_id_str} • {new Date(item.assigned_at).toLocaleDateString()}</p>
                    </div>
                    <ChevronRight size={20} className="text-slate-300" />
                  </button>
                ))}
                {history.length === 0 && (
                  <div className="text-center py-8">
                    <Package size={48} className="text-slate-200 mx-auto mb-2" />
                    <p className="text-slate-400 italic">No assignments yet</p>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Quick Info / Sidebar */}
          <div className="space-y-6">
            <div className="bg-gradient-to-br from-indigo-600 to-indigo-800 rounded-[2rem] p-8 text-white shadow-xl shadow-indigo-100">
               <h3 className="text-xl font-bold mb-4">Pro Tip</h3>
               <p className="text-indigo-100 leading-relaxed mb-6">
                 Always ensure the shop owner's phone number is verified before completing the assignment.
               </p>
               <button className="bg-white text-indigo-600 font-bold px-6 py-3 rounded-xl hover:bg-indigo-50 transition-colors">
                 Learn More
               </button>
            </div>

            <div className="bg-white rounded-[2rem] p-8 border border-slate-100 shadow-sm">
               <h3 className="text-lg font-bold text-slate-900 mb-4">Active Session</h3>
               <div className="space-y-4">
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-500">Status</span>
                    <span className="text-emerald-500 font-bold flex items-center">
                       <div className="w-2 h-2 bg-emerald-500 rounded-full mr-2 animate-pulse"></div>
                       Online
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-500">Last Sync</span>
                    <span className="text-slate-900 font-medium">Just now</span>
                  </div>
               </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;
