# Generated manually for customer portal credentials on assign

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('devices', '0009_device_wifi_password'),
    ]

    operations = [
        migrations.AddField(
            model_name='deviceassignment',
            name='portal_password',
            field=models.CharField(blank=True, default='', max_length=64),
        ),
    ]
