import React, { useState } from 'react';
import { useLocation, useNavigate, useSearchParams } from 'react-router-dom';
import { Wifi, Lock, ArrowLeft, CheckCircle, Loader2 } from 'lucide-react';
import client from '../../api/client';
import { motion } from 'framer-motion';

const WifiSetup = () => {
  const { state } = useLocation();
  const [searchParams] = useSearchParams();
  const device_id = searchParams.get('device_id');
  const navigate = useNavigate();
  
  const [wifi, setWifi] = useState({
    wifi_ssid: '',
    wifi_password: '',
  });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!wifi.wifi_ssid || !wifi.wifi_password) {
      alert('Please enter both WiFi name and password');
      return;
    }

    setLoading(true);
    try {
      const finalData = {
        ...state.formData,
        ...wifi,
        device_id: device_id,
        device: state.deviceId,
      };

      await client.post('/device/assign/', finalData);
      navigate(`/sales/success?device_id=${device_id}&shop_name=${state.formData.shop_name}`);
    } catch (err) {
      const errorData = err.response?.data;
      let msg = 'Assignment failed';
      if (errorData) {
        msg = Object.entries(errorData)
          .map(([key, val]) => `${key}: ${val}`)
          .join('\n');
      }
      alert(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 py-8 px-4">
      <div className="max-w-md mx-auto">
        <button 
          onClick={() => navigate(-1)}
          className="flex items-center text-slate-500 hover:text-slate-900 font-bold mb-8 transition-colors"
        >
          <ArrowLeft size={20} className="mr-2" />
          Back to Details
        </button>

        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-white rounded-[2.5rem] shadow-xl border border-slate-100 overflow-hidden"
        >
          <div className="bg-indigo-600 p-8 text-white text-center">
             <div className="bg-white/20 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Wifi size={32} />
             </div>
            <h1 className="text-2xl font-bold">WiFi Configuration</h1>
            <p className="text-indigo-100 mt-1">Setup internet for device {device_id}</p>
          </div>

          <form onSubmit={handleSubmit} className="p-8 space-y-6">
            <div className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-sm font-bold text-slate-700 ml-1">WiFi Name (SSID)</label>
                <div className="relative flex items-center group">
                  <Wifi className="absolute left-4 text-slate-400 group-focus-within:text-indigo-600" size={18} />
                  <input 
                    type="text"
                    placeholder="Enter WiFi Name"
                    value={wifi.wifi_ssid}
                    onChange={e => setWifi({...wifi, wifi_ssid: e.target.value})}
                    className="w-full pl-12 pr-4 py-4 rounded-2xl border border-slate-200 focus:ring-2 focus:ring-indigo-600 outline-none transition-all font-medium"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-sm font-bold text-slate-700 ml-1">WiFi Password</label>
                <div className="relative flex items-center group">
                  <Lock className="absolute left-4 text-slate-400 group-focus-within:text-indigo-600" size={18} />
                  <input 
                    type="password"
                    placeholder="Enter WiFi Password"
                    value={wifi.wifi_password}
                    onChange={e => setWifi({...wifi, wifi_password: e.target.value})}
                    className="w-full pl-12 pr-4 py-4 rounded-2xl border border-slate-200 focus:ring-2 focus:ring-indigo-600 outline-none transition-all font-medium"
                  />
                </div>
              </div>
            </div>

            <button 
              type="submit"
              disabled={loading}
              className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-5 rounded-2xl flex items-center justify-center space-x-2 transition-all shadow-lg shadow-indigo-100 disabled:opacity-70 mt-4"
            >
              {loading ? <Loader2 className="animate-spin" /> : (
                <>
                  <CheckCircle size={22} />
                  <span>Save & Complete</span>
                </>
              )}
            </button>
          </form>
        </motion.div>
      </div>
    </div>
  );
};

export default WifiSetup;
