from rest_framework import serializers
from .models import Device, DeviceAssignment, Batch, DeviceSchedule, SensorReading
from accounts.models import User
from accounts.serializers import UserSerializer

class DeviceSerializer(serializers.ModelSerializer):
    assignment = serializers.SerializerMethodField()
    
    class Meta:
        model = Device
        fields = [
            'id', 'device_id', 'sequence_number', 'qr_image', 'status',
            'desired_power_state', 'is_armed', 'is_online', 'last_seen',
            'last_temperature', 'last_ultrasonic_distance', 'firmware_version',
            'wifi_ssid', 'ultrasonic_config', 'created_at', 'assignment',
        ]
    
    def get_assignment(self, obj):
        try:
            # We use a nested serializer to get shop_name, owner_name, etc.
            return DeviceAssignmentSerializer(obj.assignment).data
        except DeviceAssignment.DoesNotExist:
            return None

class DeviceAssignmentSerializer(serializers.ModelSerializer):
    assigned_by_details = UserSerializer(source='assigned_by', read_only=True)
    device_id_str = serializers.CharField(source='device.device_id', read_only=True)
    customer_username = serializers.CharField(write_only=True, required=False, allow_blank=True)
    customer_password = serializers.CharField(write_only=True, required=False, allow_blank=True)
    customer_email = serializers.EmailField(write_only=True, required=False, allow_blank=True)

    class Meta:
        model = DeviceAssignment
        fields = '__all__'
        read_only_fields = ('assigned_by', 'assigned_at')

    def validate_device(self, value):
        if value.status == 'assigned':
            raise serializers.ValidationError("Device already assigned")
        return value

    def create(self, validated_data):
        customer_username = validated_data.pop('customer_username', '').strip()
        customer_password = validated_data.pop('customer_password', '').strip()
        customer_email = validated_data.pop('customer_email', '').strip()

        if customer_username:
            customer, created = User.objects.get_or_create(
                username=customer_username,
                defaults={'email': customer_email, 'role': 'customer'},
            )
            if created and customer_password:
                customer.set_password(customer_password)
                customer.save(update_fields=['password'])
            validated_data['customer'] = customer

        device = validated_data['device']
        assignment = super().create(validated_data)
        device.status = 'assigned'
        if assignment.customer_id:
            device.customer = assignment.customer
        device.save()
        return assignment

class CustomerDeviceSerializer(serializers.ModelSerializer):
    assignment = DeviceAssignmentSerializer(read_only=True)

    class Meta:
        model = Device
        fields = [
            'id', 'device_id', 'status', 'desired_power_state', 'is_armed',
            'is_online', 'last_seen', 'last_temperature',
            'last_ultrasonic_distance', 'firmware_version', 'wifi_ssid',
            'ultrasonic_config', 'assignment',
        ]

class DeviceScheduleSerializer(serializers.ModelSerializer):
    class Meta:
        model = DeviceSchedule
        fields = ['id', 'name', 'start_time', 'end_time', 'weekdays', 'enabled']

class SensorReadingSerializer(serializers.ModelSerializer):
    class Meta:
        model = SensorReading
        fields = ['id', 'temperature', 'ultrasonic_distance', 'heat_alarm', 'status', 'created_at']

class PowerControlSerializer(serializers.Serializer):
    enabled = serializers.BooleanField()

class WifiConfigSerializer(serializers.Serializer):
    ssid = serializers.CharField(max_length=100)
    password = serializers.CharField(max_length=100, write_only=True)

class UltrasonicConfigSerializer(serializers.Serializer):
    ignore_percent = serializers.FloatField(required=False, min_value=0.01, max_value=0.9)
    min_intrusion_cm = serializers.IntegerField(required=False, min_value=1, max_value=400)
    recalibrate = serializers.BooleanField(required=False, default=False)

    def validate(self, attrs):
        if not attrs:
            raise serializers.ValidationError('At least one ultrasonic setting is required.')
        return attrs

class TelemetrySerializer(serializers.Serializer):
    temperature = serializers.DecimalField(max_digits=6, decimal_places=2, required=False, allow_null=True)
    ultrasonic_distance = serializers.DecimalField(max_digits=7, decimal_places=2, required=False, allow_null=True)
    heat_alarm = serializers.BooleanField(required=False, default=False)
    status = serializers.CharField(max_length=20, required=False, allow_blank=True)
    armed = serializers.BooleanField(required=False)
    online = serializers.BooleanField(required=False, default=True)
    firmware_version = serializers.CharField(max_length=50, required=False, allow_blank=True)

class CommandAckSerializer(serializers.Serializer):
    command_revision = serializers.IntegerField(required=False, min_value=0)
    wifi_revision = serializers.IntegerField(required=False, min_value=0)
    wifi_status = serializers.ChoiceField(choices=['success', 'failed'], required=False)
    wifi_ssid = serializers.CharField(max_length=100, required=False, allow_blank=True)
    ultrasonic_revision = serializers.IntegerField(required=False, min_value=0)
    ultrasonic_status = serializers.ChoiceField(choices=['success', 'failed'], required=False)

class BatchSerializer(serializers.ModelSerializer):
    pdf_url = serializers.SerializerMethodField()
    excel_url = serializers.SerializerMethodField()

    class Meta:
        model = Batch
        fields = [
            'batch_number',
            'count',
            'created_at',
            'pdf_file',
            'pdf_url',
            'excel_file',
            'excel_url',
        ]

    def get_pdf_url(self, obj):
        if obj.pdf_file:
            request = self.context.get('request')
            if request:
                return request.build_absolute_uri(obj.pdf_file.url)
            return obj.pdf_file.url
        return None

    def get_excel_url(self, obj):
        if obj.excel_file:
            request = self.context.get('request')
            if request:
                return request.build_absolute_uri(obj.excel_file.url)
            return obj.excel_file.url
        return None

class GenerateBatchSerializer(serializers.Serializer):
    count = serializers.IntegerField(min_value=1, max_value=280)
