import re

DEFAULT_COUNTRY_CODE = '91'


def normalize_phone_e164(phone: str, country_code: str = DEFAULT_COUNTRY_CODE) -> str:
    """Convert stored phone to E.164 for Twilio (default +91 for 10-digit Indian numbers)."""
    if not phone:
        return ''
    raw = str(phone).strip()
    if raw.startswith('+'):
        digits = re.sub(r'\D', '', raw)
        return f'+{digits}' if digits else ''
    digits = re.sub(r'\D', '', raw)
    if len(digits) == 10:
        return f'+{country_code}{digits}'
    if len(digits) == 12 and digits.startswith(country_code):
        return f'+{digits}'
    if digits:
        return f'+{digits}'
    return ''
