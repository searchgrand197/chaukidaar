import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider, useAuth } from './context/AuthContext';
import AppLayout from './components/layout/AppLayout';

// Admin Pages
import Dashboard from './pages/Dashboard';
import GeneratePage from './pages/GeneratePage';
import DeviceTable from './pages/DeviceTable';
import LoginPage from './pages/LoginPage';
import VerifyPage from './pages/VerifyPage';
import BatchHistory from './pages/BatchHistory';

// Sales Pages
import SalesDashboard from './pages/sales/Dashboard';
import QRScanner from './pages/sales/QRScanner';
import AssignmentForm from './pages/sales/AssignmentForm';
import WifiSetup from './pages/sales/WifiSetup';
import Success from './pages/sales/Success';
import SalesHistory from './pages/sales/SalesHistory';
import AssignmentDetail from './pages/sales/AssignmentDetail';

// Customer Pages
import CustomerDashboard from './pages/customer/Dashboard';
import CustomerDeviceControl from './pages/customer/DeviceControl';
import CustomerSchedule from './pages/customer/Schedule';
import CustomerSensors from './pages/customer/Sensors';
import CustomerWifiSettings from './pages/customer/WifiSettings';
import WifiHotspotGuide from './pages/customer/WifiHotspotGuide';
import CustomerUltrasonicSettings from './pages/customer/UltrasonicSettings';

// Protected Route Component
const ProtectedRoute = ({ children }) => {
  const { user, loading } = useAuth();
  
  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50">
      <div className="w-10 h-10 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
    </div>
  );
  
  if (!user) return <Navigate to="/login" />;
  
  return children;
};

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          
          {/* Default Route: Redirect to login or appropriate dashboard */}
          <Route path="/" element={<Navigate to="/login" />} />

          {/* Admin Routes */}
          <Route path="/admin/*" element={
            <ProtectedRoute>
              <AppLayout />
            </ProtectedRoute>
          }>
            <Route index element={<Navigate to="dashboard" />} />
            <Route path="dashboard" element={<Dashboard />} />
            <Route path="generate" element={<GeneratePage />} />
            <Route path="devices" element={<DeviceTable />} />
            <Route path="batches" element={<BatchHistory />} />
            <Route path="verify" element={<VerifyPage />} />
            <Route path="verify/:deviceId" element={<VerifyPage />} />
          </Route>

          {/* Sales Routes */}
          <Route path="/sales/*" element={
            <ProtectedRoute>
              <Routes>
                <Route path="dashboard" element={<SalesDashboard />} />
                <Route path="scanner" element={<QRScanner />} />
                <Route path="assign/:device_id" element={<AssignmentForm />} />
                <Route path="wifi-setup" element={<WifiSetup />} />
                <Route path="success" element={<Success />} />
                <Route path="history" element={<SalesHistory />} />
                <Route path="assignment/:id" element={<AssignmentDetail />} />
                <Route path="*" element={<Navigate to="dashboard" />} />
              </Routes>
            </ProtectedRoute>
          } />

          {/* Customer Routes */}
          <Route path="/customer/*" element={
            <ProtectedRoute>
              <Routes>
                <Route path="dashboard" element={<CustomerDashboard />} />
                <Route path="device/:deviceId" element={<CustomerDeviceControl />} />
                <Route path="device/:deviceId/schedule" element={<CustomerSchedule />} />
                <Route path="device/:deviceId/sensors" element={<CustomerSensors />} />
                <Route path="device/:deviceId/wifi" element={<CustomerWifiSettings />} />
                <Route path="device/:deviceId/wifi/forget" element={<WifiHotspotGuide mode="forget" />} />
                <Route path="device/:deviceId/wifi/change" element={<WifiHotspotGuide mode="change" />} />
                <Route path="device/:deviceId/ultrasonic" element={<CustomerUltrasonicSettings />} />
                <Route path="*" element={<Navigate to="dashboard" />} />
              </Routes>
            </ProtectedRoute>
          } />

          {/* Legacy single-path routes for sales app compatibility */}
          <Route path="/scanner" element={<ProtectedRoute><QRScanner /></ProtectedRoute>} />
          <Route path="/assign/:device_id" element={<ProtectedRoute><AssignmentForm /></ProtectedRoute>} />
          <Route path="/wifi-setup" element={<ProtectedRoute><WifiSetup /></ProtectedRoute>} />
          <Route path="/success" element={<ProtectedRoute><Success /></ProtectedRoute>} />
          
          {/* Catch all */}
          <Route path="*" element={<Navigate to="/login" />} />
        </Routes>
        <Toaster position="top-right" />
      </BrowserRouter>
    </AuthProvider>
  );
}

export default App;
