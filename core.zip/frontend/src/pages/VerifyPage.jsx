import React, { useState, useEffect } from 'react';
import { useParams, useSearchParams } from 'react-router-dom';
import { deviceService } from '../api/services';
import { CheckCircle, XCircle, Loader2, ShieldCheck, Tablet, User } from 'lucide-react';

const VerifyPage = () => {
  const { deviceId: paramId } = useParams();
  const [searchParams] = useSearchParams();
  const [deviceId, setDeviceId] = useState(paramId || searchParams.get('id') || '');
  const [device, setDevice] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleVerify = async (idToVerify) => {
    if (!idToVerify) return;
    setLoading(true);
    setError(null);
    try {
      const res = await deviceService.verify(idToVerify);
      setDevice(res.data);
    } catch (err) {
      setError(err.response?.data?.error || "Invalid Device ID");
      setDevice(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (deviceId) handleVerify(deviceId);
  }, []);

  return (
    <div className="max-w-2xl mx-auto space-y-8 animate-in fade-in duration-500">
      <div className="text-center">
        <div className="w-16 h-16 bg-primary-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
          <ShieldCheck className="w-8 h-8 text-primary-600" />
        </div>
        <h1 className="text-3xl font-bold text-slate-900">Device Verification</h1>
        <p className="text-slate-500 mt-2">Scan a QR code or enter ID manually to verify authenticity.</p>
      </div>

      <div className="glass-card p-6">
        <div className="flex gap-3">
          <input 
            type="text" 
            className="input-field uppercase font-bold tracking-widest text-center text-xl"
            placeholder="e.g. INT-123"
            value={deviceId}
            onChange={(e) => setDeviceId(e.target.value.toUpperCase())}
          />
          <button 
            onClick={() => handleVerify(deviceId)}
            disabled={loading}
            className="btn-primary px-8"
          >
            {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : 'Verify'}
          </button>
        </div>
      </div>

      {device && (
        <div className="glass-card overflow-hidden animate-in slide-in-from-top duration-300">
          <div className="bg-emerald-500 p-6 text-white flex items-center justify-between">
            <div className="flex items-center gap-3">
              <CheckCircle className="w-8 h-8" />
              <div>
                <h3 className="text-xl font-bold">Valid Device</h3>
                <p className="text-emerald-100 text-sm">Genuine INT Security Hardware</p>
              </div>
            </div>
            <span className="text-3xl font-black opacity-30">{device.device_id}</span>
          </div>
          
          <div className="p-8 space-y-8">
            <div className="grid grid-cols-2 gap-8">
              <div className="space-y-1">
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Device ID</p>
                <div className="flex items-center gap-2 text-slate-800 font-bold">
                  <Tablet className="w-4 h-4 text-slate-400" />
                  {device.device_id}
                </div>
              </div>
              <div className="space-y-1">
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Status</p>
                <div className="flex items-center gap-2">
                  <div className={`w-2.5 h-2.5 rounded-full ${device.status === 'available' ? 'bg-emerald-500 animate-pulse' : 'bg-blue-500'}`}></div>
                  <span className={`font-bold capitalize ${device.status === 'available' ? 'text-emerald-600' : 'text-blue-600'}`}>
                    {device.status}
                  </span>
                </div>
              </div>
            </div>

            {device.assignment ? (
              <div className="bg-slate-50 rounded-2xl p-6 border border-slate-100 space-y-4">
                <div className="flex items-center gap-2 text-slate-800 font-bold border-b border-slate-200 pb-2">
                  <User className="w-4 h-4 text-primary-500" />
                  Assignment Information
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Shop Name</p>
                    <p className="text-slate-900 font-bold">{device.assignment.shop_name}</p>
                  </div>
                  <div>
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Owner</p>
                    <p className="text-slate-900 font-bold">{device.assignment.owner_name}</p>
                  </div>
                  <div>
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Phone</p>
                    <p className="text-slate-900 font-bold">{device.assignment.phone}</p>
                  </div>
                  <div>
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Assigned At</p>
                    <p className="text-slate-900 font-bold">{new Date(device.assignment.assigned_at).toLocaleDateString()}</p>
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-emerald-50 rounded-2xl p-6 border border-emerald-100 flex items-center gap-3">
                <CheckCircle className="w-6 h-6 text-emerald-500" />
                <div>
                  <p className="text-emerald-900 font-bold">Available for Assignment</p>
                  <p className="text-emerald-700 text-sm">This device is ready to be assigned to a new shop.</p>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {error && (
        <div className="glass-card p-12 text-center space-y-4 border-rose-100 bg-rose-50/30 animate-in zoom-in duration-300">
          <div className="w-20 h-20 bg-rose-100 rounded-full flex items-center justify-center mx-auto">
            <XCircle className="w-12 h-12 text-rose-500" />
          </div>
          <div>
            <h3 className="text-2xl font-bold text-slate-900">Invalid ID</h3>
            <p className="text-slate-500 mt-1">This device ID was not found in our secure database.</p>
          </div>
          <p className="text-sm text-rose-600 bg-rose-100/50 py-2 px-4 rounded-full inline-block font-bold">
            {error}
          </p>
        </div>
      )}
    </div>
  );
};

export default VerifyPage;
