#include <EEPROM.h>
#include <Servo.h>
#include <ESP8266WiFi.h>
#include <ESP8266WebServer.h>
#include <ESP8266HTTPClient.h>
#include <DNSServer.h>
#include <WiFiClientSecure.h>
#include <OneWire.h>
#include <DallasTemperature.h>

// NodeMCU pin map:
// HC-SR04 Trig -> D6, Echo -> D5
// SG90 servo signal -> D4
// Active buzzer -> D3
// DS18B20 data -> D7 (4.7k pull-up to 3.3V)
// Power LED -> D1, WiFi LED -> D2
#define TRIG_PIN D6
#define ECHO_PIN D5
#define BUZZER_PIN D3
#define SERVO_PIN D4
#define ONE_WIRE_BUS D7
#define POWER_LED_PIN D1
#define WIFI_LED_PIN D2
#define LED_PWM_LEVEL 64

#define SOUND_VELOCITY 0.034
#define EEPROM_SIZE 512
#define EEPROM_SSID_ADDR 64
#define EEPROM_PASS_ADDR 128
#define EEPROM_API_ADDR 192
#define EEPROM_DEVICE_ID_ADDR 320
#define EEPROM_TOKEN_ADDR 368
#define EEPROM_SHORT_LEN 64
#define EEPROM_API_LEN 128
#define EEPROM_TOKEN_LEN 96
#define IGNORE_PERCENT 0.17
#define MIN_DISTANCE 5
#define MAX_DISTANCE 400
// Ultrasonic: tighter echo timeout (~2.4 m), fewer samples/gaps = faster sweeps.
#define PULSE_TIMEOUT_US 30000
#define SCAN_PULSE_TIMEOUT_US 14000
#define CALIBRATION_SAMPLES 10
#define SCAN_SAMPLES 7
#define SERVO_STEP_DEG 4
#define SERVO_STEP_DELAY_MS 5
#define SERVO_SETTLE_MS 20
#define SERVO_AT_ANGLE_TOLERANCE 3
#define CALIBRATION_MAX_CM 200
#define MIN_INTRUSION_CM 22
#define HIT_REQUIRED 5
#define CLEAR_REQUIRED 4
#define OUTLIER_MAX_CM 7
#define READING_SPREAD_MAX_CM 9
#define INTRUDER_MAX_BURST_SPREAD_CM 7.0f
#define SAMPLE_GAP_MS 8
#define CONFIRM_READ_GAP_MS 24
#define CONFIRM_PAIR_MAX_DELTA_CM 5.0f
#define HUMAN_NEAR_MAX_CM 180
#define HUMAN_FAR_MIN_CM 35
#define OPEN_DETECT_MIN_CM 32
#define OPEN_DETECT_MAX_CM 130
#define OPEN_CALIB_HIT_REQUIRED 7
#define MAX_READ_SAMPLES 15
// Heat: 2°C vs oldest sample in 30s window (~29s warm-up with 1s history steps).
#define TEMP_RISE_WINDOW_MS 30000UL
#define TEMP_RISE_ALARM_C 2.0f
#define TEMP_HISTORY_SAMPLE_MS 1000UL
#define TEMP_HISTORY_MAX 36
#define TEMP_RISE_BEEP_REPEAT_MS 5000UL
#define TEMP_POLL_MS 2000UL
#define TWILIO_HEAT_CALL_COOLDOWN_MS 600000UL
#define TWILIO_POST_RETRIES 3
#define TWILIO_RETRY_GAP_MS 400UL
#define TWILIO_INTRUDER_MIN_RETRY_GAP_MS 25000UL

#define WIFI_SSID "facebook"
#define WIFI_PASS "12121212"
#define FORCE_DEFAULT_WIFI_ON_BOOT true
#define WIFI_CONNECT_TIMEOUT_MS 60000UL
#define WIFI_RETRY_MS 20000UL
#define WIFI_RECONNECT_TIMEOUT_MS 10000UL

// Setup hotspot (customer forget/change WiFi via phone)
#define AP_SSID_PREFIX "UltrasonicSetup-"
#define AP_PASSWORD "setup1234"
#define WIFI_FAIL_AP_TIMEOUT_MS 60000UL
#define STA_FAIL_BEFORE_AP 3

// Django IoT — customer portal controls device via these endpoints
#define API_BASE_URL "http://10.82.116.120:8000/api"
#define DEVICE_ID "26E13000028"
#define DEVICE_TOKEN "iCWKwcRYYIy48xzE7KQc8kAcYDzlbgVBc7fxT-P3yCA"
#define FIRMWARE_VERSION "1.0.0-django"
#define TELEMETRY_POST_MS 3000UL
#define COMMAND_POLL_MS 3000UL
#define DJANGO_SERIAL_BODY_MAX 512

#define TWILIO_ACCOUNT_SID "AC2d1161e4550d167d96e4c5b9dda5d6e35"
#define TWILIO_AUTH_TOKEN "6ed9b1311b15e52d0c981af74b051b4e5"
#define TWILIO_FROM_NUMBER "+17755996527"
#define TWILIO_TO_NUMBER "+918295110043"

Servo myServo;
ESP8266WebServer server(80);
DNSServer dnsServer;
OneWire oneWire(ONE_WIRE_BUS);
DallasTemperature sensors(&oneWire);

float savedDistance[3];
float currentDistance[3];
int angles[3] = {0, 90, 135};
int sweepPattern[4] = {0, 1, 2, 1};
uint8_t sweepStep = 0;
int currentServoAngle = 0;
bool ds18b20Present = false;
bool twilioCallSent = false;
bool intruderAlertBeeped = false;
uint8_t hitStreak[3] = {0, 0, 0};
uint8_t clearStreak = 0;
uint8_t lastValidSampleCount = 0;
float lastReadingSpreadCm = 0;
float lastTemperatureC = NAN;
unsigned long histTime[TEMP_HISTORY_MAX];
float histTemp[TEMP_HISTORY_MAX];
uint8_t histCount = 0;
unsigned long lastTempRiseBeepMs = 0;
unsigned long lastTempPollMs = 0;
unsigned long lastTwilioHeatCallMs = 0;
unsigned long lastTwilioIntruderAttemptMs = 0;
bool webServerBegun = false;
unsigned long lastWifiRetryMs = 0;
unsigned long lastTelemetryPostMs = 0;
unsigned long lastCommandPollMs = 0;
bool remoteEnabled = true;
bool djangoDesiredPower = true;
bool djangoScheduleGate = false;
bool djangoInScheduleWindow = true;
float runtimeIgnorePercent = IGNORE_PERCENT;
int runtimeMinIntrusionCm = MIN_INTRUSION_CM;
String wifiSsid = WIFI_SSID;
String wifiPass = WIFI_PASS;
String apiBaseUrl = API_BASE_URL;
String djangoDeviceId = DEVICE_ID;
String djangoDeviceToken = DEVICE_TOKEN;

String systemStatus = "SAFE";
String lastAlertAngle = "None";
bool configPortalActive = false;
bool configPortalForgetMode = false;
String apSsidName = "";
uint8_t staReconnectFailures = 0;
unsigned long lastWifiLedBlinkMs = 0;
bool wifiLedBlinkState = false;

void updateWifiLed();
void startWifiConfigPortal(bool forgetMode);
void runConfigPortalLoop();
void beep(int times, int durationMs);
bool sendTwilioVoiceSay(const char *sayPhrase, const char *debugTag);
bool tryIntruderTwilioOnce();
void performCalibration();

String readEepromString(int addr, int maxLen, const char *fallback) {
  String value = "";
  for (int i = 0; i < maxLen; i++) {
    char c = char(EEPROM.read(addr + i));
    if (c == '\0' || c == 255) break;
    value += c;
  }
  return value.length() > 0 ? value : String(fallback);
}

void writeEepromString(int addr, int maxLen, const String &value) {
  int limit = min(maxLen - 1, int(value.length()));
  for (int i = 0; i < maxLen; i++) EEPROM.write(addr + i, 0);
  for (int i = 0; i < limit; i++) EEPROM.write(addr + i, value[i]);
}

void loadStoredConfig() {
  wifiSsid = readEepromString(EEPROM_SSID_ADDR, EEPROM_SHORT_LEN, WIFI_SSID);
  wifiPass = readEepromString(EEPROM_PASS_ADDR, EEPROM_SHORT_LEN, WIFI_PASS);
  apiBaseUrl = readEepromString(EEPROM_API_ADDR, EEPROM_API_LEN, API_BASE_URL);
  djangoDeviceId = readEepromString(EEPROM_DEVICE_ID_ADDR, EEPROM_SHORT_LEN, DEVICE_ID);
  djangoDeviceToken = readEepromString(EEPROM_TOKEN_ADDR, EEPROM_TOKEN_LEN, DEVICE_TOKEN);

  if (FORCE_DEFAULT_WIFI_ON_BOOT) {
    String storedSsid = readEepromString(EEPROM_SSID_ADDR, EEPROM_SHORT_LEN, "");
    if (storedSsid.length() == 0) {
      wifiSsid = WIFI_SSID;
      wifiPass = WIFI_PASS;
      writeEepromString(EEPROM_SSID_ADDR, EEPROM_SHORT_LEN, wifiSsid);
      writeEepromString(EEPROM_PASS_ADDR, EEPROM_SHORT_LEN, wifiPass);
      EEPROM.commit();
    }
  }
}

void clearWifiCredentials() {
  writeEepromString(EEPROM_SSID_ADDR, EEPROM_SHORT_LEN, "");
  writeEepromString(EEPROM_PASS_ADDR, EEPROM_SHORT_LEN, "");
  EEPROM.commit();
  wifiSsid = "";
  wifiPass = "";
}

String htmlEscape(const String &s) {
  String out;
  out.reserve(s.length() + 8);
  for (unsigned int i = 0; i < s.length(); i++) {
    char c = s[i];
    if (c == '&') out += "&amp;";
    else if (c == '<') out += "&lt;";
    else if (c == '>') out += "&gt;";
    else if (c == '"') out += "&quot;";
    else out += c;
  }
  return out;
}

String buildApSsid() {
  String id = djangoDeviceId;
  if (id.length() == 0 || id == "CHANGE_ME") {
    id = String(ESP.getChipId(), HEX);
  }
  String suffix = id.substring(id.length() > 4 ? id.length() - 4 : 0);
  suffix.toUpperCase();
  return String(AP_SSID_PREFIX) + suffix;
}

void handleCaptiveRedirect() {
  server.sendHeader("Location", "http://192.168.4.1/", true);
  server.send(302, "text/plain", "Redirecting to setup...");
}

void handleSetupRoot() {
  String mode = server.arg("mode");
  bool forget = configPortalForgetMode || mode == "forget";
  String prefillSsid = forget ? "" : wifiSsid;
  String prefillPass = forget ? "" : "";

  String html = "<!DOCTYPE html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'>";
  html += "<title>WiFi Setup</title>";
  html += "<style>body{font-family:sans-serif;background:#0f172a;color:#fff;padding:20px;max-width:420px;margin:0 auto}";
  html += "h1{font-size:1.5rem}input{width:100%;padding:14px;margin:8px 0;border-radius:12px;border:none;font-size:16px;box-sizing:border-box}";
  html += "button{width:100%;padding:16px;margin-top:12px;border-radius:12px;border:none;background:#4f46e5;color:#fff;font-weight:bold;font-size:16px}";
  html += ".hint{color:#94a3b8;font-size:14px;line-height:1.5}</style></head><body>";
  html += "<h1>Shop WiFi Setup</h1>";
  if (forget) {
    html += "<p class='hint'>Forget mode: enter new WiFi name and password. Device will reboot and connect.</p>";
  } else {
    html += "<p class='hint'>Change mode: update password or network. Same WiFi name is pre-filled if saved.</p>";
  }
  html += "<form method='POST' action='/save'>";
  html += "<input name='ssid' placeholder='WiFi name (SSID)' value='" + htmlEscape(prefillSsid) + "' required>";
  html += "<input name='password' type='password' placeholder='WiFi password' value='" + htmlEscape(prefillPass) + "' required>";
  if (forget) html += "<input type='hidden' name='forget' value='1'>";
  html += "<button type='submit'>Save and reconnect</button></form></body></html>";
  server.send(200, "text/html", html);
}

void handleSetupSave() {
  String ssid = server.arg("ssid");
  String pass = server.arg("password");
  bool forget = configPortalForgetMode || server.arg("forget") == "1";

  if (ssid.length() == 0 || pass.length() == 0) {
    server.send(400, "text/plain", "SSID and password required");
    return;
  }

  if (forget) clearWifiCredentials();
  saveWifiCredentials(ssid, pass);

  String html = "<!DOCTYPE html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'>";
  html += "<style>body{font-family:sans-serif;background:#14532d;color:#fff;text-align:center;padding:40px 20px}</style></head><body>";
  html += "<h1>Saved</h1><p>Connecting to " + htmlEscape(ssid) + "… Rebooting now.</p></body></html>";
  server.send(200, "text/html", html);
  Serial.println("WiFi saved via setup portal — rebooting");
  delay(1500);
  ESP.restart();
}

void startWifiConfigPortal(bool forgetMode) {
  if (configPortalActive) return;

  configPortalForgetMode = forgetMode;
  configPortalActive = true;
  webServerBegun = false;
  staReconnectFailures = 0;

  WiFi.disconnect(true);
  delay(200);

  apSsidName = buildApSsid();
  WiFi.mode(WIFI_AP);
  WiFi.softAPConfig(IPAddress(192, 168, 4, 1), IPAddress(192, 168, 4, 1), IPAddress(255, 255, 255, 0));
  WiFi.softAP(apSsidName.c_str(), AP_PASSWORD);

  server.stop();
  server.on("/", handleSetupRoot);
  server.on("/setup", handleSetupRoot);
  server.on("/save", HTTP_POST, handleSetupSave);
  server.onNotFound(handleCaptiveRedirect);
  server.begin();

  dnsServer.stop();
  dnsServer.start(53, "*", WiFi.softAPIP());

  Serial.println();
  Serial.println("=== WiFi SETUP HOTSPOT ACTIVE ===");
  Serial.print("Join WiFi: ");
  Serial.println(apSsidName);
  Serial.print("Password: ");
  Serial.println(AP_PASSWORD);
  Serial.println("Open http://192.168.4.1 in your browser");
  if (forgetMode) Serial.println("Mode: FORGET (clears old WiFi on save)");
  else Serial.println("Mode: CHANGE");
  Serial.println("=================================");
}

void updateWifiLedPortalBlink() {
  unsigned long now = millis();
  if (now - lastWifiLedBlinkMs < 400) return;
  lastWifiLedBlinkMs = now;
  wifiLedBlinkState = !wifiLedBlinkState;
  setIndicatorLed(WIFI_LED_PIN, wifiLedBlinkState);
}

void runConfigPortalLoop() {
  dnsServer.processNextRequest();
  server.handleClient();
  updateWifiLedPortalBlink();
  delay(5);
}

void saveWifiCredentials(const String &ssid, const String &password) {
  writeEepromString(EEPROM_SSID_ADDR, EEPROM_SHORT_LEN, ssid);
  writeEepromString(EEPROM_PASS_ADDR, EEPROM_SHORT_LEN, password);
  EEPROM.commit();
  wifiSsid = ssid;
  wifiPass = password;
}

String jsonStringValue(const String &json, const String &key, const String &fallback = "") {
  int keyPos = json.indexOf("\"" + key + "\"");
  if (keyPos < 0) return fallback;
  int colon = json.indexOf(':', keyPos);
  int firstQuote = json.indexOf('"', colon + 1);
  int secondQuote = json.indexOf('"', firstQuote + 1);
  if (colon < 0 || firstQuote < 0 || secondQuote < 0) return fallback;
  return json.substring(firstQuote + 1, secondQuote);
}

int jsonIntValue(const String &json, const String &key, int fallback = 0) {
  int keyPos = json.indexOf("\"" + key + "\"");
  if (keyPos < 0) return fallback;
  int colon = json.indexOf(':', keyPos);
  if (colon < 0) return fallback;
  return json.substring(colon + 1).toInt();
}

float jsonFloatValue(const String &json, const String &key, float fallback) {
  int keyPos = json.indexOf("\"" + key + "\"");
  if (keyPos < 0) return fallback;
  int colon = json.indexOf(':', keyPos);
  if (colon < 0) return fallback;
  return json.substring(colon + 1).toFloat();
}

bool jsonBoolValue(const String &json, const String &key, bool fallback) {
  int keyPos = json.indexOf("\"" + key + "\"");
  if (keyPos < 0) return fallback;
  int colon = json.indexOf(':', keyPos);
  if (colon < 0) return fallback;
  int valueStart = colon + 1;
  while (valueStart < (int)json.length() && json[valueStart] == ' ') valueStart++;
  if (json.startsWith("true", valueStart)) return true;
  if (json.startsWith("false", valueStart)) return false;
  return fallback;
}

void initWifiStack() {
  WiFi.persistent(false);
  WiFi.setAutoReconnect(true);
  WiFi.setSleepMode(WIFI_NONE_SLEEP);
}

void logWifiStatus() {
  Serial.print("WiFi status ");
  Serial.print(WiFi.status());
  Serial.print(" = ");
  switch (WiFi.status()) {
    case WL_IDLE_STATUS: Serial.println("IDLE"); break;
    case WL_NO_SSID_AVAIL: Serial.println("NO_SSID (wrong name or 5 GHz only)"); break;
    case WL_SCAN_COMPLETED: Serial.println("SCAN_COMPLETED"); break;
    case WL_CONNECTED: Serial.println("CONNECTED"); break;
    case WL_CONNECT_FAILED: Serial.println("CONNECT_FAILED (wrong password?)"); break;
    case WL_CONNECTION_LOST: Serial.println("CONNECTION_LOST"); break;
    case WL_DISCONNECTED: Serial.println("DISCONNECTED"); break;
    default: Serial.println("UNKNOWN"); break;
  }
}

bool connectWifi(const String &ssid, const String &password, unsigned long timeoutMs) {
  if (ssid.length() == 0) {
    Serial.println("WiFi: SSID is empty — set WIFI_SSID in code.");
    return false;
  }

  Serial.print("Connecting to SSID: ");
  Serial.println(ssid);

  initWifiStack();
  WiFi.mode(WIFI_STA);
  WiFi.disconnect(true);
  delay(100);
  WiFi.hostname("ultrasonic-security");
  WiFi.begin(ssid.c_str(), password.c_str());

  unsigned long started = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - started < timeoutMs) {
    updateWifiLed();
    yield();
    delay(150);
    Serial.print(".");
  }
  Serial.println();
  updateWifiLed();

  if (WiFi.status() == WL_CONNECTED) {
    Serial.print("WiFi OK — IP: ");
    Serial.println(WiFi.localIP());
    Serial.print("RSSI: ");
    Serial.print(WiFi.RSSI());
    Serial.println(" dBm");
    return true;
  }

  logWifiStatus();
  return false;
}

void maintainWifi() {
  if (configPortalActive) return;

  if (WiFi.status() == WL_CONNECTED) {
    staReconnectFailures = 0;
    if (!webServerBegun) {
      server.on("/", handleRoot);
      server.begin();
      webServerBegun = true;
      Serial.print("Dashboard: http://");
      Serial.println(WiFi.localIP());
    }
    server.handleClient();
    return;
  }

  webServerBegun = false;
  if (millis() - lastWifiRetryMs < WIFI_RETRY_MS) return;
  lastWifiRetryMs = millis();

  Serial.println("WiFi lost — reconnecting...");
  if (connectWifi(wifiSsid, wifiPass, WIFI_RECONNECT_TIMEOUT_MS)) {
    staReconnectFailures = 0;
    return;
  }

  if (wifiSsid != WIFI_SSID && wifiSsid.length() > 0) {
    Serial.println("Retrying default WIFI_SSID from code...");
    if (connectWifi(WIFI_SSID, WIFI_PASS, WIFI_RECONNECT_TIMEOUT_MS)) {
      saveWifiCredentials(WIFI_SSID, WIFI_PASS);
      staReconnectFailures = 0;
      return;
    }
  }

  staReconnectFailures++;
  if (staReconnectFailures >= STA_FAIL_BEFORE_AP) {
    Serial.println("WiFi failed repeatedly — opening setup hotspot");
    startWifiConfigPortal(false);
  }
}

void setIndicatorLed(uint8_t pin, bool on) {
  analogWrite(pin, on ? LED_PWM_LEVEL : 0);
}

void updatePowerLed() {
  setIndicatorLed(POWER_LED_PIN, true);
}

void updateWifiLed() {
  setIndicatorLed(WIFI_LED_PIN, WiFi.status() == WL_CONNECTED);
}

bool readTempCelsius(float *outC) {
  for (uint8_t attempt = 0; attempt < 4; attempt++) {
    if (attempt) delay(40);
    yield();
    sensors.requestTemperatures();
    yield();
    float c = sensors.getTempCByIndex(0);
    if (c != DEVICE_DISCONNECTED_C && c >= -55.0f && c <= 125.0f) {
      *outC = c;
      return true;
    }
  }
  return false;
}

void pruneTempHistory(unsigned long nowMs) {
  while (histCount > 0 && nowMs - histTime[0] > TEMP_RISE_WINDOW_MS) {
    for (uint8_t i = 0; i + 1 < histCount; i++) {
      histTime[i] = histTime[i + 1];
      histTemp[i] = histTemp[i + 1];
    }
    histCount--;
  }
}

void appendTempHistory(float tempC, unsigned long nowMs) {
  static unsigned long lastHistSampleMs = 0;
  pruneTempHistory(nowMs);
  if (histCount > 0 && nowMs - lastHistSampleMs < TEMP_HISTORY_SAMPLE_MS) return;
  lastHistSampleMs = nowMs;
  if (histCount >= TEMP_HISTORY_MAX) {
    for (uint8_t i = 0; i + 1 < TEMP_HISTORY_MAX; i++) {
      histTime[i] = histTime[i + 1];
      histTemp[i] = histTemp[i + 1];
    }
    histCount = TEMP_HISTORY_MAX - 1;
  }
  histTime[histCount] = nowMs;
  histTemp[histCount] = tempC;
  histCount++;
}

bool getRiseReferenceTemp(unsigned long nowMs, float *refOut) {
  pruneTempHistory(nowMs);
  if (histCount == 0) return false;
  unsigned long ageOldest = nowMs - histTime[0];
  if (ageOldest < TEMP_RISE_WINDOW_MS - TEMP_HISTORY_SAMPLE_MS) return false;
  *refOut = histTemp[0];
  return true;
}

void checkTempRiseAlarm(float currentC, unsigned long nowMs) {
  float refC;
  if (!getRiseReferenceTemp(nowMs, &refC)) return;

  float rise = currentC - refC;
  if (rise < TEMP_RISE_ALARM_C) {
    lastTempRiseBeepMs = 0;
    return;
  }

  if (lastTempRiseBeepMs == 0 || (nowMs - lastTempRiseBeepMs >= TEMP_RISE_BEEP_REPEAT_MS)) {
    lastTempRiseBeepMs = nowMs;
    Serial.print("TEMP RISE ALARM: +");
    Serial.print(rise, 1);
    Serial.print(" C vs ref ");
    Serial.print(refC, 1);
    Serial.println(" C (30s sliding window)");
    if (lastTwilioHeatCallMs == 0 ||
        (nowMs - lastTwilioHeatCallMs >= TWILIO_HEAT_CALL_COOLDOWN_MS)) {
      if (sendTwilioVoiceSay(
              "Temperature rose two degrees in thirty seconds. Check the shop.",
              "heat")) {
        lastTwilioHeatCallMs = nowMs;
      }
    }
    beep(6, 70);
  }
}

// Poll from loop() on TEMP_POLL_MS so the 30s rise window tracks wall time.
void reportTemperature() {
  if (!ds18b20Present) return;

  unsigned long nowMs = millis();
  float tempC;
  if (readTempCelsius(&tempC)) {
    lastTemperatureC = tempC;
    appendTempHistory(tempC, nowMs);
    checkTempRiseAlarm(tempC, nowMs);
    Serial.print("Temperature: ");
    Serial.print(tempC);
    Serial.println(" C");
  } else {
    lastTemperatureC = NAN;
    Serial.println("Temperature: read failed");
  }
}

void handleRoot() {
  String html = "<!DOCTYPE html><html><head><meta name='viewport' content='width=device-width, initial-scale=1'>";
  html += "<meta http-equiv='refresh' content='2'>";

  if (systemStatus == "SAFE") {
    html += "<style>body { background-color: #1b5e20; color: white; font-family: sans-serif; text-align: center; padding-top: 30%; }</style>";
    html += "</head><body><h1 style='font-size: 55px;'>SECURE</h1><h2>Scanning Area...</h2>";
  } else {
    html += "<style>body { background-color: #b71c1c; color: white; font-family: sans-serif; text-align: center; padding-top: 30%; }</style>";
    html += "</head><body><h1 style='font-size: 55px;'>ALERT!</h1><h2>Intruder at " + lastAlertAngle + " deg</h2>";
  }

  if (!isnan(lastTemperatureC)) {
    html += "<p style='font-size: 20px; margin-top: 18px;'>Temperature: " + String(lastTemperatureC, 1) + " C</p>";
  }
  html += "</body></html>";

  server.send(200, "text/html", html);
}

void smoothMoveStep(int targetAngle) {
  targetAngle = constrain(targetAngle, 0, 180);
  if (currentServoAngle == targetAngle) return;

  int diff = targetAngle - currentServoAngle;
  int step = (diff > 0) ? SERVO_STEP_DEG : -SERVO_STEP_DEG;
  if (abs(diff) < abs(step)) {
    currentServoAngle = targetAngle;
  } else {
    currentServoAngle += step;
  }
  myServo.write(currentServoAngle);
  delay(SERVO_STEP_DELAY_MS);
  if (webServerBegun && WiFi.status() == WL_CONNECTED) server.handleClient();
}

void smoothMove(int targetAngle) {
  targetAngle = constrain(targetAngle, 0, 180);
  while (currentServoAngle != targetAngle) {
    smoothMoveStep(targetAngle);
  }
}

float medianOfSorted(float *values, int count) {
  if (count <= 0) return 0;
  if (count % 2 == 1) return values[count / 2];
  return (values[count / 2 - 1] + values[count / 2]) / 2.0f;
}

void sortFloatArray(float *values, int count) {
  for (int i = 1; i < count; i++) {
    float key = values[i];
    int j = i - 1;
    while (j >= 0 && values[j] > key) {
      values[j + 1] = values[j];
      j--;
    }
    values[j + 1] = key;
  }
}

float readSingleDistanceCm(unsigned int pulseTimeoutUs) {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);
  long duration = pulseIn(ECHO_PIN, HIGH, pulseTimeoutUs);
  if (duration <= 0) return 0;
  float distance = duration * SOUND_VELOCITY / 2.0f;
  if (distance < MIN_DISTANCE || distance > MAX_DISTANCE) return 0;
  return distance;
}

float readDistanceCm(int samples, bool serviceWeb, unsigned int pulseTimeoutUs) {
  if (samples > MAX_READ_SAMPLES) samples = MAX_READ_SAMPLES;
  float readings[MAX_READ_SAMPLES];
  int valid = 0;

  for (int i = 0; i < samples; i++) {
    float distance = readSingleDistanceCm(pulseTimeoutUs);
    if (distance > 0) readings[valid++] = distance;
    if (serviceWeb && webServerBegun && WiFi.status() == WL_CONNECTED) server.handleClient();
    yield();
    delay(SAMPLE_GAP_MS);
  }

  lastValidSampleCount = valid;
  if (valid < (samples + 1) / 2) return 0;

  sortFloatArray(readings, valid);
  float median = medianOfSorted(readings, valid);

  float filtered[MAX_READ_SAMPLES];
  int filteredCount = 0;
  for (int i = 0; i < valid; i++) {
    if (fabs(readings[i] - median) <= OUTLIER_MAX_CM) {
      filtered[filteredCount++] = readings[i];
    }
  }

  if (filteredCount < (samples + 1) / 2) return 0;
  sortFloatArray(filtered, filteredCount);
  lastReadingSpreadCm = filtered[filteredCount - 1] - filtered[0];
  if (lastReadingSpreadCm > READING_SPREAD_MAX_CM) return 0;
  return medianOfSorted(filtered, filteredCount);
}

float combineDistanceReads(float readingA, float readingB) {
  if (readingA <= 0 && readingB <= 0) return 0;
  if (readingA <= 0) return readingB;
  if (readingB <= 0) return readingA;
  if (fabs(readingA - readingB) > CONFIRM_PAIR_MAX_DELTA_CM) return 0;
  return (readingA + readingB) * 0.5f;
}

int requiredDropForBase(float baseCm) {
  int minDrop = runtimeMinIntrusionCm;
  if (baseCm < 90.0f) minDrop = 18;
  else if (baseCm < 140.0f) minDrop = 22;
  else minDrop = 26;
  float percentDrop = baseCm * runtimeIgnorePercent;
  if (percentDrop < minDrop) return minDrop;
  return int(percentDrop + 0.5f);
}

bool isHumanRange(float distanceCm) {
  return distanceCm >= HUMAN_FAR_MIN_CM && distanceCm <= HUMAN_NEAR_MAX_CM;
}

bool isIntruderCandidate(int angleIndex, float distance) {
  if (distance <= 0) return false;
  if (!isHumanRange(distance)) return false;

  if (savedDistance[angleIndex] > 0) {
    float base = savedDistance[angleIndex];
    float threshold = base * (1.0f - runtimeIgnorePercent);
    int requiredDrop = requiredDropForBase(base);
    float delta = base - distance;
    return distance < threshold && delta >= requiredDrop;
  }

  return distance >= OPEN_DETECT_MIN_CM && distance <= OPEN_DETECT_MAX_CM;
}

float readDistanceConfirmed(bool serviceWeb, unsigned int pulseTimeoutUs) {
  float first = readDistanceCm(SCAN_SAMPLES, serviceWeb, pulseTimeoutUs);
  delay(CONFIRM_READ_GAP_MS);
  float second = readDistanceCm(SCAN_SAMPLES, serviceWeb, pulseTimeoutUs);
  return combineDistanceReads(first, second);
}

String twilioUrlEncode(const String &s) {
  String e;
  const char *hex = "0123456789ABCDEF";

  for (unsigned int i = 0; i < s.length(); i++) {
    char c = s[i];

    if ((c >= 'A' && c <= 'Z') ||
        (c >= 'a' && c <= 'z') ||
        (c >= '0' && c <= '9') ||
        c == '-' || c == '_' || c == '.' || c == '~') {
      e += c;
    } else if (c == ' ') {
      e += '+';
    } else {
      e += '%';
      e += hex[((unsigned char)c) >> 4];
      e += hex[((unsigned char)c) & 15];
    }
  }

  return e;
}

bool sendTwilioVoiceSay(const char *sayPhrase, const char *debugTag) {
  if (WiFi.status() != WL_CONNECTED) {
    Serial.print("[Twilio/");
    Serial.print(debugTag);
    Serial.println("] skip: WiFi not connected");
    return false;
  }

  String url =
    String("https://api.twilio.com/2010-04-01/Accounts/")
    + TWILIO_ACCOUNT_SID +
    "/Calls.json";

  String twiml =
    String("<Response><Say voice=\"alice\">") + sayPhrase + "</Say></Response>";

  String body =
    "To=" + twilioUrlEncode(TWILIO_TO_NUMBER) +
    "&From=" + twilioUrlEncode(TWILIO_FROM_NUMBER) +
    "&Twiml=" + twilioUrlEncode(twiml);

  for (int attempt = 1; attempt <= TWILIO_POST_RETRIES; attempt++) {
    Serial.print("[Twilio/");
    Serial.print(debugTag);
    Serial.print("] try ");
    Serial.print(attempt);
    Serial.print("/");
    Serial.print(TWILIO_POST_RETRIES);
    Serial.print(" heap=");
    Serial.print(ESP.getFreeHeap());
    Serial.print(" RSSI=");
    Serial.println(WiFi.RSSI());

    WiFiClientSecure ssl;
    ssl.setInsecure();
    ssl.setTimeout(20000);

    HTTPClient http;
    if (!http.begin(ssl, url)) {
      Serial.println("[Twilio] http.begin failed");
      delay(TWILIO_RETRY_GAP_MS);
      yield();
      continue;
    }

    http.setAuthorization(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN);
    http.setTimeout(25000);
    http.addHeader("Content-Type", "application/x-www-form-urlencoded");

    int code = http.POST(body);
    String resp = http.getString();
    http.end();
    ssl.stop();

    Serial.print("[Twilio/");
    Serial.print(debugTag);
    Serial.print("] HTTP ");
    Serial.print(code);
    if (code < 0) {
      Serial.print(" (");
      Serial.print(http.errorToString(code));
      Serial.print(")");
    }
    Serial.println();

    if (resp.length() > 0 && (code < 200 || code >= 300)) {
      unsigned int n = resp.length();
      if (n > 280) n = 280;
      Serial.print("[Twilio] body ");
      Serial.println(resp.substring(0, n));
    }

    if (code >= 200 && code < 300)
      return true;

    delay(TWILIO_RETRY_GAP_MS + (attempt * 200));
    yield();
  }

  return false;
}

bool tryIntruderTwilioOnce() {
  unsigned long now = millis();
  if (lastTwilioIntruderAttemptMs != 0 &&
      now - lastTwilioIntruderAttemptMs < TWILIO_INTRUDER_MIN_RETRY_GAP_MS)
    return false;
  lastTwilioIntruderAttemptMs = now;
  return sendTwilioVoiceSay(
    "your shop is under threat, please take required action",
    "intruder");
}

void beep(int times, int durationMs) {
  for (int i = 0; i < times; i++) {
    digitalWrite(BUZZER_PIN, HIGH);
    delay(durationMs);
    digitalWrite(BUZZER_PIN, LOW);
    delay(durationMs);
  }
}

String jsonEscape(String value) {
  value.replace("\\", "\\\\");
  value.replace("\"", "\\\"");
  return value;
}

bool djangoIoTConfigured() {
  return djangoDeviceId.length() > 0 && djangoDeviceId != "CHANGE_ME" &&
         djangoDeviceToken.length() > 0 && djangoDeviceToken != "CHANGE_ME";
}

void serialLogDjangoHttp(const char *tag, const char *method, const String &url, int httpCode, const String &body) {
  Serial.println();
  Serial.print("[Django/");
  Serial.print(tag);
  Serial.print("] ");
  Serial.print(method);
  Serial.print(" ");
  Serial.println(url);
  Serial.print("[Django/");
  Serial.print(tag);
  Serial.print("] HTTP ");
  Serial.println(httpCode);
  if (httpCode < 0) {
    Serial.println("[Django] body: (no response — run Django on 0.0.0.0:8000, fix API_BASE_URL IP)");
    Serial.println();
    return;
  }
  if (body.length() == 0) {
    Serial.println("[Django] body: (empty)");
  } else {
    unsigned int n = body.length();
    if (n > DJANGO_SERIAL_BODY_MAX) n = DJANGO_SERIAL_BODY_MAX;
    Serial.print("[Django] body (");
    Serial.print(body.length());
    Serial.println(" bytes):");
    Serial.println(body.substring(0, n));
    if (body.length() > DJANGO_SERIAL_BODY_MAX)
      Serial.println("[Django] ...(truncated)");
  }
  Serial.println();
}

void printDjangoIoTConfig() {
  Serial.println("--- Django IoT ---");
  Serial.print("API: ");
  Serial.println(apiBaseUrl);
  Serial.print("Device: ");
  Serial.println(djangoDeviceId);
  Serial.println("Poll /commands/ and POST /telemetry/ every 3s");
  Serial.println("Portal -> Django :8000 -> ESP (not Vite npx port)");
  if (!djangoIoTConfigured())
    Serial.println("WARN: Set DEVICE_ID and DEVICE_TOKEN in sketch");
  Serial.println("----------------");
}

void postCommandAck(int commandRevision, int wifiRevision, String wifiStatus, int ultrasonicRevision, String ultrasonicStatus) {
  if (WiFi.status() != WL_CONNECTED || !djangoIoTConfigured()) return;

  HTTPClient http;
  String url = apiBaseUrl + "/iot/devices/" + djangoDeviceId + "/commands/ack/";
  WiFiClient httpClient;
  http.begin(httpClient, url);
  http.setTimeout(6000);
  http.addHeader("Content-Type", "application/json");
  http.addHeader("X-Device-Token", djangoDeviceToken);

  String body = "{";
  bool hasField = false;
  if (commandRevision >= 0) {
    body += "\"command_revision\":" + String(commandRevision);
    hasField = true;
  }
  if (wifiRevision >= 0) {
    if (hasField) body += ",";
    body += "\"wifi_revision\":" + String(wifiRevision) + ",\"wifi_status\":\"" + wifiStatus + "\",\"wifi_ssid\":\"" + jsonEscape(wifiSsid) + "\"";
    hasField = true;
  }
  if (ultrasonicRevision >= 0) {
    if (hasField) body += ",";
    body += "\"ultrasonic_revision\":" + String(ultrasonicRevision) + ",\"ultrasonic_status\":\"" + ultrasonicStatus + "\"";
  }
  body += "}";

  int code = http.POST(body);
  String resp = http.getString();
  serialLogDjangoHttp("ack", "POST", url, code, resp);
  http.end();
}

void postTelemetry() {
  if (WiFi.status() != WL_CONNECTED || millis() - lastTelemetryPostMs < TELEMETRY_POST_MS) return;
  if (!djangoIoTConfigured()) return;
  lastTelemetryPostMs = millis();

  HTTPClient http;
  String url = apiBaseUrl + "/iot/devices/" + djangoDeviceId + "/telemetry/";
  WiFiClient httpClient;
  http.begin(httpClient, url);
  http.setTimeout(6000);
  http.addHeader("Content-Type", "application/json");
  http.addHeader("X-Device-Token", djangoDeviceToken);

  float distance = currentDistance[1] > 0 ? currentDistance[1] : 0;
  String tempValue = isnan(lastTemperatureC) ? "null" : String(lastTemperatureC, 2);
  String body = "{";
  body += "\"temperature\":" + tempValue + ",";
  body += "\"ultrasonic_distance\":" + String(distance, 2) + ",";
  body += "\"heat_alarm\":" + String(lastTempRiseBeepMs > 0 ? "true" : "false") + ",";
  body += "\"status\":\"" + systemStatus + "\",";
  body += "\"armed\":" + String(remoteEnabled ? "true" : "false") + ",";
  body += "\"online\":true,";
  body += "\"firmware_version\":\"" + String(FIRMWARE_VERSION) + "\"";
  body += "}";

  int code = http.POST(body);
  String resp = http.getString();
  serialLogDjangoHttp("telemetry", "POST", url, code, body + " -> " + resp);
  http.end();
}

void applyWifiUpdate(String newSsid, String newPass, int revision) {
  if (newSsid.length() == 0 || revision <= 0) return;
  String oldSsid = wifiSsid;
  String oldPass = wifiPass;

  Serial.println("Applying WiFi update from Django...");
  WiFi.disconnect();
  delay(300);
  if (connectWifi(newSsid, newPass, 20000UL)) {
    saveWifiCredentials(newSsid, newPass);
    Serial.println("WiFi update OK.");
    postCommandAck(-1, revision, "success", -1, "");
    return;
  }
  Serial.println("WiFi update failed — reverting.");
  WiFi.disconnect();
  delay(300);
  connectWifi(oldSsid, oldPass, 20000UL);
  postCommandAck(-1, revision, "failed", -1, "");
}

void pollDjangoCommands() {
  if (WiFi.status() != WL_CONNECTED || millis() - lastCommandPollMs < COMMAND_POLL_MS) return;
  if (!djangoIoTConfigured()) return;
  lastCommandPollMs = millis();

  HTTPClient http;
  String url = apiBaseUrl + "/iot/devices/" + djangoDeviceId + "/commands/";
  WiFiClient httpClient;
  http.begin(httpClient, url);
  http.setTimeout(6000);
  http.addHeader("X-Device-Token", djangoDeviceToken);
  int code = http.GET();
  String payload = http.getString();
  serialLogDjangoHttp("commands", "GET", url, code, payload);

  if (code == 200) {
    bool prevRemote = remoteEnabled;
    djangoDesiredPower = jsonBoolValue(payload, "desired_power_state", djangoDesiredPower);
    djangoScheduleGate = jsonBoolValue(payload, "schedule_gate_active", djangoScheduleGate);
    djangoInScheduleWindow = jsonBoolValue(payload, "in_schedule_window", djangoInScheduleWindow);
    int commandRevision = jsonIntValue(payload, "command_revision", -1);
    int powerPos = payload.indexOf("\"power\"");
    String powerSection = powerPos >= 0 ? payload.substring(powerPos) : payload;
    remoteEnabled = jsonBoolValue(powerSection, "enabled", remoteEnabled);

    if (remoteEnabled != prevRemote) {
      Serial.print("[IoT] Scanning ");
      Serial.println(remoteEnabled ? "ON" : "OFF");
    }

    postCommandAck(commandRevision, -1, "", -1, "");

    int wifiPos = payload.indexOf("wifi_update");
    if (wifiPos >= 0) {
      String wifiSection = payload.substring(wifiPos);
      int wifiRevision = jsonIntValue(wifiSection, "revision", -1);
      String newSsid = jsonStringValue(wifiSection, "ssid", "");
      String newPass = jsonStringValue(wifiSection, "password", "");
      if (newSsid.length() > 0 && newPass.length() > 0 && wifiRevision > 0)
        applyWifiUpdate(newSsid, newPass, wifiRevision);
    }

    int ultrasonicPos = payload.indexOf("ultrasonic_update");
    if (ultrasonicPos >= 0) {
      String ultrasonicSection = payload.substring(ultrasonicPos);
      int configPos = ultrasonicSection.indexOf("\"config\"");
      String configSection = configPos >= 0 ? ultrasonicSection.substring(configPos) : ultrasonicSection;
      float ignorePercent = jsonFloatValue(configSection, "ignore_percent", runtimeIgnorePercent);
      int minIntrusion = jsonIntValue(configSection, "min_intrusion_cm", runtimeMinIntrusionCm);
      bool recalibrate = jsonBoolValue(configSection, "recalibrate", false);
      int ultrasonicRevision = jsonIntValue(ultrasonicSection, "revision", -1);
      if (ignorePercent > 0.0f) runtimeIgnorePercent = ignorePercent;
      if (minIntrusion > 0) runtimeMinIntrusionCm = minIntrusion;
      if (recalibrate) performCalibration();
      if (ultrasonicRevision > 0) postCommandAck(-1, -1, "", ultrasonicRevision, "success");
    }
  }

  http.end();
}

void performCalibration() {
  Serial.println("Starting Calibration Phase...");
  delay(400);

  for (int i = 0; i < 3; i++) {
    smoothMove(angles[i]);
    delay(SERVO_SETTLE_MS);
    readDistanceCm(1, false, PULSE_TIMEOUT_US);
    savedDistance[i] = readDistanceCm(CALIBRATION_SAMPLES, true, PULSE_TIMEOUT_US);
    int retries = 0;
    while (savedDistance[i] == 0.00f && retries < 3) {
      delay(150);
      savedDistance[i] = readDistanceCm(CALIBRATION_SAMPLES, true, PULSE_TIMEOUT_US);
      retries++;
    }
    if (savedDistance[i] > CALIBRATION_MAX_CM) {
      Serial.print(" (");
      Serial.print(savedDistance[i]);
      Serial.println(" cm unreliable — using OPEN)");
      savedDistance[i] = 0;
    }
    EEPROM.put(i * sizeof(float), savedDistance[i]);
    Serial.print("Calibrated Angle ");
    Serial.print(angles[i]);
    Serial.print(" deg => Base: ");
    if (savedDistance[i] == 0) Serial.println("OPEN SPACE");
    else {
      Serial.print(savedDistance[i]);
      Serial.println(" cm");
    }
  }
  EEPROM.commit();
}

bool processUltrasonicSweep(bool &alertTriggeredThisCycle, bool &candidateThisCycle, String &detectedAngle) {
  static bool cycleAlert = false;
  static bool cycleCandidate = false;
  static String cycleDetectedAngle = "";
  static bool sweepReadyToScan = false;

  alertTriggeredThisCycle = false;
  candidateThisCycle = false;
  detectedAngle = "";

  int i = sweepPattern[sweepStep];
  int target = angles[i];

  if (abs(currentServoAngle - target) > SERVO_AT_ANGLE_TOLERANCE) {
    sweepReadyToScan = false;
    smoothMoveStep(target);
    return false;
  }

  if (!sweepReadyToScan) {
    sweepReadyToScan = true;
    delay(SERVO_SETTLE_MS);
  }

  EEPROM.get(i * sizeof(float), savedDistance[i]);
  currentDistance[i] = readDistanceConfirmed(true, SCAN_PULSE_TIMEOUT_US);
  sweepReadyToScan = false;

  bool echoStable =
    currentDistance[i] > 0.0f &&
    lastReadingSpreadCm <= INTRUDER_MAX_BURST_SPREAD_CM;
  bool candidate =
      echoStable && isIntruderCandidate(i, currentDistance[i]);
  if (candidate) {
    cycleCandidate = true;
    if (hitStreak[i] < 255) hitStreak[i]++;

    if (!twilioCallSent) {
      Serial.println();
      Serial.println("Candidate detected — Twilio (if due)");
      lastAlertAngle = String(angles[i]);
      systemStatus = "ALERT";
      if (tryIntruderTwilioOnce())
        twilioCallSent = true;
      if (!intruderAlertBeeped) {
        intruderAlertBeeped = true;
        beep(3, 35);
      }
    }
  } else {
    hitStreak[i] = 0;
  }

  bool isIntruder =
      hitStreak[i] >= (savedDistance[i] > 0 ? HIT_REQUIRED : OPEN_CALIB_HIT_REQUIRED);
  float threshold = 0.0f;
  float requiredDrop = 0.0f;
  if (savedDistance[i] > 0) {
    threshold = savedDistance[i] * (1.0f - runtimeIgnorePercent);
    requiredDrop = requiredDropForBase(savedDistance[i]);
  }

  Serial.print("Scan ");
  Serial.print(angles[i]);
  Serial.print(" deg | Base: ");
  if (savedDistance[i] == 0) Serial.print("OPEN   ");
  else {
    Serial.print(savedDistance[i]);
    Serial.print("cm");
  }

  Serial.print(" | Thr: ");
  if (savedDistance[i] == 0) Serial.print("ANY    ");
  else {
    Serial.print(threshold);
    Serial.print("cm");
  }

  Serial.print(" | Drop: ");
  if (savedDistance[i] == 0) Serial.print("ANY    ");
  else {
    Serial.print(requiredDrop);
    Serial.print("cm");
  }

  Serial.print(" | Cur: ");
  if (currentDistance[i] == 0) Serial.print("OPEN   ");
  else {
    Serial.print(currentDistance[i]);
    Serial.print("cm");
  }

  Serial.print(" | Valid: ");
  Serial.print(lastValidSampleCount);
  Serial.print("/");
  Serial.print(SCAN_SAMPLES);

  Serial.print(" | Spread: ");
  Serial.print(lastReadingSpreadCm, 1);
  Serial.print("cm");

  Serial.print(" | Hits: ");
  Serial.print(hitStreak[i]);
  Serial.print("/");
  Serial.print(savedDistance[i] > 0 ? HIT_REQUIRED : OPEN_CALIB_HIT_REQUIRED);

  if (isIntruder) {
    cycleAlert = true;
    cycleDetectedAngle = String(angles[i]);
    Serial.println();
    Serial.println("  INTRUDER ALERT");
    Serial.println();
  } else {
    Serial.println(candidate ? " -> Candidate"
                             : (echoStable ? " -> Clear" : " -> Unstable echo"));
  }

  if (i == 2) {
    Serial.println("--- 3-zone scan done (temp polled in loop) ---");
  }

  uint8_t done = sweepStep;
  sweepStep = (sweepStep + 1) % 4;

  if (done == 3) {
    alertTriggeredThisCycle = cycleAlert;
    candidateThisCycle = cycleCandidate;
    detectedAngle = cycleDetectedAngle;
    cycleAlert = false;
    cycleCandidate = false;
    cycleDetectedAngle = "";
    return true;
  }
  return false;
}

void setup() {
  Serial.begin(115200);
  Serial.println();
  Serial.println("System Initializing...");

  pinMode(ONE_WIRE_BUS, INPUT);
  sensors.begin();
  sensors.setResolution(10);
  sensors.setWaitForConversion(true);
  delay(750);
  ds18b20Present = sensors.getDeviceCount() > 0;
  if (!ds18b20Present) {
    Serial.println("DS18B20 not found — temperature disabled");
  } else {
    Serial.print("DS18B20 OK, count: ");
    Serial.println(sensors.getDeviceCount());
  }

  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(POWER_LED_PIN, OUTPUT);
  pinMode(WIFI_LED_PIN, OUTPUT);
  analogWriteFreq(1000);
  digitalWrite(BUZZER_PIN, LOW);
  updatePowerLed();
  setIndicatorLed(WIFI_LED_PIN, false);

  EEPROM.begin(EEPROM_SIZE);
  loadStoredConfig();
  printDjangoIoTConfig();

  myServo.attach(SERVO_PIN);
  myServo.write(currentServoAngle);
  delay(150);

  Serial.println("ESP8266 needs 2.4 GHz WiFi.");
  bool wifiConnected = false;
  if (wifiSsid.length() > 0) {
    wifiConnected = connectWifi(wifiSsid, wifiPass, WIFI_FAIL_AP_TIMEOUT_MS);
  }
  if (!wifiConnected && wifiSsid != WIFI_SSID && WIFI_SSID[0] != '\0') {
    wifiConnected = connectWifi(WIFI_SSID, WIFI_PASS, 30000UL);
    if (wifiConnected) saveWifiCredentials(WIFI_SSID, WIFI_PASS);
  }
  lastWifiRetryMs = millis();

  if (wifiConnected) {
    server.on("/", handleRoot);
    server.begin();
    webServerBegun = true;
    Serial.print("Dashboard: http://");
    Serial.println(WiFi.localIP());
    performCalibration();
    if (ds18b20Present) reportTemperature();
    Serial.println("High-Speed Security Active");
    Serial.println("Scanning started...");
    beep(2, 60);
    return;
  }

  Serial.println("WiFi connect failed — starting setup hotspot");
  startWifiConfigPortal(wifiSsid.length() == 0);
}

void loop() {
  updatePowerLed();

  if (configPortalActive) {
    runConfigPortalLoop();
    return;
  }

  updateWifiLed();
  maintainWifi();

  if (ds18b20Present) {
    unsigned long tnow = millis();
    if (tnow - lastTempPollMs >= TEMP_POLL_MS) {
      lastTempPollMs = tnow;
      reportTemperature();
    }
  }

  pollDjangoCommands();
  postTelemetry();

  if (!remoteEnabled) {
    static unsigned long lastPausedLogMs = 0;
    if (millis() - lastPausedLogMs > 15000UL) {
      lastPausedLogMs = millis();
      if (djangoScheduleGate && djangoDesiredPower && !djangoInScheduleWindow)
        Serial.println("[PAUSED] Outside schedule window.");
      else if (!djangoDesiredPower)
        Serial.println("[PAUSED] Power OFF in customer portal.");
      else
        Serial.println("[PAUSED] Scanning disabled by Django.");
    }
    systemStatus = "SAFE";
    digitalWrite(BUZZER_PIN, LOW);
    twilioCallSent = false;
    intruderAlertBeeped = false;
    delay(50);
    return;
  }

  bool alertTriggeredThisCycle = false;
  bool candidateThisCycle = false;
  String detectedAngle = "";
  bool cycleDone = processUltrasonicSweep(alertTriggeredThisCycle, candidateThisCycle, detectedAngle);

  if (!cycleDone) return;

  if (alertTriggeredThisCycle || candidateThisCycle) {
    clearStreak = 0;
    if (alertTriggeredThisCycle && !twilioCallSent) {
      lastAlertAngle = detectedAngle;
      systemStatus = "ALERT";
      Serial.println("Intruder confirmed — Twilio (if due)");
      if (tryIntruderTwilioOnce())
        twilioCallSent = true;
      if (!intruderAlertBeeped) {
        intruderAlertBeeped = true;
        beep(3, 35);
      }
    }
  } else if (clearStreak < 255) {
    clearStreak++;
  }

  if (clearStreak >= CLEAR_REQUIRED) {
    systemStatus = "SAFE";
    digitalWrite(BUZZER_PIN, LOW);
    twilioCallSent = false;
    intruderAlertBeeped = false;
  }
}