import { useEffect, useMemo, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, Loader2, Thermometer } from 'lucide-react';
import { customerDeviceService } from '../../api/services';

const Sensors = () => {
  const { deviceId } = useParams();
  const navigate = useNavigate();
  const [readings, setReadings] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadReadings = async () => {
      try {
        const response = await customerDeviceService.getSensorReadings(deviceId);
        setReadings(response.data || []);
      } finally {
        setLoading(false);
      }
    };
    loadReadings();
  }, [deviceId]);

  const points = useMemo(() => {
    const values = readings.map((item) => Number(item.temperature)).filter((value) => !Number.isNaN(value));
    if (values.length === 0) return '';
    const min = Math.min(...values);
    const max = Math.max(...values);
    const range = max - min || 1;
    return values.map((value, index) => {
      const x = values.length === 1 ? 280 : (index / (values.length - 1)) * 280;
      const y = 120 - ((value - min) / range) * 100;
      return `${x},${y}`;
    }).join(' ');
  }, [readings]);

  const latest = readings[readings.length - 1];

  return (
    <div className="min-h-screen bg-slate-50 p-5">
      <button onClick={() => navigate(`/customer/device/${deviceId}`)} className="flex items-center gap-2 text-slate-500 font-bold mb-6">
        <ArrowLeft size={20} /> Back
      </button>

      <h1 className="text-3xl font-black text-slate-900">Heat Sensor Graph</h1>
      <p className="text-slate-500 mt-1">Latest {readings.length} of 100 points.</p>

      <section className="bg-white rounded-[2rem] p-5 border border-slate-100 mt-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-slate-500">Current temperature</p>
            <p className="text-4xl font-black">{latest?.temperature ?? '--'} C</p>
          </div>
          <div className="w-14 h-14 rounded-2xl bg-orange-100 text-orange-600 flex items-center justify-center">
            <Thermometer size={28} />
          </div>
        </div>

        <div className="mt-8 h-48 bg-slate-950 rounded-[1.5rem] p-4 overflow-hidden">
          {loading ? (
            <div className="h-full flex items-center justify-center">
              <Loader2 className="animate-spin text-white" />
            </div>
          ) : points ? (
            <svg viewBox="0 0 280 130" className="w-full h-full">
              <polyline points={points} fill="none" stroke="rgb(251 146 60)" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          ) : (
            <div className="h-full flex items-center justify-center text-slate-400 font-bold">No sensor data yet</div>
          )}
        </div>
      </section>

      <div className="mt-5 space-y-3">
        {readings.slice(-8).reverse().map((reading) => (
          <div key={reading.id} className="bg-white rounded-2xl p-4 border border-slate-100 flex justify-between">
            <span className="font-bold">{reading.temperature ?? '--'} C</span>
            <span className="text-sm text-slate-500">{new Date(reading.created_at).toLocaleString()}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Sensors;
