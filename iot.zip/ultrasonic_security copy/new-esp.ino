/*
 * Ultrasonic Security — ESP8266 + Django IoT
 *
 * WiFi stored in EEPROM. Factory defaults: SSID="sales", password="12341234".
 * Boot: read EEPROM → connect → if fail → hotspot.
 * Django wifi_update OR hotspot save → update EEPROM immediately.
 *
 * Set DEVICE_ID and DEVICE_TOKEN from your batch / Django admin before flashing.
 */
 #include <EEPROM.h>
 #include <Servo.h>
 #include <ESP8266WiFi.h>
 #include <ESP8266WebServer.h>
 #include <ESP8266HTTPClient.h>
 #include <DNSServer.h>
 #include <WiFiClientSecure.h>
 #include <OneWire.h>
 #include <DallasTemperature.h>
 
 // NodeMCU pin map:
 // HC-SR04 Trig -> D6, Echo -> D5
 // SG90 servo signal -> D4
 // Active buzzer -> D3
 // DS18B20 data -> D7 (4.7k pull-up to 3.3V)
 // Power LED -> D1, WiFi LED -> D2
 #define TRIG_PIN D6
 #define ECHO_PIN D5
 #define BUZZER_PIN D2
 #define SERVO_PIN D4
 #define ONE_WIRE_BUS D7
 #define POWER_LED_PIN D1
 #define WIFI_LED_PIN D3
 #define LED_PWM_LEVEL 64
 
 #define SOUND_VELOCITY 0.034
 #define SENSOR_ERROR_PERCENT 0.03f  // 3% HC-SR04 error — used for ALL distance math
#define MIN_DISTANCE 5
#define MAX_DISTANCE 400          // raw sensor read limit (calibration can use full range)
#define DETECT_MAX_FEET 10
#define DETECT_MAX_CM 300         // reliable HC-SR04 human detection (~10 ft)
#define PULSE_TIMEOUT_US 35000
 #define SCAN_PULSE_TIMEOUT_US 35000
 #define CALIBRATION_SAMPLES 15
 #define CALIBRATION_ROUNDS 5
 #define CALIBRATION_SETTLE_MS 800
 #define SCAN_SAMPLES 11
 #define SCAN_BURST_GAP_MS 40
 #define SERVO_STEP_DEG 4
 #define SERVO_STEP_DELAY_MS 5
 #define SERVO_SETTLE_MS 20
 #define SERVO_AT_ANGLE_TOLERANCE 3
#define CALIBRATION_MAX_CM 400
#define MIN_INTRUSION_CM 12       // ignore wall noise below this drop
#define INTRUSION_NOISE_MULT 2.0f // drop must clear 2x sensor error band
#define HIT_REQUIRED 3              // consecutive candidates → alert + Twilio call
#define CLEAR_REQUIRED 4
#define ARM_CLEAR_REQUIRED 6
#define SAMPLE_GAP_MS 15
#define HUMAN_NEAR_MAX_CM DETECT_MAX_CM
#define HUMAN_FAR_MIN_CM 5
#define OPEN_DETECT_MIN_CM 5
#define OPEN_DETECT_MAX_CM DETECT_MAX_CM
#define OPEN_CALIB_HIT_REQUIRED 3   // open-space mode (no wall base)
#define MAX_READ_SAMPLES 20
#define MIN_CLUSTER_SAMPLES 3
#define SCAN_INTRUDER_MIN_SAMPLES 4  // need 4 close echoes, not random spikes
#define MAX_CLUSTER_SPREAD_CM 25.0f  // reject burst if close samples disagree too much
 // Heat: 2°C vs oldest sample in 30s window (~29s warm-up with 1s history steps).
 #define TEMP_RISE_WINDOW_MS 30000UL
 #define TEMP_RISE_ALARM_C 2.0f
 #define TEMP_HISTORY_SAMPLE_MS 1000UL
 #define TEMP_HISTORY_MAX 36
 #define TEMP_RISE_BEEP_REPEAT_MS 5000UL
 #define TEMP_POLL_MS 2000UL
 #define TWILIO_HEAT_CALL_COOLDOWN_MS 600000UL
 #define TWILIO_POST_RETRIES 3
 #define TWILIO_RETRY_GAP_MS 400UL
 #define TWILIO_INTRUDER_MIN_RETRY_GAP_MS 25000UL
 
 // Factory-default WiFi written to EEPROM on very first boot (when EEPROM magic is missing).
 // After that, EEPROM holds the current credentials — edit WIFI_SSID/PASS only to reset.
 #define WIFI_SSID_DEFAULT "intvice"
 #define WIFI_PASS_DEFAULT "intvicepass"
 
 // EEPROM layout (256 bytes total)
 #define EEPROM_SIZE         256
 #define EEPROM_MAGIC_ADDR     0   // 1 byte  — 0xAB = initialized
 #define EEPROM_SSID_ADDR      1   // 63 bytes
 #define EEPROM_PASS_ADDR     64   // 63 bytes
 #define EEPROM_FW_ADDR       127  // 32 bytes — stores firmware version to detect re-flash
 #define EEPROM_STR_MAX        63
 #define EEPROM_FW_MAX         31
 #define EEPROM_MAGIC_VAL    0xAB
 
 #define WIFI_CONNECT_TIMEOUT_MS 60000UL
 #define WIFI_RETRY_MS 20000UL
 #define WIFI_RETRY_MS_QUICK 5000UL
 #define WIFI_RECONNECT_TIMEOUT_MS 45000UL
 #define WIFI_LINK_CHECK_MS 5000UL
 #define WIFI_DJANGO_POST_RETRIES 5
 #define WIFI_DJANGO_POST_GAP_MS 2000UL
 #define WIFI_HOTSPOT_TIMEOUT_MS 300000UL   // 5 min — then exit hotspot and retry EEPROM WiFi
 #define WIFI_SYNC_COOLDOWN_MS   60000UL    // min gap between /wifi-report/ retries
 #define WIFI_UPDATE_CONNECT_MS  40000UL    // timeout for applying Django wifi_update
 
 // Setup hotspot (customer forget/change WiFi via phone)
 #define AP_SSID_PREFIX "UltrasonicSetup-"
 #define AP_PASSWORD "setup1234"
 #define WIFI_FAIL_AP_TIMEOUT_MS 60000UL
 #define STA_FAIL_BEFORE_AP 8
 
// Django IoT — customer portal controls device via these endpoints
// Production: USE_LOCAL_DJANGO false → https://iot.intvice.com/api
// Local dev:   USE_LOCAL_DJANGO true  + LOCAL_PC_IP + runserver 0.0.0.0:8000
#define USE_LOCAL_DJANGO false
 #define LOCAL_PC_IP "192.168.29.110"
 #define LOCAL_API_BASE_URL "http://" LOCAL_PC_IP ":8000/api"
 #define PRODUCTION_API_BASE_URL "https://iot.intvice.com/api"
 #if USE_LOCAL_DJANGO
 #define API_BASE_URL LOCAL_API_BASE_URL
 #else
 #define API_BASE_URL PRODUCTION_API_BASE_URL
 #endif
 #define DEVICE_ID "26E15000056"
 #define DEVICE_TOKEN "8QLvrDJItPbJibs7d_sVQHbToemguGqwUIarL8Q5G6s"
#define FIRMWARE_VERSION "1.0.6-prod-acc"
#if USE_LOCAL_DJANGO
#define COMMAND_POLL_MS 5000UL
#define TELEMETRY_POST_MS 10000UL
#define DJANGO_HTTP_TIMEOUT_MS 12000UL
#else
// ESP8266 HTTPS is expensive — poll less, one request per loop, short timeout
#define COMMAND_POLL_MS 30000UL
#define TELEMETRY_POST_MS 30000UL
#define DJANGO_HTTP_TIMEOUT_MS 12000UL
#endif
#define DJANGO_SERIAL_BODY_MAX 512
 
 #define TWILIO_ACCOUNT_SID "AC2d1161e4550d167d96e4c5b9dda5d6e3"
 #define TWILIO_AUTH_TOKEN "6ed9b1311b15e52d0c981af74b051b4e"
 #define TWILIO_FROM_NUMBER "+17755996527"
 #define TWILIO_TO_NUMBER ""   // phone number comes from Django API (notification.phone)
 
 Servo myServo;
 ESP8266WebServer server(80);
 DNSServer dnsServer;
 OneWire oneWire(ONE_WIRE_BUS);
 DallasTemperature sensors(&oneWire);
 
 float savedDistance[3];
 float currentDistance[3];
 // Servo locked straight (90°) — no sweep, single zone only
 #define FIXED_SERVO_ANGLE 90
 int angles[3] = {FIXED_SERVO_ANGLE, FIXED_SERVO_ANGLE, FIXED_SERVO_ANGLE};
 int sweepPattern[4] = {0, 0, 0, 0};
 uint8_t sweepStep = 0;
 int currentServoAngle = FIXED_SERVO_ANGLE;
 bool ds18b20Present = false;
 bool twilioCallSent = false;
 bool intruderAlertBeeped = false;
uint8_t hitStreak[3] = {0, 0, 0};
uint8_t clearStreak = 0;
uint8_t armClearStreak = 0;
bool detectionArmed = false;
bool lastDualBurstIntrusion = false;
uint8_t lastValidSampleCount = 0;
 float lastReadingSpreadCm = 0;
 float lastTemperatureC = NAN;
 unsigned long histTime[TEMP_HISTORY_MAX];
 float histTemp[TEMP_HISTORY_MAX];
 uint8_t histCount = 0;
 unsigned long lastTempRiseBeepMs = 0;
 unsigned long lastTempPollMs = 0;
 unsigned long lastTwilioHeatCallMs = 0;
 unsigned long lastTwilioIntruderAttemptMs = 0;
 bool webServerBegun = false;
 unsigned long lastWifiRetryMs = 0;
 unsigned long lastTelemetryPostMs = 0;
 unsigned long lastCommandPollMs = 0;
 int lastAckedCommandRevision = -1;
 int lastAckedUltrasonicRevision = -1;
 int pendingCommandAckRevision = -1;
 int pendingUltrasonicAckRevision = -1;
 bool remoteEnabled = true;
 bool djangoDesiredPower = true;
 bool djangoScheduleGate = false;
 bool djangoInScheduleWindow = true;
 float runtimeIgnorePercent = SENSOR_ERROR_PERCENT;
 int runtimeMinIntrusionCm = MIN_INTRUSION_CM;
 String wifiSsid = WIFI_SSID_DEFAULT;
 String wifiPass = WIFI_PASS_DEFAULT;
 String apiBaseUrl = API_BASE_URL;
 String djangoDeviceId = DEVICE_ID;
 String djangoDeviceToken = DEVICE_TOKEN;
 String twilioToNumber = TWILIO_TO_NUMBER;
 String twilioAlternateNumber = "";
 
 String systemStatus = "SAFE";
 String lastAlertAngle = "None";
 bool configPortalActive = false;
 bool configPortalForgetMode = false;
 String apSsidName = "";
 uint8_t staReconnectFailures = 0;
 unsigned long lastWifiLedBlinkMs = 0;
 bool wifiLedBlinkState = false;
 volatile bool wifiNeedsReconnect = false;
 unsigned long lastWifiLinkCheckMs = 0;
 String lastSyncedWifiSsid = "";
 String lastSyncedWifiPass = "";
 unsigned long hotspotStartedMs = 0;
unsigned long lastSyncFailMs = 0;
bool djangoHttpInUse = false;

void updateWifiLed();
 bool isWifiLinked();
 bool connectWifi(const String &ssid, const String &password, unsigned long timeoutMs, bool hardReset = false);
 bool djangoIoTConfigured();
 void onWifiStationDisconnected(const WiFiEventStationModeDisconnected &evt);
 void onWifiStationGotIP(const WiFiEventStationModeGotIP &evt);
 bool reconnectWifiSoft(unsigned long timeoutMs);
 bool postHotspotWifiToDjango(const String &ssid, const String &pass);
 bool syncWifiCredentialsToDjango(const String &ssid, const String &pass);
 void syncWifiToDjangoIfNeeded();
 void shutdownConfigPortalForSta();
 void startWifiConfigPortal(bool forgetMode);
 void runConfigPortalLoop();
 void beep(int times, int durationMs);
 bool sendTwilioVoiceSay(const char *sayPhrase, const char *debugTag);
 bool tryIntruderTwilioOnce();
 void maintainDjangoIoT();
 void applyNotificationFromCommands(const String &payload);
 void performCalibration();
 
 // ── EEPROM helpers ──────────────────────────────────────────────────────────
 
 String eepromReadStr(int addr, int maxLen) {
   String s;
   for (int i = 0; i < maxLen; i++) {
     char c = (char)EEPROM.read(addr + i);
     if (c == '\0' || c == (char)0xFF) break;
     s += c;
   }
   return s;
 }
 
 void eepromWriteStr(int addr, int maxLen, const String &value) {
   int limit = min(maxLen, (int)value.length());
   for (int i = 0; i < maxLen; i++)
     EEPROM.write(addr + i, i < limit ? (uint8_t)value[i] : 0);
 }
 
 bool eepromIsInitialized() {
   return EEPROM.read(EEPROM_MAGIC_ADDR) == EEPROM_MAGIC_VAL;
 }
 
 // Write factory defaults and mark EEPROM as initialized
 void eepromWriteDefaults() {
   EEPROM.write(EEPROM_MAGIC_ADDR, 0);           // clear magic first (safe)
   eepromWriteStr(EEPROM_SSID_ADDR, EEPROM_STR_MAX, WIFI_SSID_DEFAULT);
   eepromWriteStr(EEPROM_PASS_ADDR, EEPROM_STR_MAX, WIFI_PASS_DEFAULT);
   eepromWriteStr(EEPROM_FW_ADDR,   EEPROM_FW_MAX,  FIRMWARE_VERSION);
   EEPROM.write(EEPROM_MAGIC_ADDR, EEPROM_MAGIC_VAL);
   EEPROM.commit();
   Serial.println("[EEPROM] Cleared — factory defaults written (sales/12341234)");
 }
 
 // Load WiFi from EEPROM into RAM. Call once in setup().
 void loadConfigFromEeprom() {
   EEPROM.begin(EEPROM_SIZE);
 
   String storedFw = eepromReadStr(EEPROM_FW_ADDR, EEPROM_FW_MAX);
   bool newFlash   = !eepromIsInitialized() || storedFw != String(FIRMWARE_VERSION);
 
   if (newFlash) {
     if (!eepromIsInitialized())
       Serial.println("[EEPROM] First boot — writing factory defaults");
     else {
       Serial.print("[EEPROM] New firmware detected (was: ");
       Serial.print(storedFw.length() > 0 ? storedFw : "unknown");
       Serial.println(") — clearing EEPROM and writing factory defaults");
     }
     eepromWriteDefaults();
   }
 
   wifiSsid = eepromReadStr(EEPROM_SSID_ADDR, EEPROM_STR_MAX);
   wifiPass = eepromReadStr(EEPROM_PASS_ADDR, EEPROM_STR_MAX);
 
   // Fallback safety: if somehow blank after init
   if (wifiSsid.length() == 0) {
     wifiSsid = WIFI_SSID_DEFAULT;
     wifiPass = WIFI_PASS_DEFAULT;
   }
 
   Serial.print("[EEPROM] Loaded WiFi SSID: ");
   Serial.println(wifiSsid);
 
   // Fixed credentials from sketch defines
   apiBaseUrl        = API_BASE_URL;
   djangoDeviceId    = DEVICE_ID;
   djangoDeviceToken = DEVICE_TOKEN;
 }
 
 // Save new WiFi to EEPROM + RAM (keeps firmware version marker intact)
 void saveWifiCredentials(const String &ssid, const String &password) {
   wifiSsid = ssid;
   wifiPass = password;
   eepromWriteStr(EEPROM_SSID_ADDR, EEPROM_STR_MAX, ssid);
   eepromWriteStr(EEPROM_PASS_ADDR, EEPROM_STR_MAX, password);
   eepromWriteStr(EEPROM_FW_ADDR,   EEPROM_FW_MAX,  FIRMWARE_VERSION);
   EEPROM.commit();
   Serial.print("[EEPROM] Saved — SSID: ");
   Serial.print(ssid);
   Serial.print("  pass: ");
   Serial.println(password);
 }
 
 void clearWifiCredentials() {
   eepromWriteStr(EEPROM_SSID_ADDR, EEPROM_STR_MAX, "");
   eepromWriteStr(EEPROM_PASS_ADDR, EEPROM_STR_MAX, "");
   EEPROM.commit();
   wifiSsid = "";
   wifiPass = "";
 }
 
 String htmlEscape(const String &s) {
   String out;
   out.reserve(s.length() + 8);
   for (unsigned int i = 0; i < s.length(); i++) {
     char c = s[i];
     if (c == '&') out += "&amp;";
     else if (c == '<') out += "&lt;";
     else if (c == '>') out += "&gt;";
     else if (c == '"') out += "&quot;";
     else out += c;
   }
   return out;
 }
 
 String buildApSsid() {
   String id = djangoDeviceId;
   if (id.length() == 0 || id == "CHANGE_ME") {
     id = String(ESP.getChipId(), HEX);
   }
   String suffix = id.substring(id.length() > 4 ? id.length() - 4 : 0);
   suffix.toUpperCase();
   return String(AP_SSID_PREFIX) + suffix;
 }
 
 void handleCaptiveRedirect() {
   server.sendHeader("Location", "http://192.168.4.1/", true);
   server.send(302, "text/plain", "Redirecting to setup...");
 }
 
 void handleSetupRoot() {
   String mode = server.arg("mode");
   bool forget = configPortalForgetMode || mode == "forget";
   String prefillSsid = forget ? "" : wifiSsid;
   String prefillPass = forget ? "" : "";
 
   String html = "<!DOCTYPE html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'>";
   html += "<title>WiFi Setup</title>";
   html += "<style>body{font-family:sans-serif;background:#0f172a;color:#fff;padding:20px;max-width:420px;margin:0 auto}";
   html += "h1{font-size:1.5rem}input{width:100%;padding:14px;margin:8px 0;border-radius:12px;border:none;font-size:16px;box-sizing:border-box}";
   html += "button{width:100%;padding:16px;margin-top:12px;border-radius:12px;border:none;background:#4f46e5;color:#fff;font-weight:bold;font-size:16px}";
   html += ".hint{color:#94a3b8;font-size:14px;line-height:1.5}</style></head><body>";
   html += "<h1>Shop WiFi Setup</h1>";
   if (forget) {
     html += "<p class='hint'>Forget mode: enter new WiFi name and password. Device will reboot and connect.</p>";
   } else {
     html += "<p class='hint'>Change mode: update password or network. Same WiFi name is pre-filled if saved.</p>";
   }
   html += "<p class='hint'>Credentials are sent to the IoT portal after the device connects.</p>";
   html += "<form method='POST' action='/save'>";
   html += "<input name='ssid' placeholder='WiFi name (SSID)' value='" + htmlEscape(prefillSsid) + "' required>";
   html += "<input name='password' type='text' placeholder='WiFi password' value='" + htmlEscape(prefillPass) + "' required>";
   if (forget) html += "<input type='hidden' name='forget' value='1'>";
   html += "<button type='submit'>Save and reconnect</button></form></body></html>";
   server.send(200, "text/html", html);
 }
 
 void handleSetupSave() {
   String ssid = server.arg("ssid");
   String pass = server.arg("password");
   bool forget = configPortalForgetMode || server.arg("forget") == "1";
 
   if (ssid.length() == 0 || pass.length() == 0) {
     server.send(400, "text/plain", "SSID and password required");
     return;
   }
 
   if (forget) clearWifiCredentials();
   saveWifiCredentials(ssid, pass);
 
   String html = "<!DOCTYPE html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'>";
   html += "<style>body{font-family:sans-serif;background:#14532d;color:#fff;text-align:center;padding:40px 20px}</style></head><body>";
   html += "<h1>Saved</h1><p>Connecting to " + htmlEscape(ssid) + " and syncing to IoT portal…</p></body></html>";
   server.send(200, "text/html", html);
   server.client().stop();
   Serial.println("WiFi saved via setup portal — connecting and posting to Django");
   delay(500);
 
   shutdownConfigPortalForSta();
 
   bool connected = connectWifi(ssid, pass, 60000UL, false);
   if (connected) {
     delay(2500);
     if (syncWifiCredentialsToDjango(ssid, pass))
       Serial.println("WiFi credentials posted to Django OK");
     else
       Serial.println("WiFi credentials Django post FAILED — will retry after reboot");
   } else {
     Serial.println("Could not connect to shop WiFi before Django post");
   }
 
   delay(1000);
   ESP.restart();
 }
 
 void shutdownConfigPortalForSta() {
   configPortalActive = false;
   configPortalForgetMode = false;
   dnsServer.stop();
   server.stop();
   WiFi.softAPdisconnect(true);
   delay(300);
   WiFi.mode(WIFI_OFF);
   delay(500);
   WiFi.mode(WIFI_STA);
   delay(200);
 }
 
 void startWifiConfigPortal(bool forgetMode) {
   if (configPortalActive) return;
 
   configPortalForgetMode = forgetMode;
   configPortalActive = true;
   webServerBegun = false;
   staReconnectFailures = 0;
   hotspotStartedMs = millis();
 
   WiFi.disconnect(true);
   delay(200);
 
   apSsidName = buildApSsid();
   WiFi.mode(WIFI_AP);
   WiFi.softAPConfig(IPAddress(192, 168, 4, 1), IPAddress(192, 168, 4, 1), IPAddress(255, 255, 255, 0));
   WiFi.softAP(apSsidName.c_str(), AP_PASSWORD);
 
   server.stop();
   server.on("/", handleSetupRoot);
   server.on("/setup", handleSetupRoot);
   server.on("/save", HTTP_POST, handleSetupSave);
   server.onNotFound(handleCaptiveRedirect);
   server.begin();
 
   dnsServer.stop();
   dnsServer.start(53, "*", WiFi.softAPIP());
 
   Serial.println();
   Serial.println("=== WiFi SETUP HOTSPOT ACTIVE ===");
   Serial.print("Join WiFi: ");
   Serial.println(apSsidName);
   Serial.print("Password: ");
   Serial.println(AP_PASSWORD);
   Serial.println("Open http://192.168.4.1 in your browser");
   if (forgetMode) Serial.println("Mode: FORGET (clears old WiFi on save)");
   else Serial.println("Mode: CHANGE");
   Serial.println("=================================");
 }
 
 void updateWifiLedPortalBlink() {
   unsigned long now = millis();
   if (now - lastWifiLedBlinkMs < 400) return;
   lastWifiLedBlinkMs = now;
   wifiLedBlinkState = !wifiLedBlinkState;
   setIndicatorLed(WIFI_LED_PIN, wifiLedBlinkState);
 }
 
 void runConfigPortalLoop() {
   dnsServer.processNextRequest();
   server.handleClient();
   updateWifiLedPortalBlink();
   delay(5);
 
   // Timeout: if nobody used the hotspot in 5 minutes, exit and retry EEPROM WiFi
   if (millis() - hotspotStartedMs >= WIFI_HOTSPOT_TIMEOUT_MS) {
     Serial.println("[Hotspot] Timed out — closing hotspot and retrying EEPROM WiFi");
     configPortalActive = false;
     configPortalForgetMode = false;
     dnsServer.stop();
     server.stop();
     WiFi.softAPdisconnect(true);
     delay(300);
     WiFi.mode(WIFI_STA);
     delay(200);
     staReconnectFailures = 0;
     lastWifiRetryMs = 0;
   }
 }
 
 String jsonStringValue(const String &json, const String &key, const String &fallback = "") {
   int keyPos = json.indexOf("\"" + key + "\"");
   if (keyPos < 0) return fallback;
   int colon = json.indexOf(':', keyPos);
   int firstQuote = json.indexOf('"', colon + 1);
   int secondQuote = json.indexOf('"', firstQuote + 1);
   if (colon < 0 || firstQuote < 0 || secondQuote < 0) return fallback;
   return json.substring(firstQuote + 1, secondQuote);
 }
 
 int jsonIntValue(const String &json, const String &key, int fallback = 0) {
   int keyPos = json.indexOf("\"" + key + "\"");
   if (keyPos < 0) return fallback;
   int colon = json.indexOf(':', keyPos);
   if (colon < 0) return fallback;
   return json.substring(colon + 1).toInt();
 }
 
 float jsonFloatValue(const String &json, const String &key, float fallback) {
   int keyPos = json.indexOf("\"" + key + "\"");
   if (keyPos < 0) return fallback;
   int colon = json.indexOf(':', keyPos);
   if (colon < 0) return fallback;
   return json.substring(colon + 1).toFloat();
 }
 
 bool jsonBoolValue(const String &json, const String &key, bool fallback) {
   int keyPos = json.indexOf("\"" + key + "\"");
   if (keyPos < 0) return fallback;
   int colon = json.indexOf(':', keyPos);
   if (colon < 0) return fallback;
   int valueStart = colon + 1;
   while (valueStart < (int)json.length() && json[valueStart] == ' ') valueStart++;
   if (json.startsWith("true", valueStart)) return true;
   if (json.startsWith("false", valueStart)) return false;
   return fallback;
 }
 
 void initWifiStack() {
   WiFi.persistent(false);
   WiFi.setAutoReconnect(true);
   WiFi.setSleepMode(WIFI_NONE_SLEEP);
 }
 
 bool isWifiLinked() {
   return WiFi.status() == WL_CONNECTED && WiFi.localIP()[0] != 0;
 }
 
 void onWifiStationDisconnected(const WiFiEventStationModeDisconnected &evt) {
   Serial.print("WiFi disconnected (reason ");
   Serial.print(evt.reason);
   Serial.println(") — will reconnect when router is back");
   wifiNeedsReconnect = true;
   webServerBegun = false;
   lastSyncedWifiSsid = "";
   lastSyncedWifiPass = "";
 }
 
 void onWifiStationGotIP(const WiFiEventStationModeGotIP &evt) {
   Serial.print("WiFi got IP: ");
   Serial.println(evt.ip);
   wifiNeedsReconnect = false;
   staReconnectFailures = 0;
 }
 
 bool reconnectWifiSoft(unsigned long timeoutMs) {
   if (wifiSsid.length() == 0) return false;
 
   initWifiStack();
   WiFi.mode(WIFI_STA);
 
   Serial.println("WiFi soft reconnect (WiFi.reconnect)...");
   WiFi.reconnect();
 
   unsigned long started = millis();
   while (!isWifiLinked() && millis() - started < timeoutMs) {
     updateWifiLed();
     yield();
     delay(250);
   }
   if (isWifiLinked()) {
     Serial.print("WiFi OK — IP: ");
     Serial.println(WiFi.localIP());
     return true;
   }
 
   Serial.println("Soft reconnect failed — trying WiFi.begin...");
   WiFi.begin(wifiSsid.c_str(), wifiPass.c_str());
   started = millis();
   while (!isWifiLinked() && millis() - started < timeoutMs) {
     updateWifiLed();
     yield();
     delay(250);
   }
 
   if (isWifiLinked()) {
     Serial.print("WiFi OK — IP: ");
     Serial.println(WiFi.localIP());
     Serial.print("RSSI: ");
     Serial.print(WiFi.RSSI());
     Serial.println(" dBm");
     return true;
   }
 
   logWifiStatus();
   return false;
 }
 
 void logWifiStatus() {
   Serial.print("WiFi status ");
   Serial.print(WiFi.status());
   Serial.print(" = ");
   switch (WiFi.status()) {
     case WL_IDLE_STATUS: Serial.println("IDLE"); break;
     case WL_NO_SSID_AVAIL: Serial.println("NO_SSID (wrong name or 5 GHz only)"); break;
     case WL_SCAN_COMPLETED: Serial.println("SCAN_COMPLETED"); break;
     case WL_CONNECTED: Serial.println("CONNECTED"); break;
     case WL_CONNECT_FAILED: Serial.println("CONNECT_FAILED (wrong password?)"); break;
     case WL_CONNECTION_LOST: Serial.println("CONNECTION_LOST"); break;
     case WL_DISCONNECTED: Serial.println("DISCONNECTED"); break;
     default: Serial.println("UNKNOWN"); break;
   }
 }
 
 bool connectWifi(const String &ssid, const String &password, unsigned long timeoutMs, bool hardReset) {
   if (ssid.length() == 0) {
     Serial.println("WiFi: SSID is empty — check EEPROM or flash new firmware.");
     return false;
   }
 
   Serial.print("Connecting to SSID: ");
   Serial.println(ssid);
 
   initWifiStack();
   WiFi.mode(WIFI_STA);
   WiFi.disconnect(hardReset);
   delay(100);
   WiFi.hostname("ultrasonic-security");
   WiFi.begin(ssid.c_str(), password.c_str());
 
   unsigned long started = millis();
   while (!isWifiLinked() && millis() - started < timeoutMs) {
     updateWifiLed();
     yield();
     delay(150);
     Serial.print(".");
   }
   Serial.println();
   updateWifiLed();
 
   if (isWifiLinked()) {
     wifiNeedsReconnect = false;
     Serial.print("WiFi OK — IP: ");
     Serial.println(WiFi.localIP());
     Serial.print("RSSI: ");
     Serial.print(WiFi.RSSI());
     Serial.println(" dBm");
     return true;
   }
 
   logWifiStatus();
   return false;
 }
 
 void maintainWifi() {
   if (configPortalActive) return;
 
   unsigned long now = millis();
   if (now - lastWifiLinkCheckMs >= WIFI_LINK_CHECK_MS) {
     lastWifiLinkCheckMs = now;
     if (WiFi.status() == WL_CONNECTED && WiFi.localIP()[0] == 0) {
       Serial.println("WiFi stale (connected but no IP) — reconnecting...");
       wifiNeedsReconnect = true;
       webServerBegun = false;
     }
   }
 
   if (isWifiLinked() && !wifiNeedsReconnect) {
     staReconnectFailures = 0;
     syncWifiToDjangoIfNeeded();
     if (!webServerBegun) {
       server.on("/", handleRoot);
       server.begin();
       webServerBegun = true;
       Serial.print("Dashboard: http://");
       Serial.println(WiFi.localIP());
     }
     server.handleClient();
     return;
   }
 
   webServerBegun = false;
   unsigned long retryGap = wifiNeedsReconnect ? WIFI_RETRY_MS_QUICK : WIFI_RETRY_MS;
   if (millis() - lastWifiRetryMs < retryGap) return;
   lastWifiRetryMs = millis();
 
   Serial.println("WiFi lost — reconnecting...");
   if (reconnectWifiSoft(WIFI_RECONNECT_TIMEOUT_MS)) {
     wifiNeedsReconnect = false;
     staReconnectFailures = 0;
     syncWifiToDjangoIfNeeded();
     return;
   }
 
   staReconnectFailures++;
   if (staReconnectFailures >= STA_FAIL_BEFORE_AP) {
     Serial.println("WiFi failed repeatedly — opening setup hotspot");
     startWifiConfigPortal(false);
   }
 }
 
 void setIndicatorLed(uint8_t pin, bool on) {
   analogWrite(pin, on ? LED_PWM_LEVEL : 0);
 }
 
 void updatePowerLed() {
   setIndicatorLed(POWER_LED_PIN, true);
 }
 
 void updateWifiLed() {
   setIndicatorLed(WIFI_LED_PIN, isWifiLinked());
 }
 
 bool readTempCelsius(float *outC) {
   for (uint8_t attempt = 0; attempt < 4; attempt++) {
     if (attempt) delay(40);
     yield();
     sensors.requestTemperatures();
     yield();
     float c = sensors.getTempCByIndex(0);
     if (c != DEVICE_DISCONNECTED_C && c >= -55.0f && c <= 125.0f) {
       *outC = c;
       return true;
     }
   }
   return false;
 }
 
 void pruneTempHistory(unsigned long nowMs) {
   while (histCount > 0 && nowMs - histTime[0] > TEMP_RISE_WINDOW_MS) {
     for (uint8_t i = 0; i + 1 < histCount; i++) {
       histTime[i] = histTime[i + 1];
       histTemp[i] = histTemp[i + 1];
     }
     histCount--;
   }
 }
 
 void appendTempHistory(float tempC, unsigned long nowMs) {
   static unsigned long lastHistSampleMs = 0;
   pruneTempHistory(nowMs);
   if (histCount > 0 && nowMs - lastHistSampleMs < TEMP_HISTORY_SAMPLE_MS) return;
   lastHistSampleMs = nowMs;
   if (histCount >= TEMP_HISTORY_MAX) {
     for (uint8_t i = 0; i + 1 < TEMP_HISTORY_MAX; i++) {
       histTime[i] = histTime[i + 1];
       histTemp[i] = histTemp[i + 1];
     }
     histCount = TEMP_HISTORY_MAX - 1;
   }
   histTime[histCount] = nowMs;
   histTemp[histCount] = tempC;
   histCount++;
 }
 
 bool getRiseReferenceTemp(unsigned long nowMs, float *refOut) {
   pruneTempHistory(nowMs);
   if (histCount == 0) return false;
   unsigned long ageOldest = nowMs - histTime[0];
   if (ageOldest < TEMP_RISE_WINDOW_MS - TEMP_HISTORY_SAMPLE_MS) return false;
   *refOut = histTemp[0];
   return true;
 }
 
 void checkTempRiseAlarm(float currentC, unsigned long nowMs) {
   float refC;
   if (!getRiseReferenceTemp(nowMs, &refC)) return;
 
   float rise = currentC - refC;
   if (rise < TEMP_RISE_ALARM_C) {
     lastTempRiseBeepMs = 0;
     return;
   }
 
   if (lastTempRiseBeepMs == 0 || (nowMs - lastTempRiseBeepMs >= TEMP_RISE_BEEP_REPEAT_MS)) {
     lastTempRiseBeepMs = nowMs;
     Serial.print("TEMP RISE ALARM: +");
     Serial.print(rise, 1);
     Serial.print(" C vs ref ");
     Serial.print(refC, 1);
     Serial.println(" C (30s sliding window)");
     if (lastTwilioHeatCallMs == 0 ||
         (nowMs - lastTwilioHeatCallMs >= TWILIO_HEAT_CALL_COOLDOWN_MS)) {
       if (sendTwilioVoiceSay(
               "Temperature rose two degrees in thirty seconds. Check the shop.",
               "heat")) {
         lastTwilioHeatCallMs = nowMs;
       }
     }
     beep(6, 70);
   }
 }
 
 // Poll from loop() on TEMP_POLL_MS so the 30s rise window tracks wall time.
 void reportTemperature() {
   if (!ds18b20Present) return;
 
   unsigned long nowMs = millis();
   float tempC;
   if (readTempCelsius(&tempC)) {
     lastTemperatureC = tempC;
     appendTempHistory(tempC, nowMs);
     checkTempRiseAlarm(tempC, nowMs);
     Serial.print("Temperature: ");
     Serial.print(tempC);
     Serial.println(" C");
   } else {
     lastTemperatureC = NAN;
     Serial.println("Temperature: read failed");
   }
 }
 
 void handleRoot() {
   String html = "<!DOCTYPE html><html><head><meta name='viewport' content='width=device-width, initial-scale=1'>";
   html += "<meta http-equiv='refresh' content='2'>";
 
   if (systemStatus == "SAFE") {
     html += "<style>body { background-color: #1b5e20; color: white; font-family: sans-serif; text-align: center; padding-top: 30%; }</style>";
     html += "</head><body><h1 style='font-size: 55px;'>SECURE</h1><h2>Scanning Area...</h2>";
   } else {
     html += "<style>body { background-color: #b71c1c; color: white; font-family: sans-serif; text-align: center; padding-top: 30%; }</style>";
     html += "</head><body><h1 style='font-size: 55px;'>ALERT!</h1><h2>Intruder at " + lastAlertAngle + " deg</h2>";
   }
 
   if (!isnan(lastTemperatureC)) {
     html += "<p style='font-size: 20px; margin-top: 18px;'>Temperature: " + String(lastTemperatureC, 1) + " C</p>";
   }
   html += "</body></html>";
 
   server.send(200, "text/html", html);
 }
 
 void smoothMoveStep(int targetAngle) {
   targetAngle = constrain(targetAngle, 0, 180);
   if (currentServoAngle == targetAngle) return;
 
   int diff = targetAngle - currentServoAngle;
   int step = (diff > 0) ? SERVO_STEP_DEG : -SERVO_STEP_DEG;
   if (abs(diff) < abs(step)) {
     currentServoAngle = targetAngle;
   } else {
     currentServoAngle += step;
   }
   myServo.write(currentServoAngle);
   delay(SERVO_STEP_DELAY_MS);
   if (webServerBegun && isWifiLinked()) server.handleClient();
 }
 
 void smoothMove(int targetAngle) {
   targetAngle = constrain(targetAngle, 0, 180);
   while (currentServoAngle != targetAngle) {
     smoothMoveStep(targetAngle);
   }
 }
 
 float medianOfSorted(float *values, int count) {
   if (count <= 0) return 0;
   if (count % 2 == 1) return values[count / 2];
   return (values[count / 2 - 1] + values[count / 2]) / 2.0f;
 }
 
 void sortFloatArray(float *values, int count) {
   for (int i = 1; i < count; i++) {
     float key = values[i];
     int j = i - 1;
     while (j >= 0 && values[j] > key) {
       values[j + 1] = values[j];
       j--;
     }
     values[j + 1] = key;
   }
 }
 
 float readSingleDistanceCm(unsigned int pulseTimeoutUs) {
   digitalWrite(TRIG_PIN, LOW);
   delayMicroseconds(2);
   digitalWrite(TRIG_PIN, HIGH);
   delayMicroseconds(10);
   digitalWrite(TRIG_PIN, LOW);
   long duration = pulseIn(ECHO_PIN, HIGH, pulseTimeoutUs);
   if (duration <= 0) return 0;
   float distance = duration * SOUND_VELOCITY / 2.0f;
   if (distance < MIN_DISTANCE || distance > MAX_DISTANCE) return 0;
   return distance;
 }
 
 // --- Ultrasonic: one rule — 3% sensor error band on every distance calculation ---
 
float sensorErrorCm(float refCm) {
  if (refCm <= 0) return (float)MIN_INTRUSION_CM;
  float band = refCm * runtimeIgnorePercent;
  if (band < (float)MIN_INTRUSION_CM) band = (float)MIN_INTRUSION_CM;
  return band;
}

float intrusionMinDropCm(float baseCm) {
  if (baseCm <= 0) return (float)runtimeMinIntrusionCm;
  float fromNoise = sensorErrorCm(baseCm) * INTRUSION_NOISE_MULT;
  float floor = (float)runtimeMinIntrusionCm;
  return fromNoise > floor ? fromNoise : floor;
}

bool burstIsIntrusion(float distanceCm, float wallBase) {
  if (distanceCm <= 0 || wallBase <= 0) return false;
  if (distanceCm > (float)DETECT_MAX_CM) return false;
  return (wallBase - distanceCm) >= intrusionMinDropCm(wallBase);
}

bool dualBurstConfirmsIntrusion(float first, float second, float wallBase) {
  if (!burstIsIntrusion(first, wallBase) || !burstIsIntrusion(second, wallBase)) return false;
  float ref = first < second ? first : second;
  if (ref <= 0) ref = first > 0 ? first : second;
  // Both bursts must agree within one sensor-error band (was 1.5x — too loose)
  return fabs(first - second) <= sensorErrorCm(ref);
}
 
 int collectDistanceSamples(float *readings, int samples, bool serviceWeb, unsigned int pulseTimeoutUs) {
   if (samples > MAX_READ_SAMPLES) samples = MAX_READ_SAMPLES;
   int valid = 0;
   for (int i = 0; i < samples; i++) {
     float distance = readSingleDistanceCm(pulseTimeoutUs);
     if (distance > 0) readings[valid++] = distance;
     if (serviceWeb && webServerBegun && isWifiLinked()) server.handleClient();
     yield();
     delay(SAMPLE_GAP_MS);
   }
   lastValidSampleCount = valid;
   return valid;
 }
 
 // Mean of readings within 3% of anchor (sorted array). fromPeak=true → wall cluster.
 float clusterMeanWithinError(float *readings, int valid, float anchor, bool fromPeak) {
   float tol = sensorErrorCm(anchor);
   float sum = 0;
   int count = 0;
 
   if (fromPeak) {
     for (int i = valid - 1; i >= 0; i--) {
       if (anchor - readings[i] <= tol) {
         sum += readings[i];
         count++;
       } else {
         break;
       }
     }
   } else {
     for (int i = 0; i < valid; i++) {
       if (readings[i] - anchor <= tol) {
         sum += readings[i];
         count++;
       } else {
         break;
       }
     }
   }
 
   if (count < MIN_CLUSTER_SAMPLES) return 0;
   lastReadingSpreadCm = tol;
   return sum / count;
 }
 
 // Empty room: furthest stable cluster = back-wall base distance.
 float measureWallBase(bool serviceWeb, unsigned int pulseTimeoutUs) {
   float readings[MAX_READ_SAMPLES];
   int valid = collectDistanceSamples(readings, CALIBRATION_SAMPLES, serviceWeb, pulseTimeoutUs);
   if (valid < MIN_CLUSTER_SAMPLES) return 0;
 
   sortFloatArray(readings, valid);
   float peak = readings[valid - 1];
   float wall = clusterMeanWithinError(readings, valid, peak, true);
   if (wall > 0) return wall;
 
   return medianOfSorted(readings, valid);
 }
 
 // Scan: close cluster (outside noise band of base) = human; else wall cluster = clear room.
 float measureScanDistance(float wallBase, bool serviceWeb, unsigned int pulseTimeoutUs) {
   float readings[MAX_READ_SAMPLES];
   int valid = collectDistanceSamples(readings, SCAN_SAMPLES, serviceWeb, pulseTimeoutUs);
   if (valid < MIN_CLUSTER_SAMPLES) return 0;
 
   sortFloatArray(readings, valid);
 
  if (wallBase > 0) {
    float minDrop = intrusionMinDropCm(wallBase);
    float closeBuf[MAX_READ_SAMPLES];
    int closeCount = 0;
    for (int i = 0; i < valid; i++) {
      if (readings[i] <= (float)DETECT_MAX_CM && wallBase - readings[i] >= minDrop) {
        closeBuf[closeCount++] = readings[i];
      }
    }
     if (closeCount >= SCAN_INTRUDER_MIN_SAMPLES) {
       sortFloatArray(closeBuf, closeCount);
       float spread = closeBuf[closeCount - 1] - closeBuf[0];
       if (spread > MAX_CLUSTER_SPREAD_CM) {
         // Mixed echoes — treat as unstable, fall through to wall/median
       } else {
         lastReadingSpreadCm = spread;
         return medianOfSorted(closeBuf, closeCount);
       }
     }
 
    float wallSum = 0;
    int wallCount = 0;
    float err = sensorErrorCm(wallBase);
    for (int i = 0; i < valid; i++) {
       if (fabs(readings[i] - wallBase) <= err) {
         wallSum += readings[i];
         wallCount++;
       }
     }
     if (wallCount >= MIN_CLUSTER_SAMPLES) {
       return wallSum / wallCount;
     }
 
     float peak = readings[valid - 1];
     float wallCluster = clusterMeanWithinError(readings, valid, peak, true);
     if (wallCluster > 0) return wallCluster;
   }
 
   return medianOfSorted(readings, valid);
 }
 
 float mergeScanBursts(float a, float b, float wallBase) {
   if (a <= 0 && b <= 0) return 0;
   if (a <= 0) return b;
   if (b <= 0) return a;
 
  if (wallBase > 0) {
    float minDrop = intrusionMinDropCm(wallBase);
    bool aIntruder = (wallBase - a) >= minDrop;
    bool bIntruder = (wallBase - b) >= minDrop;
 
     if (aIntruder && bIntruder) {
       float ref = a > b ? a : b;
       if (fabs(a - b) <= sensorErrorCm(ref)) return (a + b) * 0.5f;
       return a < b ? a : b;
     }
     if (aIntruder) return a;
     if (bIntruder) return b;
 
     float ref = a > b ? a : b;
     if (fabs(a - b) <= sensorErrorCm(ref)) return (a + b) * 0.5f;
     return (a + b) * 0.5f;
   }
 
   float ref = a > b ? a : b;
   if (fabs(a - b) <= sensorErrorCm(ref)) return (a + b) * 0.5f;
   return a < b ? a : b;
 }
 
 int requiredDropForBase(float baseCm) {
   return int(sensorErrorCm(baseCm) + 0.5f);
 }
 
float intrusionThresholdForBase(float baseCm) {
  return baseCm - intrusionMinDropCm(baseCm);
}
 
 bool isHumanRange(float distanceCm) {
   return distanceCm >= HUMAN_FAR_MIN_CM && distanceCm <= HUMAN_NEAR_MAX_CM;
 }
 
bool isIntruderCandidate(int angleIndex, float distance) {
  if (distance <= 0 || !isHumanRange(distance)) return false;

  if (savedDistance[angleIndex] > 0) {
    float base = savedDistance[angleIndex];
    return (base - distance) >= intrusionMinDropCm(base);
  }

  return distance >= OPEN_DETECT_MIN_CM && distance <= OPEN_DETECT_MAX_CM;
}

float readDistanceConfirmed(float wallBase, bool serviceWeb, unsigned int pulseTimeoutUs) {
  float first = measureScanDistance(wallBase, serviceWeb, pulseTimeoutUs);
  delay(SCAN_BURST_GAP_MS);
  float second = measureScanDistance(wallBase, serviceWeb, pulseTimeoutUs);
  lastDualBurstIntrusion = dualBurstConfirmsIntrusion(first, second, wallBase);
  return mergeScanBursts(first, second, wallBase);
}
 
 String twilioUrlEncode(const String &s) {
   String e;
   const char *hex = "0123456789ABCDEF";
 
   for (unsigned int i = 0; i < s.length(); i++) {
     char c = s[i];
 
     if ((c >= 'A' && c <= 'Z') ||
         (c >= 'a' && c <= 'z') ||
         (c >= '0' && c <= '9') ||
         c == '-' || c == '_' || c == '.' || c == '~') {
       e += c;
     } else if (c == ' ') {
       e += '+';
     } else {
       e += '%';
       e += hex[((unsigned char)c) >> 4];
       e += hex[((unsigned char)c) & 15];
     }
   }
 
   return e;
 }
 
 bool sendTwilioVoiceSay(const char *sayPhrase, const char *debugTag) {
   if (!isWifiLinked()) {
     Serial.print("[Twilio/");
     Serial.print(debugTag);
     Serial.println("] skip: WiFi not connected");
     return false;
   }
 
   // Phone number must come from Django API (notification.phone field).
   // TWILIO_TO_NUMBER is intentionally empty — never fall back to a hardcoded number.
   String toNumber = twilioToNumber;
   toNumber.trim();
   if (toNumber.length() < 8) {
     Serial.print("[Twilio/");
     Serial.print(debugTag);
     Serial.println("] skip: no phone from Django yet (waiting for /commands/ notification.phone)");
     return false;
   }
 
   String url =
     String("https://api.twilio.com/2010-04-01/Accounts/")
     + TWILIO_ACCOUNT_SID +
     "/Calls.json";
 
   String twiml =
     String("<Response><Say voice=\"alice\">") + sayPhrase + "</Say></Response>";
 
   String body =
     "To=" + twilioUrlEncode(toNumber) +
     "&From=" + twilioUrlEncode(TWILIO_FROM_NUMBER) +
     "&Twiml=" + twilioUrlEncode(twiml);
 
   for (int attempt = 1; attempt <= TWILIO_POST_RETRIES; attempt++) {
     Serial.print("[Twilio/");
     Serial.print(debugTag);
     Serial.print("] try ");
     Serial.print(attempt);
     Serial.print("/");
     Serial.print(TWILIO_POST_RETRIES);
     Serial.print(" heap=");
     Serial.print(ESP.getFreeHeap());
     Serial.print(" RSSI=");
     Serial.println(WiFi.RSSI());
 
     WiFiClientSecure ssl;
     ssl.setInsecure();
     ssl.setTimeout(20000);
 
     HTTPClient http;
     if (!http.begin(ssl, url)) {
       Serial.println("[Twilio] http.begin failed");
       delay(TWILIO_RETRY_GAP_MS);
       yield();
       continue;
     }
 
     http.setAuthorization(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN);
     http.setTimeout(25000);
     http.addHeader("Content-Type", "application/x-www-form-urlencoded");
 
     int code = http.POST(body);
     String resp = http.getString();
     http.end();
     ssl.stop();
 
     Serial.print("[Twilio/");
     Serial.print(debugTag);
     Serial.print("] HTTP ");
     Serial.print(code);
     if (code < 0) {
       Serial.print(" (");
       Serial.print(http.errorToString(code));
       Serial.print(")");
     }
     Serial.println();
 
     if (resp.length() > 0 && (code < 200 || code >= 300)) {
       unsigned int n = resp.length();
       if (n > 280) n = 280;
       Serial.print("[Twilio] body ");
       Serial.println(resp.substring(0, n));
     }
 
     if (code >= 200 && code < 300)
       return true;
 
     delay(TWILIO_RETRY_GAP_MS + (attempt * 200));
     yield();
   }
 
   return false;
 }
 
 bool tryIntruderTwilioOnce() {
   String toNumber = twilioToNumber;
   toNumber.trim();
   if (toNumber.length() < 8 && twilioAlternateNumber.length() >= 8)
     twilioToNumber = twilioAlternateNumber;

   toNumber = twilioToNumber;
   toNumber.trim();
   if (toNumber.length() < 8) {
     Serial.println("[Twilio/intruder] skip: no phone from Django yet");
     return false;  // do NOT burn cooldown — keep trying after /commands/ fills phone
   }

   unsigned long now = millis();
   if (lastTwilioIntruderAttemptMs != 0 &&
       now - lastTwilioIntruderAttemptMs < TWILIO_INTRUDER_MIN_RETRY_GAP_MS)
     return false;
   lastTwilioIntruderAttemptMs = now;
   return sendTwilioVoiceSay(
     "your shop is under threat, please take required action",
     "intruder");
 }
 
 void beep(int times, int durationMs) {
   for (int i = 0; i < times; i++) {
     digitalWrite(BUZZER_PIN, HIGH);
     delay(durationMs);
     digitalWrite(BUZZER_PIN, LOW);
     delay(durationMs);
   }
 }
 
 String jsonEscape(String value) {
   value.replace("\\", "\\\\");
   value.replace("\"", "\\\"");
   return value;
 }
 
bool djangoIoTConfigured() {
  return djangoDeviceId.length() > 0 && djangoDeviceId != "CHANGE_ME" &&
         djangoDeviceToken.length() > 0 && djangoDeviceToken != "CHANGE_ME";
}

bool acquireDjangoHttp() {
  if (djangoHttpInUse) return false;
  djangoHttpInUse = true;
  return true;
}

void releaseDjangoHttp() {
  djangoHttpInUse = false;
}

bool parsePlainHttpUrl(const String &url, String &host, uint16_t &port, String &path) {
  const String prefix = "http://";
  if (!url.startsWith(prefix)) return false;
  int rest = prefix.length();
  int slash = url.indexOf('/', rest);
  String authority = slash < 0 ? url.substring(rest) : url.substring(rest, slash);
  path = slash < 0 ? "/" : url.substring(slash);
  int colon = authority.indexOf(':');
  if (colon < 0) {
    host = authority;
    port = 80;
  } else {
    host = authority.substring(0, colon);
    port = (uint16_t)authority.substring(colon + 1).toInt();
    if (port == 0) port = 80;
  }
  return host.length() > 0;
}

#if USE_LOCAL_DJANGO
bool waitDjangoTcpReady(uint8_t maxAttempts = 8) {
  WiFiClient probe;
  probe.setTimeout(5000);
  for (uint8_t i = 0; i < maxAttempts; i++) {
    if (probe.connect(LOCAL_PC_IP, 8000)) {
      probe.stop();
      return true;
    }
    probe.stop();
    delay(400);
    yield();
  }
  Serial.println("[Django] TCP probe failed — runserver 0.0.0.0:8000? Same WiFi as PC?");
  return false;
}
#endif

bool beginDjangoHttp(HTTPClient &http, const String &url, WiFiClientSecure &secureClient, WiFiClient &plainClient) {
  if (!acquireDjangoHttp()) {
    Serial.println("[Django] HTTP busy — skip");
    return false;
  }
  http.setTimeout(DJANGO_HTTP_TIMEOUT_MS);
  if (url.startsWith("https://")) {
    secureClient.setInsecure();
    secureClient.setTimeout(DJANGO_HTTP_TIMEOUT_MS);
    if (!http.begin(secureClient, url)) {
      releaseDjangoHttp();
      return false;
    }
    return true;
  }
  plainClient.setTimeout(DJANGO_HTTP_TIMEOUT_MS);
  String host, path;
  uint16_t port = 80;
  if (parsePlainHttpUrl(url, host, port, path)) {
    if (!http.begin(plainClient, host, port, path)) {
      releaseDjangoHttp();
      return false;
    }
    return true;
  }
  if (!http.begin(plainClient, url)) {
    releaseDjangoHttp();
    return false;
  }
  return true;
}

void finishDjangoHttp(HTTPClient &http, WiFiClient &plainClient, WiFiClientSecure &secureClient) {
  http.end();
  plainClient.stop();
  secureClient.stop();
  releaseDjangoHttp();
}

void serialLogDjangoHttp(const char *tag, const char *method, const String &url, int httpCode, const String &body, HTTPClient *http = nullptr) {
   Serial.println();
   Serial.print("[Django/");
   Serial.print(tag);
   Serial.print("] ");
   Serial.print(method);
   Serial.print(" ");
   Serial.println(url);
   Serial.print("[Django/");
   Serial.print(tag);
   Serial.print("] HTTP ");
   Serial.println(httpCode);
  if (httpCode < 0) {
    if (http != nullptr) {
      Serial.print("[Django] error: ");
      Serial.println(http->errorToString(httpCode));
    }
    Serial.println("[Django] body: (no response — check WiFi, API_BASE_URL, device token)");
    Serial.println();
    return;
  }
   if (body.length() == 0) {
     Serial.println("[Django] body: (empty)");
   } else {
     unsigned int n = body.length();
     if (n > DJANGO_SERIAL_BODY_MAX) n = DJANGO_SERIAL_BODY_MAX;
     Serial.print("[Django] body (");
     Serial.print(body.length());
     Serial.println(" bytes):");
     Serial.println(body.substring(0, n));
     if (body.length() > DJANGO_SERIAL_BODY_MAX)
       Serial.println("[Django] ...(truncated)");
   }
   Serial.println();
 }
 
 bool postHotspotWifiToDjango(const String &ssid, const String &pass) {
   if (!isWifiLinked() || !djangoIoTConfigured()) return false;
 
   HTTPClient http;
   WiFiClientSecure secureClient;
   WiFiClient plainClient;
   String url = apiBaseUrl + "/iot/devices/" + djangoDeviceId + "/wifi-report/";
   if (!beginDjangoHttp(http, url, secureClient, plainClient)) {
     Serial.println("[Django/wifi-report] http.begin failed");
     return false;
   }
 
  http.addHeader("Content-Type", "application/json");
  http.addHeader("X-Device-Token", djangoDeviceToken);

  String body = "{\"ssid\":\"" + jsonEscape(ssid) + "\",\"password\":\"" + jsonEscape(pass) + "\"}";
  int code = http.POST(body);
  String resp = http.getString();
  serialLogDjangoHttp("wifi-report", "POST", url, code, resp, &http);
  finishDjangoHttp(http, plainClient, secureClient);
  return code >= 200 && code < 300;
}
 
 bool syncWifiCredentialsToDjango(const String &ssid, const String &pass) {
   if (!djangoIoTConfigured()) {
     Serial.println("[Django/wifi-report] skip: set DEVICE_ID and DEVICE_TOKEN");
     return false;
   }
   if (!isWifiLinked()) {
     Serial.println("[Django/wifi-report] skip: WiFi not linked yet");
     return false;
   }
 
   for (uint8_t attempt = 1; attempt <= WIFI_DJANGO_POST_RETRIES; attempt++) {
     Serial.print("[Django/wifi-report] sync attempt ");
     Serial.print(attempt);
     Serial.print("/");
    Serial.println(WIFI_DJANGO_POST_RETRIES);
#if USE_LOCAL_DJANGO
    if (attempt == 1 && !waitDjangoTcpReady()) {
      delay(WIFI_DJANGO_POST_GAP_MS);
      continue;
    }
#endif
    if (postHotspotWifiToDjango(ssid, pass)) {
       lastSyncedWifiSsid = ssid;
       lastSyncedWifiPass = pass;
       return true;
     }
     delay(WIFI_DJANGO_POST_GAP_MS);
   }
   return false;
 }
 
 void syncWifiToDjangoIfNeeded() {
   if (wifiSsid.length() == 0 || wifiPass.length() == 0) return;
   if (wifiSsid == lastSyncedWifiSsid && wifiPass == lastSyncedWifiPass) return;
   // Don't hammer Django if it's down — wait WIFI_SYNC_COOLDOWN_MS between failed attempts
   if (lastSyncFailMs != 0 && millis() - lastSyncFailMs < WIFI_SYNC_COOLDOWN_MS) return;
   if (!syncWifiCredentialsToDjango(wifiSsid, wifiPass)) {
     lastSyncFailMs = millis();
   } else {
     lastSyncFailMs = 0;
   }
 }
 
 void printDjangoIoTConfig() {
   Serial.println("--- Django IoT ---");
   Serial.print("API: ");
   Serial.println(apiBaseUrl);
   Serial.print("Device: ");
   Serial.println(djangoDeviceId);
#if USE_LOCAL_DJANGO
   Serial.println("Mode: LOCAL HTTP");
#else
   Serial.println("Mode: PRODUCTION HTTPS (1 req/loop, staggered)");
#endif
   Serial.print("Commands every ");
   Serial.print(COMMAND_POLL_MS / 1000);
   Serial.print("s, telemetry every ");
   Serial.print(TELEMETRY_POST_MS / 1000);
   Serial.println("s");
   if (!djangoIoTConfigured())
     Serial.println("WARN: Set DEVICE_ID and DEVICE_TOKEN in sketch");
   Serial.println("----------------");
 }
 
 void postCommandAck(int commandRevision, int wifiRevision, String wifiStatus, int ultrasonicRevision, String ultrasonicStatus) {
   if (!isWifiLinked() || !djangoIoTConfigured()) return;
   if (commandRevision < 0 && wifiRevision < 0 && ultrasonicRevision < 0) return;
 
   HTTPClient http;
   WiFiClientSecure secureClient;
   WiFiClient plainClient;
   String url = apiBaseUrl + "/iot/devices/" + djangoDeviceId + "/commands/ack/";
   if (!beginDjangoHttp(http, url, secureClient, plainClient)) {
     Serial.println("[Django/ack] http.begin failed");
     return;
   }
   http.addHeader("Content-Type", "application/json");
   http.addHeader("X-Device-Token", djangoDeviceToken);
 
   String body = "{";
   bool hasField = false;
   if (commandRevision >= 0) {
     body += "\"command_revision\":" + String(commandRevision);
     hasField = true;
   }
   if (wifiRevision >= 0) {
     if (hasField) body += ",";
     body += "\"wifi_revision\":" + String(wifiRevision) + ",\"wifi_status\":\"" + wifiStatus + "\",\"wifi_ssid\":\"" + jsonEscape(wifiSsid) + "\"";
     hasField = true;
   }
   if (ultrasonicRevision >= 0) {
     if (hasField) body += ",";
     body += "\"ultrasonic_revision\":" + String(ultrasonicRevision) + ",\"ultrasonic_status\":\"" + ultrasonicStatus + "\"";
   }
   body += "}";
 
  int code = http.POST(body);
  String resp = http.getString();
  serialLogDjangoHttp("ack", "POST", url, code, resp, &http);
  finishDjangoHttp(http, plainClient, secureClient);
}

void postTelemetry() {
   if (!isWifiLinked() || millis() - lastTelemetryPostMs < TELEMETRY_POST_MS) return;
   if (!djangoIoTConfigured()) return;
   lastTelemetryPostMs = millis();
 
   HTTPClient http;
   WiFiClientSecure secureClient;
   WiFiClient plainClient;
   String url = apiBaseUrl + "/iot/devices/" + djangoDeviceId + "/telemetry/";
   if (!beginDjangoHttp(http, url, secureClient, plainClient)) {
     Serial.println("[Django/telemetry] http.begin failed");
     return;
   }
   http.addHeader("Content-Type", "application/json");
   http.addHeader("X-Device-Token", djangoDeviceToken);
   http.addHeader("Connection", "close");
 
   float distance = currentDistance[0] > 0 ? currentDistance[0] : 0;
   String tempValue = isnan(lastTemperatureC) ? "null" : String(lastTemperatureC, 2);
   String body = "{";
   body += "\"temperature\":" + tempValue + ",";
   body += "\"ultrasonic_distance\":" + String(distance, 2) + ",";
   body += "\"heat_alarm\":" + String(lastTempRiseBeepMs > 0 ? "true" : "false") + ",";
   body += "\"status\":\"" + systemStatus + "\",";
   body += "\"armed\":" + String(remoteEnabled ? "true" : "false") + ",";
   body += "\"online\":true,";
   body += "\"firmware_version\":\"" + String(FIRMWARE_VERSION) + "\"";
   body += "}";
 
  int code = http.POST(body);
  String resp = http.getString();
  serialLogDjangoHttp("telemetry", "POST", url, code, body + " -> " + resp, &http);
  finishDjangoHttp(http, plainClient, secureClient);
}
 
 void applyWifiUpdate(String newSsid, String newPass, int revision) {
   if (newSsid.length() == 0 || revision <= 0) return;
   String oldSsid = wifiSsid;
   String oldPass = wifiPass;
 
   Serial.println("Applying WiFi update from Django...");
   WiFi.disconnect();
   delay(300);
   if (connectWifi(newSsid, newPass, WIFI_UPDATE_CONNECT_MS)) {
     saveWifiCredentials(newSsid, newPass);
     Serial.println("WiFi update OK.");
     syncWifiCredentialsToDjango(newSsid, newPass);
     postCommandAck(-1, revision, "success", -1, "");
     return;
   }
   Serial.println("WiFi update failed — reverting to old credentials.");
   WiFi.disconnect();
   delay(300);
   connectWifi(oldSsid, oldPass, WIFI_UPDATE_CONNECT_MS);
   postCommandAck(-1, revision, "failed", -1, "");
 }
 
 void applyNotificationFromCommands(const String &payload) {
   int notifPos = payload.indexOf("\"notification\"");
   if (notifPos < 0) return;
 
   String section = payload.substring(notifPos);
   String phone = jsonStringValue(section, "phone", "");
   String altPhone = jsonStringValue(section, "alternate_phone", "");
 
   if (phone.length() >= 8 && phone != twilioToNumber) {
     twilioToNumber = phone;
     Serial.print("[IoT] Alert phone updated: ");
     Serial.println(twilioToNumber);
   } else if (phone.length() >= 8) {
     twilioToNumber = phone;
   }
 
   if (altPhone.length() >= 8) {
     twilioAlternateNumber = altPhone;
   } else {
     twilioAlternateNumber = "";
   }
 }
 
 void pollDjangoCommands() {
   if (!isWifiLinked() || !djangoIoTConfigured()) return;
   lastCommandPollMs = millis();
 
   HTTPClient http;
   WiFiClientSecure secureClient;
   WiFiClient plainClient;
   // lite=1: smaller JSON (still includes notification.phone for Twilio)
   String url = apiBaseUrl + "/iot/devices/" + djangoDeviceId + "/commands/?lite=1";
   if (!beginDjangoHttp(http, url, secureClient, plainClient)) {
     Serial.println("[Django/commands] http.begin failed");
     return;
   }
   http.addHeader("X-Device-Token", djangoDeviceToken);
   http.addHeader("Connection", "close");
  int code = http.GET();
  String payload = http.getString();
  serialLogDjangoHttp("commands", "GET", url, code, payload, &http);
  finishDjangoHttp(http, plainClient, secureClient);

  if (code == 200) {
     applyNotificationFromCommands(payload);
 
     bool prevRemote = remoteEnabled;
     djangoDesiredPower = jsonBoolValue(payload, "desired_power_state", djangoDesiredPower);
     djangoScheduleGate = jsonBoolValue(payload, "schedule_gate_active", djangoScheduleGate);
     djangoInScheduleWindow = jsonBoolValue(payload, "in_schedule_window", djangoInScheduleWindow);
     int commandRevision = jsonIntValue(payload, "command_revision", -1);
     int powerPos = payload.indexOf("\"power\"");
     String powerSection = powerPos >= 0 ? payload.substring(powerPos) : payload;
     remoteEnabled = jsonBoolValue(powerSection, "enabled", remoteEnabled);
 
     if (remoteEnabled != prevRemote) {
       Serial.print("[IoT] Scanning ");
       Serial.println(remoteEnabled ? "ON" : "OFF");
     }
 
     // Defer ack to next slot — never stack 2 HTTPS calls in one poll
     if (commandRevision >= 0 && commandRevision != lastAckedCommandRevision)
       pendingCommandAckRevision = commandRevision;
 
     int wifiPos = payload.indexOf("wifi_update");
     if (wifiPos >= 0) {
       String wifiSection = payload.substring(wifiPos);
       int wifiRevision = jsonIntValue(wifiSection, "revision", -1);
       String newSsid = jsonStringValue(wifiSection, "ssid", "");
       String newPass = jsonStringValue(wifiSection, "password", "");
       if (newSsid.length() > 0 && newPass.length() > 0 && wifiRevision > 0)
         applyWifiUpdate(newSsid, newPass, wifiRevision);
     }
 
     int ultrasonicPos = payload.indexOf("ultrasonic_update");
     if (ultrasonicPos >= 0) {
       String ultrasonicSection = payload.substring(ultrasonicPos);
       int configPos = ultrasonicSection.indexOf("\"config\"");
       String configSection = configPos >= 0 ? ultrasonicSection.substring(configPos) : ultrasonicSection;
       float ignorePercent = jsonFloatValue(configSection, "ignore_percent", runtimeIgnorePercent);
       int minIntrusion = jsonIntValue(configSection, "min_intrusion_cm", runtimeMinIntrusionCm);
       bool recalibrate = jsonBoolValue(configSection, "recalibrate", false);
       int ultrasonicRevision = jsonIntValue(ultrasonicSection, "revision", -1);
       if (ignorePercent >= 0.01f && ignorePercent <= 0.05f) runtimeIgnorePercent = ignorePercent;
       else runtimeIgnorePercent = SENSOR_ERROR_PERCENT;
       if (minIntrusion > 0 && minIntrusion <= 25) runtimeMinIntrusionCm = minIntrusion;
       if (recalibrate) performCalibration();
      if (ultrasonicRevision > 0 && ultrasonicRevision != lastAckedUltrasonicRevision)
        pendingUltrasonicAckRevision = ultrasonicRevision;
    }
  }
}

void maintainDjangoIoT() {
  if (!isWifiLinked() || !djangoIoTConfigured() || djangoHttpInUse) return;
  unsigned long now = millis();

  // One HTTPS request per invoke — ESP8266 TLS heap cannot stack calls
  if (pendingCommandAckRevision >= 0) {
    postCommandAck(pendingCommandAckRevision, -1, "", -1, "");
    lastAckedCommandRevision = pendingCommandAckRevision;
    pendingCommandAckRevision = -1;
    return;
  }
  if (pendingUltrasonicAckRevision >= 0) {
    postCommandAck(-1, -1, "", pendingUltrasonicAckRevision, "success");
    lastAckedUltrasonicRevision = pendingUltrasonicAckRevision;
    pendingUltrasonicAckRevision = -1;
    return;
  }
  if (now - lastCommandPollMs >= COMMAND_POLL_MS) {
    pollDjangoCommands();
    return;
  }
  if (now - lastTelemetryPostMs >= TELEMETRY_POST_MS) {
    postTelemetry();
  }
}
 
 void performCalibration() {
   runtimeIgnorePercent = SENSOR_ERROR_PERCENT;
   Serial.println("Calibration (90 deg, 3% error band)...");
 
   myServo.write(FIXED_SERVO_ANGLE);
   currentServoAngle = FIXED_SERVO_ANGLE;
   delay(CALIBRATION_SETTLE_MS);
 
   for (int w = 0; w < 6; w++) {
     readSingleDistanceCm(PULSE_TIMEOUT_US);
     delay(80);
   }
 
   float roundBase[CALIBRATION_ROUNDS];
   int roundCount = 0;
 
   for (int round = 0; round < CALIBRATION_ROUNDS; round++) {
     float reading = measureWallBase(true, PULSE_TIMEOUT_US);
     Serial.print("  Round ");
     Serial.print(round + 1);
     Serial.print(": ");
     if (reading > 0) {
       Serial.println(reading, 1);
       roundBase[roundCount++] = reading;
     } else {
       Serial.println("--");
     }
     delay(200);
   }
 
   int retries = 0;
   while (roundCount == 0 && retries < 4) {
     delay(300);
     float reading = measureWallBase(true, PULSE_TIMEOUT_US);
     if (reading > 0) roundBase[roundCount++] = reading;
     retries++;
   }
 
   savedDistance[0] = 0;
   if (roundCount > 0) {
     sortFloatArray(roundBase, roundCount);
     savedDistance[0] = medianOfSorted(roundBase, roundCount);
     Serial.print("  Base (median of ");
     Serial.print(roundCount);
     Serial.print(" rounds): ");
     Serial.println(savedDistance[0], 1);
   }
 
   if (savedDistance[0] > CALIBRATION_MAX_CM) {
     Serial.println("  Unreliable — OPEN space mode");
     savedDistance[0] = 0;
   }
  savedDistance[1] = savedDistance[0];
  savedDistance[2] = savedDistance[0];

  detectionArmed = false;
  armClearStreak = 0;
  hitStreak[0] = hitStreak[1] = hitStreak[2] = 0;
  lastDualBurstIntrusion = false;

  Serial.print("Base: ");
  if (savedDistance[0] == 0) {
    Serial.println("OPEN");
  } else {
    Serial.print(savedDistance[0], 1);
    Serial.print(" cm | noise +/-");
    Serial.print(sensorErrorCm(savedDistance[0]), 1);
    Serial.print(" cm | alert drop >=");
    Serial.print(intrusionMinDropCm(savedDistance[0]), 1);
    Serial.println(" cm");
    Serial.print("Detection zone: ");
    Serial.print(DETECT_MAX_FEET);
    Serial.print(" ft (");
    Serial.print(DETECT_MAX_CM);
    Serial.println(" cm)");
    Serial.print("Arming: need ");
    Serial.print(ARM_CLEAR_REQUIRED);
    Serial.println(" clear scans before detection");
  }
}
 
 // Single straight scan — servo stays at FIXED_SERVO_ANGLE (90°), no sweep.
 bool processUltrasonicSweep(bool &alertTriggeredThisCycle, bool &candidateThisCycle, String &detectedAngle) {
   alertTriggeredThisCycle = false;
   candidateThisCycle = false;
   detectedAngle = "";
 
   // Zone 0 only, servo never moves
   const int i = 0;
 
   currentDistance[i] = readDistanceConfirmed(savedDistance[i], true, SCAN_PULSE_TIMEOUT_US);
 
   float errBand = savedDistance[i] > 0 ? sensorErrorCm(savedDistance[i]) : 0;
   float delta = (savedDistance[i] > 0 && currentDistance[i] > 0)
       ? savedDistance[i] - currentDistance[i] : 0;
 
  bool echoStable = currentDistance[i] > 0.0f;
  bool candidate  = echoStable && lastDualBurstIntrusion && isIntruderCandidate(i, currentDistance[i]);

  if (savedDistance[i] > 0 && !detectionArmed) {
    if (echoStable && !candidate && delta <= errBand) {
      if (armClearStreak < 255) armClearStreak++;
    } else if (candidate) {
      armClearStreak = 0;
    }
    if (armClearStreak >= ARM_CLEAR_REQUIRED) {
      detectionArmed = true;
      Serial.println("Detection ARMED");
    }
  }

  if (candidate) {
    candidateThisCycle = true;
    if (hitStreak[i] < 255) hitStreak[i]++;
  } else if (echoStable && savedDistance[i] > 0 && delta <= errBand) {
    hitStreak[i] = 0;
  } else if (hitStreak[i] > 0) {
    hitStreak[i]--;
  }

  uint8_t needed  = savedDistance[i] > 0 ? HIT_REQUIRED : OPEN_CALIB_HIT_REQUIRED;
  bool isIntruder = (savedDistance[i] == 0 || detectionArmed) && candidate && hitStreak[i] >= needed;
   float threshold = savedDistance[i] > 0 ? intrusionThresholdForBase(savedDistance[i]) : 0;
 
   Serial.print("Scan | Base:");
   if (savedDistance[i] == 0) Serial.print("OPEN");
   else { Serial.print(savedDistance[i], 1); Serial.print("cm"); }
 
   Serial.print(" Band:");
   if (savedDistance[i] == 0) Serial.print("-");
   else { Serial.print(errBand, 1); Serial.print("cm"); }
 
   Serial.print(" Thr:");
   if (savedDistance[i] == 0) Serial.print("ANY");
   else { Serial.print(threshold, 1); Serial.print("cm"); }
 
   Serial.print(" Cur:");
   if (currentDistance[i] == 0) Serial.print("--");
   else { Serial.print(currentDistance[i], 1); Serial.print("cm"); }
 
  Serial.print(" d:");
  if (delta > 0) Serial.print(delta, 1);
  else Serial.print("0");

  Serial.print(" 2x:");
  Serial.print(lastDualBurstIntrusion ? "Y" : "N");

  Serial.print(" V:");
   Serial.print(lastValidSampleCount);
   Serial.print("/");
   Serial.print(SCAN_SAMPLES);
 
  Serial.print(" Hits:");
  Serial.print(hitStreak[i]);
  Serial.print("/");
  Serial.print(needed);

  if (savedDistance[i] > 0 && !detectionArmed) {
    Serial.print(" Arm:");
    Serial.print(armClearStreak);
    Serial.print("/");
    Serial.print(ARM_CLEAR_REQUIRED);
  }

  if (isIntruder) {
     alertTriggeredThisCycle = true;
     detectedAngle = "90";
     Serial.println(" >>> INTRUDER <<<");
   } else {
     Serial.println(candidate ? " CANDIDATE" : (detectionArmed ? (echoStable ? " clear" : " fail") : " wait"));
   }
 
   return true;
 }
 
 void setup() {
   Serial.begin(115200);
   Serial.println();
   Serial.println("System Initializing...");
 
   pinMode(ONE_WIRE_BUS, INPUT);
   sensors.begin();
   sensors.setResolution(10);
   sensors.setWaitForConversion(true);
   delay(750);
   ds18b20Present = sensors.getDeviceCount() > 0;
   if (!ds18b20Present) {
     Serial.println("DS18B20 not found — temperature disabled");
   } else {
     Serial.print("DS18B20 OK, count: ");
     Serial.println(sensors.getDeviceCount());
   }
 
   pinMode(TRIG_PIN, OUTPUT);
   pinMode(ECHO_PIN, INPUT);
   pinMode(BUZZER_PIN, OUTPUT);
   pinMode(POWER_LED_PIN, OUTPUT);
   pinMode(WIFI_LED_PIN, OUTPUT);
   analogWriteFreq(1000);
   digitalWrite(BUZZER_PIN, LOW);
   updatePowerLed();
   setIndicatorLed(WIFI_LED_PIN, false);
 
   loadConfigFromEeprom();
   printDjangoIoTConfig();
 
   myServo.attach(SERVO_PIN);
   myServo.write(currentServoAngle);
   delay(150);
 
   Serial.println("ESP8266 needs 2.4 GHz WiFi.");
   initWifiStack();
   WiFi.onStationModeDisconnected(onWifiStationDisconnected);
   WiFi.onStationModeGotIP(onWifiStationGotIP);
 
   // Try EEPROM WiFi → on fail → hotspot (no fallback to #define)
   bool wifiConnected = false;
   if (wifiSsid.length() > 0) {
     Serial.print("Connecting to EEPROM WiFi: ");
     Serial.println(wifiSsid);
     wifiConnected = connectWifi(wifiSsid, wifiPass, WIFI_FAIL_AP_TIMEOUT_MS, true);
   }
   lastWifiRetryMs = millis();
 
   if (wifiConnected) {
     delay(1000);
 
     // Immediately poll /commands/ on boot so Django can push the real shop WiFi
     // (e.g. device boots on "sales" hotspot, Django replies with wifi_update → shop WiFi,
     // applyWifiUpdate() connects + saves to EEPROM before security starts).
     if (djangoIoTConfigured()) {
       Serial.println("[Boot] Checking Django for WiFi update...");
       lastCommandPollMs = 0;  // force immediate poll (bypass the 3s timer)
       pollDjangoCommands();
     }
 
     // After possible wifi_update, report the current (possibly new) WiFi to Django
     syncWifiToDjangoIfNeeded();
 
     server.on("/", handleRoot);
     server.begin();
     webServerBegun = true;
     Serial.print("Dashboard: http://");
     Serial.println(WiFi.localIP());
     performCalibration();
     if (ds18b20Present) reportTemperature();
     Serial.println("High-Speed Security Active");
     Serial.println("Scanning started...");
     beep(2, 60);
     return;
   }
 
   Serial.println("WiFi connect failed — starting setup hotspot");
   startWifiConfigPortal(wifiSsid.length() == 0);
 }
 
 void loop() {
   updatePowerLed();
 
   if (configPortalActive) {
     runConfigPortalLoop();
     return;
   }
 
   updateWifiLed();
   maintainWifi();
 
   if (ds18b20Present) {
     unsigned long tnow = millis();
     if (tnow - lastTempPollMs >= TEMP_POLL_MS) {
       lastTempPollMs = tnow;
       reportTemperature();
     }
   }
 
   if (!remoteEnabled) {
     maintainDjangoIoT();
     static unsigned long lastPausedLogMs = 0;
     if (millis() - lastPausedLogMs > 15000UL) {
       lastPausedLogMs = millis();
       if (djangoScheduleGate && djangoDesiredPower && !djangoInScheduleWindow)
         Serial.println("[PAUSED] Outside schedule window.");
       else if (!djangoDesiredPower)
         Serial.println("[PAUSED] Power OFF in customer portal.");
       else
         Serial.println("[PAUSED] Scanning disabled by Django.");
     }
     systemStatus = "SAFE";
     digitalWrite(BUZZER_PIN, LOW);
     twilioCallSent = false;
     intruderAlertBeeped = false;
     delay(50);
     return;
   }
 
   bool alertTriggeredThisCycle = false;
   bool candidateThisCycle = false;
   String detectedAngle = "";
   bool cycleDone = processUltrasonicSweep(alertTriggeredThisCycle, candidateThisCycle, detectedAngle);
 
   if (cycleDone) {
     if (alertTriggeredThisCycle || candidateThisCycle) {
       clearStreak = 0;
       if (alertTriggeredThisCycle && !twilioCallSent) {
         lastAlertAngle = detectedAngle;
         systemStatus = "ALERT";
         Serial.println("Intruder confirmed — Twilio (if due)");
         // Call Twilio BEFORE Django HTTPS so ESP8266 has free TLS heap
         if (tryIntruderTwilioOnce())
           twilioCallSent = true;
         if (!intruderAlertBeeped) {
           intruderAlertBeeped = true;
           beep(3, 35);
         }
       }
     } else if (clearStreak < 255) {
       clearStreak++;
     }
 
     if (clearStreak >= CLEAR_REQUIRED) {
       systemStatus = "SAFE";
       digitalWrite(BUZZER_PIN, LOW);
       twilioCallSent = false;
       intruderAlertBeeped = false;
     }
   }
 
   // Don't starve Twilio: while waiting for call (or phone), prioritize call over Django
   if (systemStatus == "ALERT" && !twilioCallSent) {
     if (tryIntruderTwilioOnce()) {
       twilioCallSent = true;
     } else if (twilioToNumber.length() < 8 &&
                millis() - lastCommandPollMs >= 5000UL &&
                !djangoHttpInUse) {
       pollDjangoCommands();
     }
   } else {
     maintainDjangoIoT();
   }
 }