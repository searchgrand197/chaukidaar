import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowLeft,
  Package,
  User,
  MapPin,
  Calendar,
  Wifi,
} from 'lucide-react';

const DetailRow = ({ label, value }) => (
  <div className="flex justify-between gap-4 py-3 border-b border-slate-100 last:border-0">
    <span className="text-slate-500 text-sm shrink-0">{label}</span>
    <span className="text-slate-900 font-semibold text-right break-all">{value || '—'}</span>
  </div>
);

const AssignmentDetail = () => {
  const navigate = useNavigate();
  const { state } = useLocation();
  const assignment = state?.assignment;

  if (!assignment) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
        <motion.div className="bg-white rounded-2xl p-8 max-w-md text-center border border-slate-100">
          <p className="text-slate-600 mb-4">Assignment not found. Open it from History.</p>
          <button
            type="button"
            onClick={() => navigate('/sales/history')}
            className="bg-indigo-600 text-white font-bold px-6 py-3 rounded-xl"
          >
            Go to History
          </button>
        </motion.div>
      </div>
    );
  }

  const deviceId = assignment.device_id_str || assignment.device?.device_id || '—';
  const intLabel = assignment.device?.sequence_number
    ? `INT-${assignment.device.sequence_number}`
    : null;

  return (
    <div className="min-h-screen bg-slate-50 p-4 md:p-8">
      <div className="max-w-2xl mx-auto space-y-6">
        <button
          type="button"
          onClick={() => navigate(-1)}
          className="flex items-center text-slate-500 hover:text-indigo-600 font-medium"
        >
          <ArrowLeft size={20} className="mr-2" />
          Back
        </button>

        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-[2rem] border border-slate-100 shadow-sm overflow-hidden"
        >
          <div className="bg-indigo-600 p-8 text-white">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 bg-white/20 rounded-2xl flex items-center justify-center">
                <Package size={28} />
              </div>
              <div>
                <p className="text-indigo-200 text-sm font-medium">Assigned device ID</p>
                <h1 className="text-2xl font-bold font-mono">{deviceId}</h1>
                {intLabel && (
                  <p className="text-indigo-100 text-sm mt-1">QR label: {intLabel}</p>
                )}
              </div>
            </div>
          </div>

          <div className="p-8 space-y-8">
            <section>
              <h2 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
                <User size={20} className="text-indigo-600" />
                Shop & owner
              </h2>
              <div className="bg-slate-50 rounded-2xl px-4">
                <DetailRow label="Shop name" value={assignment.shop_name} />
                <DetailRow label="Owner name" value={assignment.owner_name} />
                <DetailRow label="Phone" value={assignment.phone} />
                <DetailRow label="Alternate phone" value={assignment.alternate_phone} />
              </div>
            </section>

            <section>
              <h2 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
                <MapPin size={20} className="text-indigo-600" />
                Address
              </h2>
              <div className="bg-slate-50 rounded-2xl px-4">
                <DetailRow label="Address" value={assignment.address_line_1} />
                <DetailRow label="Address line 2" value={assignment.address_line_2} />
                <DetailRow label="City" value={assignment.city} />
                <DetailRow label="State" value={assignment.state} />
                <DetailRow label="Pincode" value={assignment.pincode} />
                <DetailRow label="Landmark" value={assignment.landmark} />
              </div>
            </section>

            {(assignment.wifi_ssid || assignment.notes) && (
              <section>
                <h2 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
                  <Wifi size={20} className="text-indigo-600" />
                  Other
                </h2>
                <div className="bg-slate-50 rounded-2xl px-4">
                  <DetailRow label="WiFi SSID" value={assignment.wifi_ssid} />
                  <DetailRow label="Notes" value={assignment.notes} />
                </div>
              </section>
            )}

            <section>
              <h2 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
                <Calendar size={20} className="text-indigo-600" />
                Assignment info
              </h2>
              <div className="bg-slate-50 rounded-2xl px-4">
                <DetailRow
                  label="Assigned on"
                  value={new Date(assignment.assigned_at).toLocaleString()}
                />
                <DetailRow
                  label="Assigned by"
                  value={assignment.assigned_by_details?.username || '—'}
                />
              </div>
            </section>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default AssignmentDetail;
