from datetime import datetime
import os

from django.conf import settings
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill


def generate_batch_excel(devices, batch_id):
    filename = f"batch_{batch_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    filepath = os.path.join(settings.MEDIA_ROOT, 'batches', filename)
    os.makedirs(os.path.dirname(filepath), exist_ok=True)

    wb = Workbook()
    ws = wb.active
    ws.title = f"Batch {batch_id}"

    headers = ['Serial No', 'Device ID', 'Random Token']
    header_fill = PatternFill(start_color='1E40AF', end_color='1E40AF', fill_type='solid')
    header_font = Font(bold=True, color='FFFFFF')

    for col, title in enumerate(headers, start=1):
        cell = ws.cell(row=1, column=col, value=title)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal='center')

    for row_idx, device in enumerate(devices, start=2):
        serial_label = (
            f"INT-{device.sequence_number}"
            if device.sequence_number is not None
            else device.device_id
        )
        ws.cell(row=row_idx, column=1, value=serial_label)
        ws.cell(row=row_idx, column=2, value=device.device_id)
        ws.cell(row=row_idx, column=3, value=device.device_token)

    ws.column_dimensions['A'].width = 16
    ws.column_dimensions['B'].width = 22
    ws.column_dimensions['C'].width = 48

    wb.save(filepath)
    return filename
