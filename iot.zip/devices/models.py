from django.db import models
from django.conf import settings
from django.utils import timezone
import secrets

def generate_device_token():
    return secrets.token_urlsafe(32)

class DeviceSequence(models.Model):
    last_id = models.PositiveIntegerField(default=0)

    @classmethod
    def get_next_ids(cls):
        from django.utils import timezone
        now = timezone.now()
        year = now.strftime('%y')
        month = now.month
        month_alpha = chr(64 + month) # 1=A, 2=B, 3=C, 4=D, 5=E...
        day = now.strftime('%d')
        prefix = f"{year}{month_alpha}{day}"
        
        seq, created = cls.objects.get_or_create(pk=1)
        seq.last_id += 1
        seq.save()
        
        serial = f"{seq.last_id:06d}" # 6-digit serial
        full_id = f"{prefix}{serial}"
        return full_id, seq.last_id

class Device(models.Model):
    STATUS_CHOICES = (
        ('available', 'Available'),
        ('assigned', 'Assigned'),
        ('damaged', 'Damaged'),
    )
    device_id = models.CharField(max_length=50, unique=True, db_index=True)
    sequence_number = models.PositiveIntegerField(default=0, null=True, blank=True)
    qr_image = models.ImageField(upload_to='qr_codes/', blank=True, null=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='available')
    batch = models.ForeignKey('Batch', on_delete=models.SET_NULL, null=True, related_name='devices')
    customer = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='customer_devices',
        limit_choices_to={'role': 'customer'},
    )
    device_token = models.CharField(max_length=128, default=generate_device_token, db_index=True)
    desired_power_state = models.BooleanField(default=True)
    is_armed = models.BooleanField(default=True)
    is_online = models.BooleanField(default=False)
    last_seen = models.DateTimeField(null=True, blank=True)
    last_temperature = models.DecimalField(max_digits=6, decimal_places=2, null=True, blank=True)
    last_ultrasonic_distance = models.DecimalField(max_digits=7, decimal_places=2, null=True, blank=True)
    firmware_version = models.CharField(max_length=50, blank=True)
    wifi_ssid = models.CharField(max_length=100, blank=True)
    wifi_password = models.CharField(max_length=100, blank=True)
    pending_wifi_ssid = models.CharField(max_length=100, blank=True)
    pending_wifi_password = models.CharField(max_length=100, blank=True)
    wifi_config_revision = models.PositiveIntegerField(default=0)
    wifi_ack_revision = models.PositiveIntegerField(default=0)
    wifi_ack_status = models.CharField(max_length=20, blank=True)
    ultrasonic_config = models.JSONField(default=dict, blank=True)
    pending_ultrasonic_config = models.JSONField(default=dict, blank=True)
    ultrasonic_config_revision = models.PositiveIntegerField(default=0)
    ultrasonic_ack_revision = models.PositiveIntegerField(default=0)
    ultrasonic_ack_status = models.CharField(max_length=20, blank=True)
    command_revision = models.PositiveIntegerField(default=0)
    command_ack_revision = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    printed_at = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return self.device_id

    class Meta:
        ordering = ['-id']

class DeviceAssignment(models.Model):
    device = models.OneToOneField(Device, on_delete=models.CASCADE, related_name='assignment')
    customer = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name='device_assignments')
    shop_name = models.CharField(max_length=255)
    owner_name = models.CharField(max_length=255)
    phone = models.CharField(max_length=15)
    alternate_phone = models.CharField(max_length=15, blank=True, null=True)
    address_line_1 = models.CharField(max_length=255)
    address_line_2 = models.CharField(max_length=255, blank=True, null=True)
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    pincode = models.CharField(max_length=10)
    landmark = models.CharField(max_length=255, blank=True, null=True)
    wifi_ssid = models.CharField(max_length=100, blank=True, null=True)
    wifi_password = models.CharField(max_length=100, blank=True, null=True)
    # Plaintext portal password so salesman can re-show customer login credentials.
    # Django auth still stores a hashed copy on the User; this is for sales support only.
    portal_password = models.CharField(max_length=64, blank=True, default='')
    notes = models.TextField(blank=True, null=True)
    
    assigned_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name='assignments')
    assigned_at = models.DateTimeField(auto_now_add=True)
    
    latitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    longitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    shop_photo = models.ImageField(upload_to='shop_photos/', null=True, blank=True)

    def __str__(self):
        return f"{self.device.device_id} assigned to {self.shop_name}"

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        update_fields = []
        if self.customer_id and self.device.customer_id != self.customer_id:
            self.device.customer = self.customer
            update_fields.append('customer')
        if self.wifi_ssid and self.device.wifi_ssid != self.wifi_ssid:
            self.device.wifi_ssid = self.wifi_ssid
            update_fields.append('wifi_ssid')
        if update_fields:
            self.device.save(update_fields=update_fields)

class DeviceSchedule(models.Model):
    device = models.ForeignKey(Device, on_delete=models.CASCADE, related_name='schedules')
    name = models.CharField(max_length=100, default='Default schedule')
    start_time = models.TimeField()
    end_time = models.TimeField()
    weekdays = models.CharField(max_length=20, default='0,1,2,3,4,5,6')
    enabled = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['start_time']

    def __str__(self):
        return f"{self.device.device_id}: {self.start_time}-{self.end_time}"

class SensorReading(models.Model):
    device = models.ForeignKey(Device, on_delete=models.CASCADE, related_name='sensor_readings')
    temperature = models.DecimalField(max_digits=6, decimal_places=2, null=True, blank=True)
    ultrasonic_distance = models.DecimalField(max_digits=7, decimal_places=2, null=True, blank=True)
    heat_alarm = models.BooleanField(default=False)
    status = models.CharField(max_length=20, blank=True)
    created_at = models.DateTimeField(default=timezone.now, db_index=True)

    class Meta:
        ordering = ['-created_at']

class Batch(models.Model):
    batch_number = models.AutoField(primary_key=True)
    count = models.IntegerField()
    created_at = models.DateTimeField(auto_now_add=True)
    pdf_file = models.FileField(upload_to='batches/', blank=True, null=True)
    excel_file = models.FileField(upload_to='batches/', blank=True, null=True)

    def __str__(self):
        return f"Batch #{self.batch_number} ({self.count} devices)"

    class Meta:
        verbose_name_plural = "Batches"
