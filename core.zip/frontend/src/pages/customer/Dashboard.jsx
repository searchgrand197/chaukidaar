import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Loader2, LogOut, Power, Thermometer, Wifi } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { customerDeviceService } from '../../api/services';

const Dashboard = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [devices, setDevices] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadDevices = async () => {
      try {
        const response = await customerDeviceService.list();
        setDevices(response.data.results || response.data || []);
      } catch (error) {
        console.error(error);
      } finally {
        setLoading(false);
      }
    };
    loadDevices();
  }, []);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      <header className="px-5 py-6 flex items-center justify-between">
        <div>
          <p className="text-slate-400 text-sm">Welcome</p>
          <h1 className="text-2xl font-black">{user?.username}</h1>
        </div>
        <button onClick={handleLogout} className="p-3 rounded-2xl bg-white/10 text-rose-200">
          <LogOut size={20} />
        </button>
      </header>

      <main className="bg-slate-50 text-slate-900 rounded-t-[2.5rem] min-h-[calc(100vh-96px)] p-5">
        <div className="flex items-center justify-between mb-5">
          <div>
            <h2 className="text-xl font-black">My IoT Devices</h2>
            <p className="text-sm text-slate-500">Control security devices from mobile</p>
          </div>
          <span className="px-3 py-1 rounded-full bg-indigo-50 text-indigo-700 text-sm font-bold">
            {devices.length}
          </span>
        </div>

        {loading ? (
          <div className="h-64 flex items-center justify-center">
            <Loader2 className="animate-spin text-indigo-600" size={36} />
          </div>
        ) : devices.length === 0 ? (
          <div className="bg-white rounded-[2rem] p-8 text-center border border-slate-100">
            <Wifi className="mx-auto text-slate-300 mb-3" size={48} />
            <h3 className="text-lg font-black">No device assigned</h3>
            <p className="text-slate-500 mt-2">Ask support to link your account with your installed device.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {devices.map((device) => (
              <button
                key={device.device_id}
                onClick={() => navigate(`/customer/device/${device.device_id}`)}
                className="w-full text-left bg-white rounded-[2rem] p-5 border border-slate-100 shadow-sm"
              >
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <p className="font-mono text-sm text-slate-500">{device.device_id}</p>
                    <h3 className="text-xl font-black mt-1">
                      {device.assignment?.shop_name || 'Security Device'}
                    </h3>
                    <p className="text-sm text-slate-500 mt-1">
                      {device.is_online ? 'Online' : 'Offline'} · {device.desired_power_state ? 'On' : 'Off'}
                    </p>
                  </div>
                  <div className={`p-3 rounded-2xl ${device.desired_power_state ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-500'}`}>
                    <Power size={22} />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3 mt-5">
                  <div className="rounded-2xl bg-slate-50 p-3">
                    <p className="text-xs text-slate-500">Temperature</p>
                    <p className="font-black flex items-center gap-1">
                      <Thermometer size={16} /> {device.last_temperature ?? '--'} C
                    </p>
                  </div>
                  <div className="rounded-2xl bg-slate-50 p-3">
                    <p className="text-xs text-slate-500">WiFi</p>
                    <p className="font-black truncate">{device.wifi_ssid || 'Not set'}</p>
                  </div>
                </div>
              </button>
            ))}
          </div>
        )}
      </main>
    </div>
  );
};

export default Dashboard;
