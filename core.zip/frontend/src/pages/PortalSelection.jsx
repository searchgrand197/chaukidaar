import React from 'react';
import { useNavigate } from 'react-router-dom';
import { QrCode, Users, ArrowRight } from 'lucide-react';
import { motion } from 'framer-motion';

const PortalSelection = () => {
  const navigate = useNavigate();

  const options = [
    {
      title: 'QR Generator',
      description: 'Generate device IDs, QR codes, and PDF labels for new devices.',
      icon: <QrCode size={40} className="text-indigo-600" />,
      path: '/admin/generate',
      color: 'bg-indigo-50 border-indigo-200 hover:border-indigo-400',
    },
    {
      title: 'Salesperson Portal',
      description: 'Verify devices and assign them to shops with GPS tracking.',
      icon: <Users size={40} className="text-emerald-600" />,
      path: '/sales/dashboard',
      color: 'bg-emerald-50 border-emerald-200 hover:border-emerald-400',
    },
  ];

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
      <div className="max-w-4xl w-full">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-extrabold text-slate-900 mb-4">Unified Management Portal</h1>
          <p className="text-slate-600 text-lg">Select a service to continue</p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {options.map((option, index) => (
            <motion.div
              key={index}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => navigate(option.path)}
              className={`cursor-pointer p-8 rounded-3xl border-2 transition-all ${option.color} flex flex-col items-center text-center shadow-sm hover:shadow-md bg-white`}
            >
              <div className="mb-6 p-4 rounded-2xl bg-white shadow-sm">
                {option.icon}
              </div>
              <h2 className="text-2xl font-bold text-slate-900 mb-3">{option.title}</h2>
              <p className="text-slate-500 mb-8 leading-relaxed">
                {option.description}
              </p>
              <div className="mt-auto flex items-center text-slate-900 font-bold group">
                Enter Portal <ArrowRight size={20} className="ml-2 group-hover:translate-x-1 transition-transform" />
              </div>
            </motion.div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <button 
            onClick={() => {
              localStorage.removeItem('token');
              navigate('/login');
            }}
            className="text-slate-400 hover:text-slate-600 font-medium transition-colors"
          >
            Sign Out
          </button>
        </div>
      </div>
    </div>
  );
};

export default PortalSelection;
