"""
Create or reset default Salesperson + QR Generator (admin) portal logins.

Usage:
  python manage.py seed_portal_users
  python manage.py seed_portal_users --sales-user mysales --sales-pass secret
"""

from django.core.management.base import BaseCommand
from django.contrib.auth import get_user_model

SALES_USERNAME = 'sales'
SALES_PASSWORD = 'sales123'
QR_USERNAME = 'alok'
QR_PASSWORD = '0000'


class Command(BaseCommand):
    help = 'Create/reset salesperson and QR generator (admin) portal users'

    def add_arguments(self, parser):
        parser.add_argument('--sales-user', default=SALES_USERNAME)
        parser.add_argument('--sales-pass', default=SALES_PASSWORD)
        parser.add_argument('--qr-user', default=QR_USERNAME)
        parser.add_argument('--qr-pass', default=QR_PASSWORD)

    def handle(self, *args, **options):
        User = get_user_model()
        sales_user = options['sales_user'].strip()
        sales_pass = options['sales_pass']
        qr_user = options['qr_user'].strip()
        qr_pass = options['qr_pass']

        salesperson, created = User.objects.get_or_create(
            username=sales_user,
            defaults={'role': 'salesperson', 'is_active': True, 'active_status': True},
        )
        salesperson.role = 'salesperson'
        salesperson.is_active = True
        salesperson.active_status = True
        salesperson.is_staff = False
        salesperson.is_superuser = False
        salesperson.set_password(sales_pass)
        salesperson.save()

        qr_admin, created_qr = User.objects.get_or_create(
            username=qr_user,
            defaults={'role': 'admin', 'is_active': True, 'active_status': True},
        )
        qr_admin.role = 'admin'
        qr_admin.is_active = True
        qr_admin.active_status = True
        qr_admin.is_staff = True
        qr_admin.set_password(qr_pass)
        qr_admin.save()

        self.stdout.write(self.style.SUCCESS('Portal users ready'))
        self.stdout.write('')
        self.stdout.write('Salesperson (scan QR / assign devices):')
        self.stdout.write(f'  username: {sales_user}')
        self.stdout.write(f'  password: {sales_pass}')
        self.stdout.write('  login as: Salesperson')
        self.stdout.write('')
        self.stdout.write('QR Generator (admin — generate batches / QR labels):')
        self.stdout.write(f'  username: {qr_user}')
        self.stdout.write(f'  password: {qr_pass}')
        self.stdout.write('  login as: QR Generator')
        self.stdout.write('')
        self.stdout.write(f'Salesperson {"created" if created else "updated"}; QR admin {"created" if created_qr else "updated"}.')
