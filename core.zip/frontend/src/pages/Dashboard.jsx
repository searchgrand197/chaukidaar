import React, { useState, useEffect } from 'react';
import { 
  Tablet, 
  CheckCircle, 
  AlertCircle, 
  Package,
  TrendingUp,
  Clock,
  QrCode
} from 'lucide-react';
import { deviceService, batchService } from '../api/services';
import { format } from 'date-fns';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
};

const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0 }
};

const StatCard = ({ label, value, icon: Icon, color, trend }) => (
  <motion.div variants={item} className="glass-card p-6 flex items-center gap-5">
    <div className={`w-14 h-14 rounded-2xl ${color} flex items-center justify-center text-white shadow-lg`}>
      <Icon className="w-7 h-7" />
    </div>
    <div>
      <p className="text-slate-500 text-sm font-medium">{label}</p>
      <div className="flex items-baseline gap-2">
        <h3 className="text-2xl font-bold text-slate-800">{value}</h3>
        {trend && <span className="text-xs text-green-500 font-medium">{trend}</span>}
      </div>
    </div>
  </motion.div>
);

const Dashboard = () => {
  const [stats, setStats] = useState({
    total: 0,
    available: 0,
    assigned: 0,
    damaged: 0
  });
  const [recentBatches, setRecentBatches] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const [totalRes, availableRes, assignedRes, damagedRes, batchesRes] = await Promise.all([
          deviceService.list({ limit: 1 }),
          deviceService.list({ status: 'available', limit: 1 }),
          deviceService.list({ status: 'assigned', limit: 1 }),
          deviceService.list({ status: 'damaged', limit: 1 }),
          batchService.list({ limit: 5 }),
        ]);

        setStats({
          total: totalRes.data?.count ?? 0,
          available: availableRes.data?.count ?? 0,
          assigned: assignedRes.data?.count ?? 0,
          damaged: damagedRes.data?.count ?? 0,
        });
        setRecentBatches(batchesRes.data?.results || []);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchStats();
  }, []);

  return (
    <motion.div 
      variants={container}
      initial="hidden"
      animate="show"
      className="space-y-8"
    >
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <motion.div variants={item}>
          <h1 className="text-3xl font-bold text-slate-900">Admin Dashboard</h1>
          <p className="text-slate-500">Welcome back. Here's what's happening with your devices.</p>
        </motion.div>
        <motion.div variants={item} className="flex gap-3">
          <div className="bg-white px-4 py-2 rounded-lg border border-slate-200 flex items-center gap-2">
            <Clock className="w-4 h-4 text-slate-400" />
            <span className="text-sm font-medium text-slate-600">
              Last updated: {format(new Date(), 'HH:mm')}
            </span>
          </div>
        </motion.div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          label="Total Devices" 
          value={loading ? '…' : stats.total} 
          icon={Package} 
          color="bg-blue-600"
        />
        <StatCard 
          label="Available" 
          value={loading ? '…' : stats.available} 
          icon={Tablet} 
          color="bg-emerald-500"
        />
        <StatCard 
          label="Assigned" 
          value={loading ? '…' : stats.assigned} 
          icon={CheckCircle} 
          color="bg-indigo-500"
        />
        <StatCard 
          label="Damaged" 
          value={loading ? '…' : stats.damaged} 
          icon={AlertCircle} 
          color="bg-rose-500"
        />
      </div>

      <motion.div variants={item} className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 glass-card overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
            <h2 className="text-lg font-bold text-slate-800">Recent Batches</h2>
            <Link to="/admin/batches" className="text-sm text-primary-600 font-semibold hover:underline">View All</Link>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wider">
                <tr>
                  <th className="px-6 py-3 font-semibold">Batch ID</th>
                  <th className="px-6 py-3 font-semibold">Date</th>
                  <th className="px-6 py-3 font-semibold">Count</th>
                  <th className="px-6 py-3 font-semibold">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {recentBatches?.map((batch) => (
                  <tr key={batch.batch_number} className="hover:bg-slate-50 transition-colors">
                    <td className="px-6 py-4 font-medium text-slate-900">#{batch.batch_number}</td>
                    <td className="px-6 py-4 text-slate-600">{format(new Date(batch.created_at), 'MMM dd, yyyy')}</td>
                    <td className="px-6 py-4">
                      <span className="px-2 py-1 bg-blue-50 text-blue-600 rounded-md text-xs font-bold">
                        {batch.count} IDs
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <a 
                        href={batch.pdf_url} 
                        target="_blank" 
                        rel="noreferrer"
                        className="text-primary-600 hover:text-primary-700 font-medium text-sm"
                      >
                        Download PDF
                      </a>
                    </td>
                  </tr>
                ))}
                {recentBatches.length === 0 && (
                  <tr>
                    <td colSpan="4" className="px-6 py-10 text-center text-slate-400 italic">
                      No batches generated yet.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        <div className="glass-card p-6 flex flex-col items-center justify-center text-center space-y-4">
          <div className="w-20 h-20 bg-primary-100 rounded-full flex items-center justify-center">
            <QrCode className="w-10 h-10 text-primary-600" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-slate-800">Need more IDs?</h3>
            <p className="text-slate-500 text-sm mt-1">
              Generate a new batch of device QR codes instantly.
            </p>
          </div>
          <Link 
            to="/admin/generate" 
            className="w-full btn-primary text-center block"
          >
            Go to Generator
          </Link>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default Dashboard;
