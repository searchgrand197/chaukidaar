import React from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { Check, Home, Share2, FileText, ArrowRight } from 'lucide-react';
import { motion } from 'framer-motion';

const Success = () => {
  const [searchParams] = useSearchParams();
  const device_id = searchParams.get('device_id');
  const shop_name = searchParams.get('shop_name');
  const navigate = useNavigate();

  const formatIntId = (fullId) => {
    if (!fullId) return '';
    if (fullId.startsWith('INT-')) return fullId;
    const match = fullId.match(/\d+$/);
    if (match) {
      return `INT-${parseInt(match[0], 10)}`;
    }
    return fullId;
  };

  const intId = formatIntId(device_id);

  const shareWhatsApp = () => {
    const text = `INT Device ${intId} assigned successfully to ${shop_name}.`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
  };

  return (
    <div className="min-h-screen bg-white flex flex-col">
      <div className="h-[40vh] bg-emerald-500 rounded-b-[4rem] flex flex-col items-center justify-center text-white relative">
        <motion.div 
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          className="w-24 h-24 bg-white/20 rounded-full flex items-center justify-center border-4 border-white/30"
        >
          <Check size={48} strokeWidth={3} />
        </motion.div>
        <h1 className="text-4xl font-bold mt-8">Assignment Success!</h1>
      </div>

      <div className="max-w-xl mx-auto w-full px-4 -mt-16">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-[2.5rem] shadow-2xl p-10 border border-slate-100"
        >
          <div className="space-y-8">
            <div className="text-center">
              <p className="text-slate-400 font-medium mb-1">Device ID</p>
              <h2 className="text-3xl font-black text-slate-900 tracking-tight">{intId}</h2>
            </div>

            <div className="h-px bg-slate-100 w-full" />

            <div className="text-center">
              <p className="text-slate-400 font-medium mb-1">Shop / Customer</p>
              <h3 className="text-2xl font-bold text-slate-900">{shop_name}</h3>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4">
              <button 
                onClick={shareWhatsApp}
                className="flex items-center justify-center p-4 bg-emerald-50 text-emerald-700 font-bold rounded-2xl border border-emerald-100 hover:bg-emerald-100 transition-all"
              >
                <Share2 size={20} className="mr-2" />
                WhatsApp
              </button>
              <button 
                className="flex items-center justify-center p-4 bg-indigo-50 text-indigo-700 font-bold rounded-2xl border border-indigo-100 hover:bg-indigo-100 transition-all"
              >
                <FileText size={20} className="mr-2" />
                Get PDF
              </button>
            </div>
          </div>
        </motion.div>

        <button 
          onClick={() => navigate('/sales/dashboard')}
          className="w-full mt-12 bg-slate-900 hover:bg-black text-white font-bold py-5 rounded-2xl flex items-center justify-center space-x-2 transition-all shadow-xl"
        >
          <Home size={20} />
          <span>Back to Dashboard</span>
          <ArrowRight size={20} />
        </button>
      </div>
    </div>
  );
};

export default Success;
